#include "stdafx.h"
#include "resource.h"
#include "maindlg.h"

#include <vector>
// include the C regexp code
#ifdef _UNICODE

#define REGEXP_UNICODE
#define re_comp_t re_comp_w
#define re_exec_t re_exec_w

#else

#undef REGEXP_UNICODE
#define re_comp_t re_comp
#define re_exec_t re_exec

#endif
#include "regexp.h"
#include "CRegExp.h"

void CMainDlg::TryIt()
{
	m_ctlResults.ResetContent();
	
	CString sRegExp;
	int nLen = m_ctlRegExp.GetWindowTextLength();
	
	m_ctlRegExp.GetWindowText(sRegExp.GetBufferSetLength(nLen), nLen + 1);
	sRegExp.ReleaseBuffer();

	try
	{
		CRegExp reObject(sRegExp);

		CString sMatch;
		nLen = m_ctlMatch.GetWindowTextLength();
		m_ctlMatch.GetWindowText(sMatch.GetBufferSetLength(nLen), nLen + 1);
		sMatch.ReleaseBuffer();
		
		BOOL bMatched = reObject.Exec(sMatch);
		if(!bMatched)
		{
			m_ctlResults.AddString(_T("No match"));
		}
		else
		{
			for(int i = 0; i < reObject.GetNumberOfMatches(); ++i)
			{
				if(reObject.IsMatched(i))
					m_ctlResults.AddString(reObject.GetMatch(i));
				else
					m_ctlResults.AddString(_T("-"));
			}
		}
		m_ctlResults.SetCurSel(0);
	}
	catch(CRegExpException& cree)
	{
		m_ctlResults.ResetContent();
		m_ctlResults.AddString(_T("Regexp Error: ") + cree.GetErrorString());
		m_ctlResults.SetCurSel(0);
		return;
	}
}

