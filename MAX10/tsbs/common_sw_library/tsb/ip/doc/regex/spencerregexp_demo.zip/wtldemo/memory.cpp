#include "stdafx.h"

#include "regexp_int.h"
#include "regexp_custom.h"

#include <stdlib.h>

void* re_malloc(size_t sz)
{
    return ::CoTaskMemAlloc(sz);
}

void re_cfree(void* p)
{
    ::CoTaskMemFree(p);
}

