#include <iostream>
#include <cmath>

#include "vxt.hpp"

inline bool run_test00()
{
   const std::size_t N = 32;

   {
      typedef vxt::vector<int,N> vector_t;
      vector_t v0(3);
      vector_t v1(2);
      vector_t v3;

      v3 = (3 + 2);

      if (!vxt::all_true(v3 == vector_t(v0 + v1)))
      {
         std::cout << "run_test00() - Failed test 00\n";
         return false;
      }

      v3 = (2 - 3);
      if (!vxt::all_true(v3 == vector_t(v1 - v0)))
      {
         std::cout << "run_test00() - Failed test 01\n";
         return false;
      }

      v3 = (3 * 2);
      if (!vxt::all_true(v3 == vector_t(v0 * v1)))
      {
         std::cout << "run_test00() - Failed test 02\n";
         return false;
      }

      v3 = (3 / 2);
      if (!vxt::all_true(v3 == vector_t(v0 / v1)))
      {
         std::cout << "run_test00() - Failed test 03\n";
         return false;
      }
   }

   {
      typedef vxt::vector<double,N> vector_t;
      vector_t v0(3.3);
      vector_t v1(2.2);
      vector_t v3;

      v3 = (3.3 + 2.2);
      if (!vxt::all_true(v3 == vector_t(v0 + v1)))
      {
         std::cout << "run_test00() - Failed test 04\n";
         return false;
      }

      v3 = (2.2 - 3.3);
      if (!vxt::all_true(v3 == vector_t(v1 - v0)))
      {
         std::cout << "run_test00() - Failed test 05\n";
         return false;
      }

      v3 = (3.3 * 2.2);
      if (!vxt::all_true(v3 == vector_t(v0 * v1)))
      {
         std::cout << "run_test00() - Failed test 06\n";
         return false;
      }

      v3 = (3.3 / 2.2);
      if (!vxt::all_true(v3 == vector_t(v0 / v1)))
      {
         std::cout << "run_test00() - Failed test 07\n";
         return false;
      }
   }

   {
      typedef vxt::vector<double,N> vector_t;
      vector_t v0(3.3);
      vector_t v1(2.2);
      vector_t v3(1.1);
      vector_t v4((v0[0] + v1[0]) / v3[0]);

      if (!vxt::all_true(v4 == vector_t((v0 + v1) / v3)))
      {
         std::cout << "run_test00() - Failed test 08\n";
         return false;
      }
   }

   {
      typedef vxt::vector<double,N> vector_t;
      vector_t v0(4.4);
      vector_t v1(3.3);
      vector_t v3(2.2);
      vector_t v4(1.1);
      vector_t v5((v0[0] + v1[0]) / (v3[0] - v4[0]));

      if (!vxt::all_true(v5 == vector_t((v0 + v1) / (v3 - v4))))
      {
         std::cout << "run_test00() - Failed test 09\n";
         return false;
      }
   }

   {
      typedef vxt::vector<double,N> vector_t;
      vector_t v0(2.2);
      vector_t v1(2.2 + 3.3);

      if (!vxt::all_true(v1 == vector_t(v0 + vxt::lit(3.3))))
      {
         std::cout << "run_test00() - Failed test 10\n";
         return false;
      }

      if (!vxt::all_true(v1 == vector_t(vxt::lit(3.3) + v0)))
      {
         std::cout << "run_test00() - Failed test 11\n";
         return false;
      }

      v1 = (2.2 * 3.3);

      if (!vxt::all_true(v1 == vector_t(v0 * vxt::lit(3.3))))
      {
         std::cout << "run_test00() - Failed test 12\n";
         return false;
      }

      if (!vxt::all_true(v1 == vector_t(vxt::lit(3.3) * v0)))
      {
         std::cout << "run_test00() - Failed test 13\n";
         return false;
      }

      v1 = (1.1 / 2.2);

      if (!vxt::all_true(v1 == vector_t(vxt::lit(1.1) / v0)))
      {
         std::cout << "run_test00() - Failed test 14\n";
         return false;
      }

      v1 = (2.2 / 1.1);

      if (!vxt::all_true(v1 == vector_t(v0 / vxt::lit(1.1))))
      {
         std::cout << "run_test00() - Failed test 15\n";
         return false;
      }
   }

   {
      typedef vxt::vector<double,N> vector_t;

      double x = 3.3;

      vector_t v0(2.2);
      vector_t v1(2.2 + x);

      if (!vxt::all_true(v1 == vector_t(v0 + vxt::var(x))))
      {
         std::cout << "run_test00() - Failed test 16\n";
         return false;
      }

      if (!vxt::all_true(v1 == vector_t(vxt::var(x) + v0)))
      {
         std::cout << "run_test00() - Failed test 17\n";
         return false;
      }

      v1 = (2.2 * x);

      if (!vxt::all_true(v1 == vector_t(v0 * vxt::var(x))))
      {
         std::cout << "run_test00() - Failed test 18\n";
         return false;
      }

      if (!vxt::all_true(v1 == vector_t(vxt::var(x) * v0)))
      {
         std::cout << "run_test00() - Failed test 19\n";
         return false;
      }

      x = 1.1;

      v1 = (x / 2.2);

      if (!vxt::all_true(v1 == vector_t(vxt::var(x) / v0)))
      {
         std::cout << "run_test00() - Failed test 20\n";
         return false;
      }

      v1 = (2.2 / x);

      if (!vxt::all_true(v1 == vector_t(v0 / vxt::var(x))))
      {
         std::cout << "run_test00() - Failed test 21\n";
         return false;
      }
   }

   {
      typedef vxt::vector<double,N> vector_t;

      double x = 3.3;

      vector_t v0(2.2);
      vector_t v1;

      v1 = (4.4 + 2.2 + x);

      if (!vxt::all_true(v1 == vector_t(vxt::lit(4.4) + v0 + vxt::var(x))))
      {
         std::cout << "run_test00() - Failed test 22\n";
         return false;
      }

      v1 = (4.4 - 2.2 - x);

      if (!vxt::all_true(v1 == vector_t(vxt::lit(4.4) - v0 - vxt::var(x))))
      {
         std::cout << "run_test00() - Failed test 23\n";
         return false;
      }

      v1 = (4.4 * 2.2 * x);

      if (!vxt::all_true(v1 == vector_t(vxt::lit(4.4) * v0 * vxt::var(x))))
      {
         std::cout << "run_test00() - Failed test 24\n";
         return false;
      }

      v1 = (4.4 / 2.2 / x);

      if (!vxt::all_true(v1 == vector_t(vxt::lit(4.4) / v0 / vxt::var(x))))
      {
         std::cout << "run_test00() - Failed test 25\n";
         return false;
      }

      v1 = (4.4 / 2.2 + x);

      if (!vxt::all_true(v1 == vector_t(vxt::lit(4.4) / v0 + vxt::var(x))))
      {
         std::cout << "run_test00() - Failed test 26\n";
         return false;
      }

      v1 = (4.4 / (2.2 + x));

      if (!vxt::all_true(v1 == vector_t(vxt::lit(4.4) / (v0 + vxt::var(x)))))
      {
         std::cout << "run_test00() - Failed test 27\n";
         return false;
      }
   }

   return true;
}

bool run_test01()
{
   const std::size_t N = 16;

   {
      typedef vxt::vector<int,N> vector_t;
      vector_t v;

      int sum_result = 0;
      for (std::size_t i = 0; i < N; ++i)
      {
         v[i] = i;
         sum_result += i;
      }

      if (sum_result != sum(v))
      {
         std::cout << "run_test01() - Failed test 00\n";
         return false;
      }

      if (0 != min(v))
      {
         std::cout << "run_test01() - Failed test 01\n";
         return false;
      }

      if (15 != max(v))
      {
         std::cout << "run_test01() - Failed test 02\n";
         return false;
      }
   }

   {
      typedef vxt::vector<double,N> vector_t;
      vector_t v;

      double sum_result = 0;
      for (std::size_t i = 0; i < N; ++i)
      {
         v[i] = i;
         sum_result += i;
      }

      if (sum_result != sum(v))
      {
         std::cout << "run_test01() - Failed test 03\n";
         return false;
      }

      if (0 != min(v))
      {
         std::cout << "run_test01() - Failed test 04\n";
         return false;
      }

      if (15 != max(v))
      {
         std::cout << "run_test01() - Failed test 05\n";
         return false;
      }
   }

   {
      typedef vxt::vector<int,N> vector_t;
      vector_t v0;
      vector_t v1;

      int sum_result = 0;
      int sum_sqr_result = 0;
      for (std::size_t i = 0; i < N; ++i)
      {
         v0[i] = i;
         v1[i] = i;
         sum_result += i;
         sum_sqr_result += (i * i);
      }

      if ((2 * sum_result) != sum(v0 + v1))
      {
         std::cout << "run_test01() - Failed test 06\n";
         return false;
      }

      if (0 != sum(v0 - v1))
      {
         std::cout << "run_test01() - Failed test 07\n";
         return false;
      }

      if (sum_sqr_result != sum(v0 * v1))
      {
         std::cout << "run_test01() - Failed test 08\n";
         return false;
      }

      if (0 != min(v0 + v1))
      {
         std::cout << "run_test01() - Failed test 09\n";
         return false;
      }

      if (0 != min(v0 - v1))
      {
         std::cout << "run_test01() - Failed test 10\n";
         return false;
      }

      if (0 != min(v0 * v1))
      {
         std::cout << "run_test01() - Failed test 11\n";
         return false;
      }

      if ((2 * (N - 1)) != max(v0 + v1))
      {
         std::cout << "run_test01() - Failed test 12\n";
         return false;
      }

      if (0 != max(v0 - v1))
      {
         std::cout << "run_test01() - Failed test 13\n";
         return false;
      }

      if (((N - 1) * (N - 1)) != max(v0 * v1))
      {
         std::cout << "run_test01() - Failed test 14\n";
         return false;
      }
   }

   return true;
}

bool run_test02()
{

   {
      const std::size_t N = 1;
      const std::size_t M = 2;
      const std::size_t O = 3;
      const std::size_t P = 4;
      const std::size_t Q = 5;
      const std::size_t R = 6;
      const std::size_t S = 7;

      typedef vxt::vector<int,N>          vector_t;
      typedef vxt::vector<vector_t,M>     vector_tt;
      typedef vxt::vector<vector_tt,O>    vector_ttt;
      typedef vxt::vector<vector_ttt,P>   vector_tttt;
      typedef vxt::vector<vector_tttt,Q>  vector_ttttt;
      typedef vxt::vector<vector_ttttt,R> vector_tttttt;
      typedef vxt::vector<vector_tttttt,S> vector_ttttttt;

      vector_ttttttt v0(1);
      vector_ttttttt v1(2);
      vector_ttttttt v2(3);
      vector_ttttttt v3(9);

      v3 = ((v0 + v1) * v2);
      v3 = ((v0 + v1) * v2);
   }

   return true;
}

int main()
{
   run_test00();
   run_test01();
   run_test02();
   return 0;
}
