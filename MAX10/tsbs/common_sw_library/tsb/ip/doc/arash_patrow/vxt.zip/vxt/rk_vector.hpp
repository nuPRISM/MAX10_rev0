#ifndef RK_VECTOR_HPP
#define RK_VECTOR_HPP

namespace rk
{
   template <typename T, std::size_t N>
   struct vector_t
   {
      vector_t()
      {}

      vector_t(const vector_t<T,N>& u)                  { for (std::size_t i = 0; i < N; ++i) { v[i] = u.v[i]; }                }
      vector_t<T,N>& operator=(const vector_t<T,N>& u)  { for (std::size_t i = 0; i < N; ++i) { v[i] = u.v[i]; }  return *this; }
      vector_t<T,N>& operator+=(const T& t)             { for (std::size_t i = 0; i < N; ++i) { v[i] += t; }      return *this; }
      vector_t<T,N>& operator-=(const T& t)             { for (std::size_t i = 0; i < N; ++i) { v[i] -= t; }      return *this; }
      vector_t<T,N>& operator*=(const T& t)             { for (std::size_t i = 0; i < N; ++i) { v[i] *= t; }      return *this; }
      vector_t<T,N>& operator/=(const T& t)             { for (std::size_t i = 0; i < N; ++i) { v[i] /= t; }      return *this; }
      vector_t<T,N>& operator+=(const vector_t<T,N>& u) { for (std::size_t i = 0; i < N; ++i) { v[i] += u.v[i]; } return *this; }
      vector_t<T,N>& operator-=(const vector_t<T,N>& u) { for (std::size_t i = 0; i < N; ++i) { v[i] -= u.v[i]; } return *this; }

      T& operator[](const std::size_t i)
      {
         return v[i];
      }

      const T& operator[](const std::size_t i) const { return v[i]; }

      T v[N];
   };

   template<typename T, std::size_t N>
   inline vector_t<T,N> operator+(const T t, const vector_t<T,N>& v)
   {
      vector_t<T,N> result;
      for (std::size_t i = 0; i < N; ++i) { result.v[i] = (t + v.v[i]); }
      return result;
   }

   template<typename T, std::size_t N>
   inline vector_t<T,N> operator+(const vector_t<T,N>& v, const T t)
   {
      return (t + v);
   }

   template<typename T, std::size_t N>
   inline vector_t<T,N> operator-(const vector_t<T,N>& v, const T t)
   {
      vector_t<T,N> result;
      for (std::size_t i = 0; i < N; ++i) { result.v[i] = (v.v[i] - t); }
      return result;
   }

   template<typename T, std::size_t N>
   inline vector_t<T,N> operator*(const T t, const vector_t<T,N>& v)
   {
      vector_t<T,N> result;
      for (std::size_t i = 0; i < N; ++i) { result.v[i] = (t * v.v[i]); }
      return result;
   }

   template<typename T, std::size_t N>
   inline vector_t<T,N> operator/(const vector_t<T,N>& v, const T t)
   {
      vector_t<T,N> result;
      for (std::size_t i = 0; i < N; ++i) { result.v[i] = (v.v[i] / t); }
      return result;
   }

   template<typename T, std::size_t N>
   inline vector_t<T,N> operator+(const vector_t<T,N>& v, const vector_t<T,N>& u)
   {
      vector_t<T,N> result;
      for (std::size_t i = 0; i < N; ++i) { result.v[i] = v.v[i] + u.v[i]; }
      return result;
   }

   template<typename T, std::size_t N>
   inline vector_t<T,N> operator-(const vector_t<T,N>& v, const vector_t<T,N>& u)
   {
      vector_t<T,N> result;
      for (std::size_t i = 0; i < N; ++i) { result.v[i] = v.v[i] - u.v[i]; }
      return result;
   }
}

#endif
