/*
 *************************************************************
 *            Vector Expression Template Library             *
 *                                                           *
 * Example: Mass-Spring Simulation via 4th Order Runge-Kutta *
 * Author: Arash Partow (2003)                               *
 * URL: http://www.partow.net/programming/vxt/index.html     *
 *                                                           *
 * Copyright notice:                                         *
 * Free use of the C++ Vector Expression Template Library    *
 * is permitted under the guidelines and in accordance with  *
 * the most current version of the Common Public License.    *
 * http://www.opensource.org/licenses/cpl1.0.php             *
 *                                                           *
 *************************************************************
*/


#include <cstdio>

#include "vxt.hpp"


namespace vxt_example
{
   template <typename T, std::size_t N>
   struct rk4_integrator
   {
      typedef vxt::vector<T,N> vector_t;

      template <typename Model>
      void operator()(Model& model, const T t, const T h, vector_t& x)
      {
         model.derivative(            t, x                        , k1); k1 *= h;
         model.derivative(t + h / T(2) , x + (k1 / vxt::lit(T(2))), k2); k2 *= h;
         model.derivative(t + h / T(2) , x + (k2 / vxt::lit(T(2))), k3); k3 *= h;
         model.derivative(t + h        , x + (k3                 ), k4); k4 *= h;
         x = x + ((k1 + (vxt::lit(T(2)) * (k2 + k3)) + k4) / vxt::lit(T(6)));
      }

      vector_t k1;
      vector_t k2;
      vector_t k3;
      vector_t k4;
   };

   template <typename T>
   struct spring
   {
      typedef vxt::vector<T,2> vector_t;

      template <typename VectorExpr>
      void derivative(const T&, const VectorExpr& x, vector_t& dx)
      {
         dx[0] = x[1];
         dx[1] = (-ks * x[0] + -kd * x[1]) / mass;
      }

      T mass;
      T ks;
      T kd;
   };

   template <typename T>
   void run()
   {
      const T h = T(0.0001);
      const T max_time = T(5000);

      spring<T> s;
      s.ks   =    T(1);
      s.kd   = T(0.02);
      s.mass =    T(2);

      typedef vxt::vector<T,2> vector_t;

      vector_t x;
      rk4_integrator<T,2> integrator;

      x[0] = T(10);
      x[1] = T(0);

      int i = 0;
      T t   = T(0);

      while (t < max_time)
      {
         integrator(s,t,h,x);

         if ((i % 1000) == 0)
         {
            printf("%15.10f %15.10f %15.10f\n", t,x[0],x[1]);
         }
         t += h;
         ++i;
      }
   }
}

int main()
{
   vxt_example::run<double>();
   return 0;
}
