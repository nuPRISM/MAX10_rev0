/*
 ************************************************************
 *            Vector Expression Template Library            *
 *                                                          *
 * Author: Arash Partow (2003)                              *
 * URL: http://www.partow.net/programming/vxt/index.html    *
 *                                                          *
 * Copyright notice:                                        *
 * Free use of the C++ Vector Expression Template Library   *
 * is permitted under the guidelines and in accordance with *
 * the most current version of the Common Public License.   *
 * http://www.opensource.org/licenses/cpl1.0.php            *
 *                                                          *
 ************************************************************
*/


#ifndef INCLUDE_VXT_HPP
#define INCLUDE_VXT_HPP


#include <algorithm>
#include <cmath>
#include <limits>


namespace vxt
{
   template <typename Expr, typename Op, typename T>
   struct unary;

   template <typename LExpr, typename RExpr,
             typename Op, typename T>
   struct binary;

   template <typename T, std::size_t N>
   struct vector
   {
      typedef T value_type;

      value_type d[N];

      explicit inline vector(const value_type& v = T())
      {
         for (std::size_t i = 0; i < N; ++i)
         {
            d[i] = v;
         }
      }

      template <typename TT>
      explicit inline vector(const TT& v)
      {
         for (std::size_t i = 0; i < N; ++i)
         {
            d[i] = v;
         }
      }

      template <typename TT, std::size_t M>
      explicit inline vector(const vector<TT,N>& v)
      {
         for (std::size_t i = 0; i < N; ++i)
         {
            d[i] = v[i];
         }
      }

      template <typename TT, std::size_t M>
      explicit inline vector(const vector<TT,M>& v)
      {
         const std::size_t NN = std::min(N,M);
         for (std::size_t i = 0; i < NN; ++i)
         {
            d[i] = v[i];
         }
      }

      template <typename LExpr, typename RExpr, typename Op>
      explicit inline vector(const binary<LExpr,RExpr,Op,T>& o)
      {
         for (std::size_t i = 0; i < N; ++i)
         {
            d[i] = o[i];
         }
      }

      template <typename Expr, typename Op>
      explicit inline vector(const unary<Expr,Op,T>& o)
      {
         for (std::size_t i = 0; i < N; ++i)
         {
            d[i] = o[i];
         }
      }

      #define vxt_define_uniary_operator(Opr)                      \
      inline vector<T,N>& operator Opr (const T& t)                \
      {                                                            \
         for (std::size_t i = 0; i < N; ++i)                       \
         { d[i] Opr t; }                                           \
         return *this;                                             \
      }                                                            \
                                                                   \
      inline vector<T,N>& operator Opr (const vector<T,N>& v)      \
      {                                                            \
         for (std::size_t i = 0; i < N; ++i)                       \
         { d[i] Opr v.d[i]; }                                      \
         return *this;                                             \
      }                                                            \
                                                                   \
      template <typename Expr, typename Op>                        \
      inline vector<T,N>& operator Opr (const unary<Expr,Op,T>& u) \
      {                                                            \
         for (std::size_t i = 0; i < N; ++i)                       \
         { d[i] Opr u[i]; }                                        \
         return *this;                                             \
      }                                                            \
                                                                   \
      template <typename L, typename R, typename Op>               \
      inline vector<T,N>& operator Opr (const binary<L,R,Op,T>& b) \
      {                                                            \
         for (std::size_t i = 0; i < N; ++i)                       \
         { d[i] Opr b[i]; }                                        \
         return *this;                                             \
      }                                                            \

      vxt_define_uniary_operator(+=)
      vxt_define_uniary_operator(-=)
      vxt_define_uniary_operator(*=)
      vxt_define_uniary_operator(/=)

      #undef vxt_define_uniary_operator

      inline const T* begin() const
      {
         return &d;
      }

      inline T* begin()
      {
         return &d;
      }

      inline const T* end() const
      {
         return &d + N;
      }

      inline T* end()
      {
         return &d + N;
      }

      static inline std::size_t size()
      {
         return N;
      }

      inline value_type operator[](const std::size_t& x) const
      {
         return d[x];
      }

      inline value_type& operator[](const std::size_t& x)
      {
         return d[x];
      }

      inline vector<T,N>& operator=(const T& v)
      {
         for (std::size_t i = 0; i < N; ++i)
         {
            d[i] = v;
         }
         return *this;
      }

      template <typename TT>
      inline vector<T,N>& operator=(const TT& v)
      {
         for (std::size_t i = 0; i < N; ++i)
         {
            d[i] = v;
         }
         return *this;
      }

      template <typename std::size_t M>
      inline vector<T,M>& operator=(const vector<T,M>& v)
      {
         for (std::size_t i = 0; i < M; ++i)
         {
            d[i] = v[i];
         }
         return *this;
      }

      template <typename LExpr, typename RExpr, typename Op, typename TT>
      inline vector<T,N>& operator=(const binary<LExpr,RExpr,Op,TT>& o)
      {
         for (std::size_t i = 0; i < N; ++i)
         {
            d[i] = o[i];
         }
         return *this;
      }

      template <typename Expr, typename Op, typename TT>
      inline vector<T,N>& operator=(const unary<Expr,Op,TT>& o)
      {
         for (std::size_t i = 0; i < N; ++i)
         {
            d[i] = o[i];
         }
         return *this;
      }
   };

   template <typename T>
   struct literal
   {
      inline literal(const T& t)
      : v(t)
      {}

      inline T operator[](const std::size_t) const
      {
         return v;
      }

      static inline std::size_t size()
      {
         return std::numeric_limits<std::size_t>::max();
      }

      const T v;
   };

   template <typename T>
   struct variable
   {
      explicit inline variable(const T& t)
      : v(t)
      {}

      inline const T& operator[](const std::size_t) const
      {
         return v;
      }

      static inline std::size_t size()
      {
         return std::numeric_limits<std::size_t>::max();
      }

      const T& v;
   };

   template <typename T>
   inline literal<T> lit(const T t)
   {
      return literal<T>(t);
   }

   template <typename T>
   inline variable<T> var(const T& t)
   {
      return variable<T>(t);
   }

   template <typename T, std::size_t N>
   inline std::size_t size(const vector<T,N>&)
   {
      return vector<T,N>::size();
   }

   template <typename T>
   inline std::size_t size(const literal<T>&)
   {
      return literal<T>::size();
   }

   template <typename T>
   inline std::size_t size(const variable<T>&)
   {
      return variable<T>::size();
   }

   template <typename Expr, typename Op, typename T>
   inline std::size_t size(const unary<Expr,Op,T>& u)
   {
      return u.size();
   }

   template <typename L, typename R, typename Op, typename T>
   inline std::size_t size(const binary<L,R,Op,T>& b)
   {
      return b.size();
   }

   namespace details
   {
      static const double log2 = 0.693147180559945309417;

      template <typename T> inline T   abs_impl(const T v) { return std::abs  (v); }
      template <typename T> inline T  acos_impl(const T v) { return std::acos (v); }
      template <typename T> inline T  asin_impl(const T v) { return std::asin (v); }
      template <typename T> inline T  atan_impl(const T v) { return std::atan (v); }
      template <typename T> inline T  ceil_impl(const T v) { return std::ceil (v); }
      template <typename T> inline T   cos_impl(const T v) { return std::cos  (v); }
      template <typename T> inline T  cosh_impl(const T v) { return std::cosh (v); }
      template <typename T> inline T   cot_impl(const T v) { return T(1) / std::tan(v); }
      template <typename T> inline T   csc_impl(const T v) { return T(1) / std::sin(v); }
      template <typename T> inline T   exp_impl(const T v) { return std::exp  (v); }
      template <typename T> inline T floor_impl(const T v) { return std::floor(v); }
      template <typename T> inline T   inv_impl(const T v) { return T(1) / v;      }
      template <typename T> inline T   log_impl(const T v) { return std::log  (v); }
      template <typename T> inline T log10_impl(const T v) { return std::log10(v); }
      template <typename T> inline T  log2_impl(const T v) { return std::log(v) / T(log2); }
      template <typename T> inline T   sec_impl(const T v) { return T(1) / std::cos(v); }
      template <typename T> inline T   sin_impl(const T v) { return std::sin  (v); }
      template <typename T> inline T  sinh_impl(const T v) { return std::sinh (v); }
      template <typename T> inline T   sqr_impl(const T v) { return v * v;         }
      template <typename T> inline T  sqrt_impl(const T v) { return std::sqrt (v); }
      template <typename T> inline T   tan_impl(const T v) { return std::tan  (v); }
      template <typename T> inline T  tanh_impl(const T v) { return std::tanh (v); }

      template <typename T, typename ReturnType,
                typename Function, std::size_t N>
      inline vector<ReturnType,N> apply(const vector<T,N>& v, Function f)
      {
         vector<ReturnType,N> result;
         for (std::size_t i = 0; i < N; ++i)
         {
            f(result[i],v[i]);
         }
         return result;
      }

      template <typename ReturnType, std::size_t N, typename Expr,
                typename Opr, typename T, typename Function>
      inline vector<ReturnType,N> apply(const unary<Expr,Opr,T>& u, Function f)
      {
         vector<ReturnType,N> result;
         for (std::size_t i = 0; i < N; ++i)
         {
            f(result[i],u[i]);
         }
         return result;
      }

      template <typename ReturnType, std::size_t N, typename L, typename R,
                typename Opr, typename T, typename Function>
      inline vector<ReturnType,N> apply(const binary<L,R,Opr,T>& b, Function f)
      {
         vector<ReturnType,N> result;
         for (std::size_t i = 0; i < N; ++i)
         {
            f(result[i],b[i]);
         }
         return result;
      }

      template <typename T, typename ReturnType,
                typename Function, std::size_t N>
      inline vector<ReturnType,N> apply(const vector<T,N>& v0,
                                        const vector<T,N>& v1,
                                        Function f)
      {
         vector<ReturnType,N> result;
         for (std::size_t i = 0; i < N; ++i)
         {
            f(result[i],v0[i],v1[i]);
         }
         return result;
      }

      #define vxt_define_apply(Type)                           \
      template <typename T, typename ReturnType,               \
                typename Function, std::size_t N>              \
      inline vector<ReturnType,N> apply(const vector<T,N>& v0, \
                                        const Type<T>& v1,     \
                                        Function f)            \
      {                                                        \
         vector<ReturnType,N> result;                          \
         for (std::size_t i = 0; i < N; ++i)                   \
         {                                                     \
            f(result[i],v0[i],v1[i]);                          \
         }                                                     \
         return result;                                        \
      }                                                        \
                                                               \
      template <typename T, typename ReturnType,               \
                typename Function, std::size_t N>              \
      inline vector<ReturnType,N> apply(const Type<T>& v0,     \
                                        const vector<T,N>& v1, \
                                        Function f)            \
      {                                                        \
         vector<ReturnType,N> result;                          \
         for (std::size_t i = 0; i < N; ++i)                   \
         {                                                     \
            f(result[i],v0[i],v1[i]);                          \
         }                                                     \
         return result;                                        \
      }                                                        \

      vxt_define_apply(variable)
      vxt_define_apply(literal)

      #undef vxt_define_apply
   }

   #define vxt_define_unary_operation(FunctionName)    \
   struct FunctionName##_op                            \
   {                                                   \
      template <typename R, typename T>                \
      static inline R execute(const T t)               \
      {                                                \
         return details:: FunctionName##_impl(t);      \
      }                                                \
   };                                                  \
                                                       \
   template <typename Expr, typename Opr, typename T>  \
   inline unary<unary<Expr,Opr,T>,FunctionName##_op,T> \
   FunctionName(const unary<Expr,Opr,T>& u)            \
   {                                                   \
      return unary<                                    \
               unary<Expr,Opr,T>,                      \
               FunctionName##_op,T>(u);                \
   }                                                   \
                                                       \
   template <typename L, typename R,                   \
             typename Opr, typename T>                 \
   inline unary<binary<L,R,Opr,T>,FunctionName##_op,T> \
   FunctionName(const binary<L,R,Opr,T>& b)            \
   {                                                   \
      return unary<                                    \
               binary<L,R,Opr,T>,                      \
               FunctionName##_op,T>(b);                \
   }                                                   \
                                                       \
   template <typename T>                               \
   inline unary<literal<T>,FunctionName##_op,T>        \
   FunctionName(const literal<T>& l)                   \
   {                                                   \
      return unary<                                    \
               literal<T>,                             \
               FunctionName##_op,T>(l);                \
   }                                                   \
                                                       \
   template <typename T>                               \
   inline unary<variable<T>,FunctionName##_op,T>       \
   FunctionName(const variable<T>& v)                  \
   {                                                   \
      return unary<                                    \
               variable<T>,                            \
               FunctionName##_op,T>(v);                \
   }                                                   \
                                                       \
   template <typename T, std::size_t N>                \
   inline unary<vector<T,N>,FunctionName##_op,T>       \
   FunctionName(const vector<T,N>& v)                  \
   {                                                   \
      return unary<                                    \
               vector<T,N>,                            \
               FunctionName##_op,T>(v);                \
   }                                                   \

   vxt_define_unary_operation(  abs)
   vxt_define_unary_operation( acos)
   vxt_define_unary_operation( asin)
   vxt_define_unary_operation( atan)
   vxt_define_unary_operation( ceil)
   vxt_define_unary_operation(  cos)
   vxt_define_unary_operation( cosh)
   vxt_define_unary_operation(  exp)
   vxt_define_unary_operation(floor)
   vxt_define_unary_operation(  inv)
   vxt_define_unary_operation(  log)
   vxt_define_unary_operation(log10)
   vxt_define_unary_operation( log2)
   vxt_define_unary_operation(  sin)
   vxt_define_unary_operation( sinh)
   vxt_define_unary_operation( sqrt)
   vxt_define_unary_operation(  tan)
   vxt_define_unary_operation( tanh)
   vxt_define_unary_operation(  cot)
   vxt_define_unary_operation(  sec)
   vxt_define_unary_operation(  csc)

   #undef vxt_define_unary_operation

   template <typename Expr,
             typename Op, typename T>
   struct unary
   {
      const Expr& e;

      inline unary(const Expr& exp)
      : e(exp)
      {}

      inline T operator[](const std::size_t& x) const
      {
         return Op::template execute<T>(e[x]);
      }

      inline std::size_t size() const
      {
         return size(e);
      }
   };

   template <typename LExpr, typename RExpr,
             typename Op, typename T>
   struct binary
   {
      const LExpr& l;
      const RExpr& r;

      inline binary(const LExpr& l, const RExpr& r)
      : l(l),
        r(r)
      {}

      inline T operator[](const std::size_t& x) const
      {
         T result;
         Op::template execute(result,l[x],r[x]);
         return result;
      }

      inline std::size_t size() const
      {
         return std::min(vxt::size(l),vxt::size(r));
      }
   };

   #define vxt_define_binary_operator(Operator,OpFunc)   \
   namespace details                                     \
   {                                                     \
      struct OpFunc##_op                                 \
      {                                                  \
         template <typename R, typename T1, typename T2> \
         static inline void execute(R& r,                \
                                    const T1& t1,        \
                                    const T2& t2)        \
         {                                               \
            r = t1 Operator t2;                          \
         }                                               \
      };                                                 \
   }                                                     \
                                                         \
   template <typename L1, typename R1, typename Op1,     \
             typename L2, typename R2, typename Op2,     \
             typename T>                                 \
   inline binary<                                        \
      binary<L1,R1,Op1,T>,                               \
      binary<L2,R2,Op2,T>,                               \
      details::OpFunc##_op,T>                            \
   operator Operator(const binary<L1,R1,Op1,T>& l,       \
                     const binary<L2,R2,Op2,T>& r)       \
   {                                                     \
      return binary<                                     \
                binary<L1,R1,Op1,T>,                     \
                binary<L2,R2,Op2,T>,                     \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename L, typename R, typename Op1,       \
             typename Expr, typename Op2,                \
             typename T>                                 \
   inline binary<                                        \
      binary<L,R,Op1,T>,                                 \
      unary<Expr,Op2,T>,                                 \
      details::OpFunc##_op,T>                            \
   operator Operator(const binary<L,R,Op1,T>& l,         \
                     const unary<Expr,Op2,T>& r)         \
   {                                                     \
      return binary<                                     \
                binary<L,R,Op1,T>,                       \
                unary<Expr,Op2,T>,                       \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename L, typename R, typename Op1,       \
             typename Expr, typename Op2,                \
             typename T>                                 \
   inline binary<                                        \
      unary<Expr,Op2,T>,                                 \
      binary<L,R,Op1,T>,                                 \
      details::OpFunc##_op,T>                            \
   operator Operator(const unary<Expr,Op2,T>& r,         \
                     const binary<L,R,Op1,T>& l)         \
   {                                                     \
      return binary<                                     \
                unary<Expr,Op2,T>,                       \
                binary<L,R,Op1,T>,                       \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename L, typename R,                     \
             typename Opr, typename T, std::size_t N>    \
   inline binary<                                        \
      binary<L,R,Opr,T>,                                 \
      vector<T,N>,                                       \
      details::OpFunc##_op,T>                            \
   operator Operator(const binary<L,R,Opr,T>& l,         \
                     const vector<T,N>& r)               \
   {                                                     \
      return binary<                                     \
                binary<L,R,Opr,T>,                       \
                vector<T,N>,                             \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename Expr,                              \
             typename Opr, typename T, std::size_t N>    \
   inline binary<                                        \
      unary<Expr,Opr,T>,                                 \
      vector<T,N>,                                       \
      details::OpFunc##_op,T>                            \
   operator Operator(const unary<Expr,Opr,T>& l,         \
                     const vector<T,N>& r)               \
   {                                                     \
      return binary<                                     \
                unary<Expr,Opr,T>,                       \
                vector<T,N>,                             \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename L, typename R,                     \
             typename Opr, typename T, std::size_t N>    \
   inline binary<                                        \
      vector<T,N>,                                       \
      binary<L,R,Opr,T>,                                 \
      details::OpFunc##_op,T>                            \
   operator Operator(const vector<T,N>& l,               \
                     const binary<L,R,Opr,T>& r)         \
   {                                                     \
      return binary<                                     \
                vector<T,N>,                             \
                binary<L,R,Opr,T>,                       \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename T, std::size_t N>                  \
   inline binary<                                        \
      vector<T,N>,                                       \
      vector<T,N>,                                       \
      details::OpFunc##_op,T>                            \
   operator Operator(const vector<T,N>& l,               \
                     const vector<T,N>& r)               \
   {                                                     \
      return binary<                                     \
               vector<T,N>,                              \
               vector<T,N>,                              \
               details::OpFunc##_op,T>(l,r);             \
   }                                                     \
                                                         \
   template <typename Expr,                              \
             typename Opr, typename T>                   \
   inline binary<                                        \
      literal<T>,                                        \
      unary<Expr,Opr,T>,                                 \
      details::OpFunc##_op,T>                            \
   operator Operator(const literal<T>& l,                \
                     const unary<Expr,Opr,T>& r)         \
   {                                                     \
      return binary<                                     \
                literal<T>,                              \
                unary<Expr,Opr,T>,                       \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename Expr,                              \
             typename Opr, typename T>                   \
   inline binary<                                        \
      unary<Expr,Opr,T>,                                 \
      literal<T>,                                        \
      details::OpFunc##_op,T>                            \
   operator Operator(const unary<Expr,Opr,T>& l,         \
                     const literal<T>& r)                \
   {                                                     \
      return binary<                                     \
                unary<Expr,Opr,T>,                       \
                literal<T>,                              \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename L, typename R,                     \
             typename Opr, typename T>                   \
   inline binary<                                        \
      literal<T>,                                        \
      binary<L,R,Opr,T>,                                 \
      details::OpFunc##_op,T>                            \
   operator Operator(const literal<T>& l,                \
                     const binary<L,R,Opr,T>& r)         \
   {                                                     \
      return binary<                                     \
                literal<T>,                              \
                binary<L,R,Opr,T>,                       \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename L, typename R,                     \
             typename Opr, typename T>                   \
   inline binary<                                        \
      binary<L,R,Opr,T>,                                 \
      literal<T>,                                        \
      details::OpFunc##_op,T>                            \
   operator Operator(const binary<L,R,Opr,T>& l,         \
                     const literal<T>& r)                \
   {                                                     \
      return binary<                                     \
                binary<L,R,Opr,T>,                       \
                literal<T>,                              \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename T, std::size_t N>                  \
   inline binary<                                        \
      literal<T>,                                        \
      vector<T,N>,                                       \
      details::OpFunc##_op,T>                            \
   operator Operator(const literal<T>& l,                \
                     const vector<T,N>& r)               \
   {                                                     \
      return binary<                                     \
               literal<T>,                               \
               vector<T,N>,                              \
               details::OpFunc##_op,T>(l,r);             \
   }                                                     \
                                                         \
   template <typename T, std::size_t N>                  \
   inline binary<                                        \
      vector<T,N>,                                       \
      literal<T>,                                        \
      details::OpFunc##_op,T>                            \
   operator Operator(const vector<T,N>& l,               \
                     const literal<T>& r)                \
   {                                                     \
      return binary<                                     \
               vector<T,N>,                              \
               literal<T>,                               \
               details::OpFunc##_op,T>(l,r);             \
   }                                                     \
                                                         \
   template <typename T>                                 \
   inline binary<                                        \
      variable<T>,                                       \
      variable<T>,                                       \
      details::OpFunc##_op,T>                            \
   operator Operator(const variable<T>& l,               \
                     const variable<T>& r)               \
   {                                                     \
      return binary<                                     \
                variable<T>,                             \
                variable<T>,                             \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename Expr, typename Opr, typename T>    \
   inline binary<                                        \
      variable<T>,                                       \
      unary<Expr,Opr,T>,                                 \
      details::OpFunc##_op,T>                            \
   operator Operator(const variable<T>& l,               \
                     const unary<Expr,Opr,T>& r)         \
   {                                                     \
      return binary<                                     \
                variable<T>,                             \
                unary<Expr,Opr,T>,                       \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename Expr, typename Opr, typename T>    \
   inline binary<                                        \
      unary<Expr,Opr,T>,                                 \
      variable<T>,                                       \
      details::OpFunc##_op,T>                            \
   operator Operator(const unary<Expr,Opr,T>& l,         \
                     const variable<T>& r)               \
   {                                                     \
      return binary<                                     \
                unary<Expr,Opr,T>,                       \
                variable<T>,                             \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename L, typename R,                     \
             typename Opr, typename T>                   \
   inline binary<                                        \
      variable<T>,                                       \
      binary<L,R,Opr,T>,                                 \
      details::OpFunc##_op,T>                            \
   operator Operator(const variable<T>& l ,              \
                     const binary<L,R,Opr,T>& r)         \
   {                                                     \
      return binary<                                     \
                variable<T>,                             \
                binary<L,R,Opr,T>,                       \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename L, typename R,                     \
             typename Opr, typename T>                   \
   inline binary<                                        \
      binary<L,R,Opr,T>,                                 \
      variable<T>,                                       \
      details::OpFunc##_op,T>                            \
   operator Operator(const binary<L,R,Opr,T>& l,         \
                     const variable<T>& r)               \
   {                                                     \
      return binary<                                     \
                binary<L,R,Opr,T>,                       \
                variable<T>,                             \
                details::OpFunc##_op,T>(l,r);            \
   }                                                     \
                                                         \
   template <typename T, std::size_t N>                  \
   inline binary<                                        \
      variable<T>,                                       \
      vector<T,N>,                                       \
      details::OpFunc##_op,T>                            \
   operator Operator(const variable<T>& l,               \
                     const vector<T,N>& r)               \
   {                                                     \
      return binary<                                     \
               variable<T>,                              \
               vector<T,N>,                              \
               details::OpFunc##_op,T>(l,r);             \
   }                                                     \
                                                         \
   template <typename T, std::size_t N>                  \
   inline binary<                                        \
      vector<T,N>,                                       \
      variable<T>,                                       \
      details::OpFunc##_op,T>                            \
   operator Operator(const vector<T,N>& l,               \
                     const variable<T>& r)               \
   {                                                     \
      return binary<                                     \
               vector<T,N>,                              \
               variable<T>,                              \
               details::OpFunc##_op,T>(l,r);             \
   }                                                     \

   vxt_define_binary_operator(+,add)
   vxt_define_binary_operator(-,sub)
   vxt_define_binary_operator(*,mul)
   vxt_define_binary_operator(/,div)

   #undef vxt_define_binary_operator


   #define vxt_define_utility(Type,TemplateDefinition) \
   TemplateDefinition                                  \
   inline T sum(const Type& t)                         \
   {                                                   \
      T result = t[0];                                 \
      const std::size_t NN = size(t);                  \
      for (std::size_t i = 1; i < NN; ++i)             \
      {                                                \
         result += t[i];                               \
      }                                                \
      return result;                                   \
   }                                                   \
                                                       \
   TemplateDefinition                                  \
   inline T min(const Type& t)                         \
   {                                                   \
      T result = t[0];                                 \
      const std::size_t NN = size(t);                  \
      for (std::size_t i = 1; i < NN; ++i)             \
      {                                                \
         result = std::min(t[i],result);               \
      }                                                \
      return result;                                   \
   }                                                   \
                                                       \
   TemplateDefinition                                  \
   inline T max(const Type& t)                         \
   {                                                   \
      T result = t[0];                                 \
      const std::size_t NN = size(t);                  \
      for (std::size_t i = 1; i < NN; ++i)             \
      {                                                \
         result = std::max(t[i],result);               \
      }                                                \
      return result;                                   \
   }                                                   \

   #define vxt_c ,

   vxt_define_utility(vector<T vxt_c N> ,                        \
                      template <typename T vxt_c std::size_t N>) \

   vxt_define_utility(unary<Expr vxt_c O vxt_c T> ,                               \
                      template <typename Expr vxt_c typename O vxt_c typename T>) \

   vxt_define_utility(binary<L vxt_c R vxt_c O vxt_c T> ,                                       \
                      template <typename L vxt_c typename R vxt_c typename O vxt_c typename T>) \

   #undef vxt_c
   #undef vxt_define_utility

   template <std::size_t N>
   inline bool all_true(const vector<bool,N>& v)
   {
      for (std::size_t i = 0; i < N; ++i)
      {
         if (!v[i]) return false;
      }
      return true;
   }

   template <std::size_t N>
   inline bool all_false(const vector<bool,N>& v)
   {
      for (std::size_t i = 0; i < N; ++i)
      {
         if (v[i]) return false;
      }
      return true;
   }

   #define vxt_define_comparator_operators(Operator,OpFunc)      \
   namespace details                                             \
   {                                                             \
      struct OpFunc##_op                                         \
      {                                                          \
         template <typename R, typename T1, typename T2>         \
         inline void operator()(R& r, const T1 t1, const T2 t2)  \
         {                                                       \
            r = (t1 Operator t2);                                \
         }                                                       \
      };                                                         \
   }                                                             \
                                                                 \
   template <typename T, std::size_t N>                          \
   inline vector<bool,N> operator Operator(const vector<T,N>& l, \
                                           const vector<T,N>& r) \
   {                                                             \
      return details::apply<T,bool,details::OpFunc##_op,N>       \
                         (l,r,details::OpFunc##_op());           \
   }                                                             \
                                                                 \
   template <typename T, std::size_t N>                          \
   inline vector<bool,N> operator Operator(const vector<T,N>& l, \
                                           const literal<T>& r)  \
   {                                                             \
      return details::apply<T,bool,details::OpFunc##_op,N>       \
                         (l,r,details::OpFunc##_op());           \
   }                                                             \
                                                                 \
   template <typename T, std::size_t N>                          \
   inline vector<bool,N> operator Operator(const literal<T>& l,  \
                                           const vector<T,N>& r) \
   {                                                             \
      return details::apply<T,bool,details::OpFunc##_op,N>       \
                         (l,r,details::OpFunc##_op());           \
   }                                                             \
                                                                 \
   template <typename T, std::size_t N>                          \
   inline vector<bool,N> operator Operator(const vector<T,N>& l, \
                                           const variable<T>& r) \
   {                                                             \
      return details::apply<T,bool,details::OpFunc##_op,N>       \
                         (l,r,details::OpFunc##_op());           \
   }                                                             \
                                                                 \
   template <typename T, std::size_t N>                          \
   inline vector<bool,N> operator Operator(const variable<T>& l, \
                                           const vector<T,N>& r) \
   {                                                             \
      return details::apply<T,bool,details::OpFunc##_op,N>       \
                         (l,r,details::OpFunc##_op());           \
   }                                                             \

   vxt_define_comparator_operators(==,equal )
   vxt_define_comparator_operators(!=,nequal)
   vxt_define_comparator_operators(< ,lt    )
   vxt_define_comparator_operators(<=,lte   )
   vxt_define_comparator_operators(> ,gt    )
   vxt_define_comparator_operators(>=,gte   )

   #undef vxt_define_comparator_operators
}

#endif
