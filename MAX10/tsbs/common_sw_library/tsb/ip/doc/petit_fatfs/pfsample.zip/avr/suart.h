#ifndef SUART
#define SUART

void xmit(uint8_t);
uint8_t rcvr();

#endif	/* SUART */
