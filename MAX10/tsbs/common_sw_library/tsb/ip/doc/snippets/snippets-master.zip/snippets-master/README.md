snippets
========

The SNIPPETS C and C++ Source Code Archives


The SNIPPETS archive was maintained for years by Bob Stout, but when he died, the snippets.org domain went away.

This is an effort to put the SNIPPETS archive back online.


Patches and additions welcome!  Any stand alone C or C++ gist is welcome.

(Patches to make old snippets compile on modern targets, should you find any problem.)
