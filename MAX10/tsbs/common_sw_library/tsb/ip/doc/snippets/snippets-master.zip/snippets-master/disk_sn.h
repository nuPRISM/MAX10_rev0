/*
**  get_disk_id() - Retrieve a disk serial number
*/

#ifndef DISK_SN__H
#define DISK_SN__H

char *get_disk_id(int drive);

#endif /*  DISK_SN__H */
