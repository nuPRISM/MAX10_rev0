/*
**  SNIPPETS header file for CTRLPRNT.C
*/

#ifndef CTRLPRNT__H
#define CTRLPRNT__H

void ctrl_print(char *line);

#endif /* CTRLPRNT__H */
