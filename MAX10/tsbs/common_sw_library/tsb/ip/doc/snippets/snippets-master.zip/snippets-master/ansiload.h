/*
**  ANSILOAD.H - tries to detect if an ANSI-style driver is loaded
*/

#ifndef ANSILOAD__H
#define ANSILOAD__H

int is_ansi_loaded(void);

#endif /* ANSILOAD__H */
