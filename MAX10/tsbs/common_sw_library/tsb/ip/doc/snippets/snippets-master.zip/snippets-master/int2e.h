/*
**  Header for Int 2Eh interface
*/

#ifndef INT2E__H
#define INT2E__H

#include "extkword.h"

extern void CDECL _Int_2E(char *);
void C_Com_Call(char *string);

#endif /* INT2E__H */
