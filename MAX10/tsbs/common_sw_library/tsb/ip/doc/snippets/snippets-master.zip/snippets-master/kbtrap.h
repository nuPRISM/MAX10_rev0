/*
**  KBTRAP.H - Header for KBTRAP.C
*/

#ifndef KBTRAP_H__
#define KBTRAP_H__

void activate_KBtrap(void);
void deactivate_KBtrap(void);


#endif /* KBTRAP_H__ */
