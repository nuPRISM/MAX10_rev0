/*
**  REGKEY.H - SNIPPETS header file for REGIT.C and CHKREG.C
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* Choose your own values for these */

#define XOR_PRIME      0xFFFFFFFFL
#define XOR_CRYPT      0x13579ACEL
#define XOR_POST_CRYPT 0x2468BDF0L
