/*
**  Header file for CURSOR.C
*/

#ifndef CURSOR__H
#define CURSOR__H

void cursor(int tmp);

#endif /* CURSOR__H */
