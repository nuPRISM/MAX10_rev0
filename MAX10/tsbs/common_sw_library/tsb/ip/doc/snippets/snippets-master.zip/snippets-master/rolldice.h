/*
**  ROLLDICE.H - SNIPPETS header file for ROLLDICE.C
*/

#ifndef ROLLDICE__H_
#define ROLLDICE__H_

#include <stdlib.h>

char *roll_dice(int d, int s);

#endif /* ROLLDICE__H_ */
