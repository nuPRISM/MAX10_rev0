/*
**  SNIPPETS header file for ISISBN.C
*/

#ifndef ISISBN__H
#define ISISBN__H

int isbn2(char *str);

#endif /* ISISBN__H */
