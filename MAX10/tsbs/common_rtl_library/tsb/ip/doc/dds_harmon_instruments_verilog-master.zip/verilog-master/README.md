verilog
=======

Some smaller Verilog cores used by Harmon Instruments

Documentation is here:
http://harmoninstruments.com/cores/cores.html
---------------------------------------------