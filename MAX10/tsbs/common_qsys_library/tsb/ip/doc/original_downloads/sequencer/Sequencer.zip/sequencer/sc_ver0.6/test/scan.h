#define NSYMS 4000	/* maximum number of symbols */

struct symtab {
	char *name;
	long value;
	long type;
};

struct symtab *symlook();
extern struct symtab symtab[NSYMS];
//extern struct code *code;
// types
#define VARIABLE 0
//#define SYSTEM_SYMBOL 1
//#define BRANCH_CONDITION 2
//#define ADR_LABEL 3
#define RESERVED 4
#define INITIALIZED_VARIABLE 5

struct code {
       long creg;
       long stack;
       long branch;
       long addgen;
       long opcode_data;
       long break_bit;
       unsigned long long int data;
       unsigned long adr; // this is the codes address in memory
       unsigned long line;
       char * name;
};

#define OK 0
#define ERROR 1
