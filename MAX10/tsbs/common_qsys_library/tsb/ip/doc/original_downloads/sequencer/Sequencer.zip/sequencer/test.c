main()
{
	int yyparse();

	return(yyparse());
}
