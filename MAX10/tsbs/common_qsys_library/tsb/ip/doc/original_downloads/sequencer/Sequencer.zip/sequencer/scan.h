#define NSYMS 2000	/* maximum number of symbols */

struct symtab {
	char *name;
	long value;
} symtab[NSYMS];

struct symtab *symlook();
