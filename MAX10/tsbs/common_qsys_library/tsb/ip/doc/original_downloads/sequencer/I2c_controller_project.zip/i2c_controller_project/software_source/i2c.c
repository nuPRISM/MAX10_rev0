// © 2013 Altera Corporation. The material in this wiki page or document is provided AS-IS and is not
// supported by Altera Corporation. Use the material in this document at your own risk; it might be, for example, objectionable,
// misleading or inaccurate.

//code for i2c controller example for the Altera State Sequencer.
// compile this code with with command 
//
// sc.exe eth_std_main_system_state_sequencer_0.shf i2c.c
//
// Basic out line
// This code excersizes the i2c bus. It preformas reads and writes with very little help from a host. 
// the host is reponsible for placing data ( address, write data) in the rx_fifo,
// indicating how many read bytes are needed in the i2c control register, and setting the run bit which set everything into motion
// When the start bit the code check to see if sda is high if not it tries to clock the ics bus a few times to see it will go high
// It also checks to see if the scl is high if it is, it errors out.  
// Once both the scl and sda are high a START bit can be sent. 
// Then the code takes a known device address (DEV__ADDRESS) and tranmits that to the slave. ( If you want to provide that as part
// of the data in the tx_fifo just change first line of code after the do_write_dev_addr: label to be
// 
// SDA_PADOEN | SCL_FORCE_LOW | LOAD_SHIFTER_TX, 
//
// this will pull the first word from the fifo and use it as the device address. 
// After the device address is sent any other bytes in the tx_fifo will be sent. These include address and bytes to be written.
// It is not recomended to do a write of data and a read in the same trasaction-- This is becuase the read pointer will end up and
// the end of the last word written which may not be what was intended. If no reads have been reqested ( bits 7:1 of the control register)
// a STOP will be sent 
// If a number of read bytes has been requested, then the code will do a RESTART, and begin to shift out the bytes requested and 
// and then issue a STOP.
//
// Psuedo code for issuing a write. 
//	write a 1 to the sequencer control register to turn on the sequencer ( if already set, it is not necissary to do it again)
//	(optional) write the device address if you changed the code require it. 
//	write the address(s) to the i2c tx_fifo ( some devices require only an 8 bit addres while others need 2 or 3 bytes)
//  	write the data bits to write.  ( this code is not smart enought to wait between writes -- but you could change it so it would)
//	write a 1 to the i2c contol register. 
// 	(optional) wait for the run bit to clear and then preform another transaction (run bit automatically clears when transactino is complete)
//
// Psuedo code for issuing a read. 
//	write a 1 to the sequencer control register to turn on the sequencer ( if already set, it is not necissary to do it again)
//	(optional) write the device address if you changed the code require it. 
//	write the address(s) to the ix2 tx_fifo ( some devices require only an 8 bit addres while others need 2 or 3 bytes)
//	write the number of bytes to read + the run bit.  ->  (number of bytes)<<1 +1
//		if you wanted to read 4 bytes you would write 0x09 to the i2c control register
// 	(optional) wait for the run bit to clear and then preform another transaction (run bit automatically clears when transactino is complete)

//
// cruben 2-oct-2013 Inital Release 1.0


// set up my definitions


// device address

DEV__ADDRESS = 0xa0;	// this is for the 24lc02 on the terasic THDB-SUM board.


// define the branch conditions.
// these come from the i2c module
RUN = BR0;
READ_REQUESTED = BR1;
TX_EMPTY = BR2;
SCL_PAD	= BR3;
SDA_PAD =BR4;
//BR( is not used


// output definitions "DOITS"
// these goto the i2c module
SCL_FORCE_LOW	 = 0x0001; // force clock low.  Otherwise it is pulled high.
SDA_PADOEN 	 = 0x0002; // output enable for the sda - by default this enabls the shift reg output to be output on SDA
SDA_FORCE_LOW 	 = 0x0004; // force the sda output to be low ( need SDA_PADOEN to be on as well)
SHIFT 		 = 0x0008; // shift in and out or the shift register
CLEAR_RUN	 = 0x0010; // clear the start and stop bits in the control register
LOAD_SHIFTER_IMM = 0x0020; // scl output
LOAD_RX 	 = 0x0040; // load the incoming data from the shift register to the rx_register. 
LOAD_SHIFTER_TX  = 0x0080; // load the shift register from the tx_register. 
NOT_BUSY 	 = 0x0100; //  idle
ERROR		 = 0x0200;  // error bus busy


// now look at the code
// always starts with a main  ( although it is really the first line of code it finds that is important
main:

idle:
    // if run is not set sit here forever.
NOT_BUSY,if(RUN) load 7 else wait; // if the run bit is set load the CREG with 8 and continue otherwise wait.

// first step wait for a command  such as stop start read or write
// check for start
,
 goto do_start;

 
 //*****************************************************//
// do_start
// 	standard i2c start
 // hold clock high and force sda from a high to low transition.
 // if the pullups are in place everything should already be high 
 // if not an error is flagged. 
//*****************************************************//
do_start:
// check to make sure the bus is availible if not throw an error
, if(SCL_PAD==0) goto error;

, if(SDA_PAD==0) goto eightclocks;

SDA_PADOEN | SDA_FORCE_LOW,   // start bit  data low
continue;

SDA_PADOEN | SDA_FORCE_LOW | SCL_FORCE_LOW,// clock low  data low
continue;

SDA_PADOEN | SDA_FORCE_LOW | SCL_FORCE_LOW ,// clock low  data lo
continue;

SDA_PADOEN | SDA_FORCE_LOW | SCL_FORCE_LOW ,// clock low  data lo
goto do_write_dev_addr;


do_rstart:
 SCL_FORCE_LOW ,   // releas sda hold scl low
continue;

,// clk high
continue;

SDA_PADOEN | SDA_FORCE_LOW , // clock high  data lo
continue;

SDA_PADOEN | SDA_FORCE_LOW | SCL_FORCE_LOW , // clock low  data lo
goto do_write_dev_addr;

//*****************************************************//
// do_write_dev_address
// 	this fuction writest the device address 
// 	defined by DEV_ADDRESS
// 	if there are bytes in the tx register it assumes that
// 	write must be preformed 
//	otherwise it is a read. 
//*****************************************************//
do_write_dev_addr:  // write 8 bits
SDA_PADOEN | SCL_FORCE_LOW | LOAD_SHIFTER_IMM, //change to LOAD_SHIFTER_TX if you want to provide the address in the tx_fifo
load DEV__ADDRESS;  // this is a dummy write the creg with the address so I can get it on the bus the actual destination is the shift registere

SDA_PADOEN | SCL_FORCE_LOW , //clk low
load 6;			// do 7 bits the last bit depend on read and write.
dev_write_loop:

SDA_PADOEN | SCL_FORCE_LOW, //clk low
continue;

SDA_PADOEN ,  //clk high
continue;

SDA_PADOEN , // clk high
continue;

SDA_PADOEN | SCL_FORCE_LOW  | SHIFT, //clk low
if(creg!=0) loop  dev_write_loop;

// now for the last bit 1 for a read 0 for a write
// if there is data in the tx fifo then must be a write.
// if tx is empty and READ_REQUESTED is set then it is read time 

SDA_PADOEN | SCL_FORCE_LOW ,
if (TX_EMPTY) goto do_address_read;

SDA_PADOEN | SCL_FORCE_LOW |SDA_FORCE_LOW, //force a write bit
continue;

SDA_PADOEN |SDA_FORCE_LOW, //clk high
continue;

SDA_PADOEN |SDA_FORCE_LOW, //clk high
continue;

SDA_PADOEN | SCL_FORCE_LOW  | SDA_FORCE_LOW, 
continue;

//now wait for the ack bit
SCL_FORCE_LOW , //force a write bit
continue;

, 
continue; //clk high

,   // if you wanted to sample the ack do it here.  
continue;  //clk high

SCL_FORCE_LOW , 
goto do_write;
  
// otherwise address read
do_address_read:
 SCL_FORCE_LOW , //force a read bit
continue;

, 	//clk high
continue;

,         //clk high
continue;

SCL_FORCE_LOW , 
continue;

//now wait for the ack bit
SCL_FORCE_LOW , 
continue;

,   // clk high
continue;

,   // if you wanted to sample the ack do it here.  clk high  
continue;

SCL_FORCE_LOW , 
if(READ_REQUESTED) goto do_read;

// should not get here. do a stop
// which is the next routine so it will automatically go there. 



//*****************************************************//
// do_stop
// 	This preforms the i2c standard stop function 
//*****************************************************//

do_stop:
// check to make sure the bus is availible if not throw an error

 SCL_FORCE_LOW | SDA_PADOEN | SDA_FORCE_LOW ,   // releas sda hold scl low
continue;

SDA_PADOEN | SDA_FORCE_LOW,// clk high
continue;

 SDA_PADOEN | SDA_FORCE_LOW,// clk high
continue;

, //clk high data high// it should get pulled high by the external resister here. 
continue;

 CLEAR_RUN ,   // scl low data high 
goto idle;

//*****************************************************//
// do_read
// 	This reads from the I2c chain until the 
// 	READ_REQUESTED is no longer true. 
//	this acsk everything and does not NACK the last read
//	i dont this is criticle. 
//*****************************************************//


do_read:  // read 8 bits
SCL_FORCE_LOW, 
load 7;

read_loop:
SCL_FORCE_LOW,
continue;

SCL_FORCE_LOW,
continue;

, //clk high
continue;

 SHIFT, //ckl high capture the data
if(creg!=0) loop  read_loop;

SCL_FORCE_LOW | LOAD_RX, //now check t see if more data in tx_registers// shifted in all 8
continue;

SCL_FORCE_LOW, //now check t see if more data in tx_registers// shifted in all 8
continue;

SCL_FORCE_LOW, //now check t see if more data in tx_registers// shifted in all 8
if(READ_REQUESTED==0) goto do_read_no_adk;

// now cyclone for the ack_bit

SCL_FORCE_LOW | SDA_PADOEN | SDA_FORCE_LOW, 
continue;				// if last one do not ack

SDA_PADOEN | SDA_FORCE_LOW, //clk high 
continue;

SDA_PADOEN | SDA_FORCE_LOW, //clk high // if you wnated to look at ack you would do it here. 
continue;

SCL_FORCE_LOW | SDA_PADOEN | SDA_FORCE_LOW, //1
continue;

SCL_FORCE_LOW,
goto  do_read;

do_read_no_adk:
SCL_FORCE_LOW , 
continue;

, //clk high 
continue;

, // clk high // if you wnated to look at ack you would do it here. 
continue;

SCL_FORCE_LOW  , 
continue;

SCL_FORCE_LOW , 
goto do_stop;				

//*****************************************************//
// do_write
// 	This writes until all the chars from the tx_buffer
// 	are used up then it does a stop unless reads are 
//	requested then it does a resatart
//*****************************************************//

do_write:  // write 8 bits
SDA_PADOEN | SCL_FORCE_LOW | LOAD_SHIFTER_TX, //idle
load 7;

write_loop:

SDA_PADOEN | SCL_FORCE_LOW, 
continue;

SDA_PADOEN , //clk high
continue;

SDA_PADOEN, // clock high 
continue;

SDA_PADOEN | SCL_FORCE_LOW  | SHIFT, 
if(creg!=0) loop  write_loop;


// now cyclone for the ack_bit

SCL_FORCE_LOW, //1
continue;

, // clk high 
continue;

, //clk high // if you wnated to look at ack you would do it here. 
continue;

SCL_FORCE_LOW, //1
continue;

SDA_PADOEN | SCL_FORCE_LOW , //now check t see if more data in tx_registers
if(TX_EMPTY==0) loop  do_write;

SDA_PADOEN | SCL_FORCE_LOW , // no more chars do we need to preforma a read?
if(READ_REQUESTED) goto  do_rstart;

SCL_FORCE_LOW | SDA_PADOEN , //if not time to do a stop.
goto do_stop;				// shifted in all 8

//*****************************************************//
// cleare the throat of the I2c devices 
//because something isn't right. sda was being held low. 
// issue a some clocks and wait for the sda line to go high. then take control
//*****************************************************//
eightclocks:
  // write 8 bits
SCL_FORCE_LOW,
load 7;

eightclocks_loop:

SCL_FORCE_LOW, 
continue;

, // clk high 
continue;

, // clk high 
continue;

SCL_FORCE_LOW, //watch for sda to go high
if(SDA_PAD) goto do_stop;

SCL_FORCE_LOW, 
if(creg!=0) loop  eightclocks_loop;

SCL_FORCE_LOW, 
goto do_stop;


// if erro rset the error bit.
error:
ERROR | CLEAR_RUN, goto idle;
