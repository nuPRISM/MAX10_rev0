echo
echo compiling. 
echo a.out i2c_controller_state_sequencer_0.shf  i2c.c
a.out i2c_controller_state_sequencer_0.shf  i2c.c
cp i2c_controller_state_sequencer_0_instr_ram_packed.hex ../../../../
echo 
echo copying
echo i2c_controller_state_sequencer_0_instr_ram_packed.hex ../../../../
echo
echo updating mif file
echo
pushd ../../../../
#echo quartus_cdb niosii_ethernet_standard_3c120 -c niosii_ethernet_standard_3c120 --update_mif
#quartus_cdb niosii_ethernet_standard_3c120 -c niosii_ethernet_standard_3c120 --update_mif
#echo quartus_asm --read_settings_files=on --write_settings_files=off niosii_ethernet_standard_3c120 -c niosii_ethernet_standard_3c120
#quartus_asm --read_settings_files=on --write_settings_files=off niosii_ethernet_standard_3c120 -c niosii_ethernet_standard_3c120
#quartus_map --read_settings_files=on --write_settings_files=off niosii_ethernet_standard_3c120 -c niosii_ethernet_standard_3c120

popd
echo done
echo