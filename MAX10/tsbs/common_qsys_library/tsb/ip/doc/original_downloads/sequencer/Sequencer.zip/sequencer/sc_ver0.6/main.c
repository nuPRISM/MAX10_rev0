#include   "y.tab.h"
main()
{
	int yyparse();

	return(yyparse());
//	while( 
//		yylex());
}
