/* A Bison parser, made by GNU Bison 2.6.1.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2012 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_Y_TAB_H
# define YY_Y_TAB_H
/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     LEFT_OP = 258,
     RIGHT_OP = 259,
     EQ_OP = 260,
     NE_OP = 261,
     DEVICE = 262,
     CONTINUE = 263,
     DEC = 264,
     STACK = 265,
     CREG = 266,
     LOAD = 267,
     WAIT = 268,
     THEN = 269,
     PUSH = 270,
     POP = 271,
     TO = 272,
     FROM = 273,
     LOOP = 274,
     GOSUB = 275,
     ADDRESS = 276,
     PREPROCESSOR = 277,
     COMPILER = 278,
     PNAME = 279,
     PNUMBER = 280,
     ORG = 281,
     BRANCH_CONDITION = 282,
     DEFAULT = 283,
     IF = 284,
     ELSE = 285,
     WHILE = 286,
     GOTO = 287,
     RETURN = 288,
     NAME = 289,
     ADR_LABEL = 290,
     SYSTEM_SYMBOL = 291,
     PLABEL = 292,
     PROJECT_NAME = 293,
     DATA_IN = 294,
     NUMBER = 295,
     DEFAULT_OUT = 296,
     UMINUS = 297
   };
#endif
/* Tokens.  */
#define LEFT_OP 258
#define RIGHT_OP 259
#define EQ_OP 260
#define NE_OP 261
#define DEVICE 262
#define CONTINUE 263
#define DEC 264
#define STACK 265
#define CREG 266
#define LOAD 267
#define WAIT 268
#define THEN 269
#define PUSH 270
#define POP 271
#define TO 272
#define FROM 273
#define LOOP 274
#define GOSUB 275
#define ADDRESS 276
#define PREPROCESSOR 277
#define COMPILER 278
#define PNAME 279
#define PNUMBER 280
#define ORG 281
#define BRANCH_CONDITION 282
#define DEFAULT 283
#define IF 284
#define ELSE 285
#define WHILE 286
#define GOTO 287
#define RETURN 288
#define NAME 289
#define ADR_LABEL 290
#define SYSTEM_SYMBOL 291
#define PLABEL 292
#define PROJECT_NAME 293
#define DATA_IN 294
#define NUMBER 295
#define DEFAULT_OUT 296
#define UMINUS 297



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{
/* Line 2049 of yacc.c  */
#line 58 "gram.y"

	long val;
	struct symtab *symp;


/* Line 2049 of yacc.c  */
#line 147 "y.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */

#endif /* !YY_Y_TAB_H  */
