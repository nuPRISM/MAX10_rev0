typedef union {
	long val;
	struct symtab *symp;
} YYSTYPE;
#define	IDENTIFIER	258
#define	CONSTANT	259
#define	STRING_LITERAL	260
#define	SIZEOF	261
#define	EQ_OP	262
#define	NE_OP	263
#define	DEFAULT_OUT	264
#define	DEVICE	265
#define	PL	266
#define	CONTINUE	267
#define	DEC	268
#define	STACK	269
#define	CREG	270
#define	LOAD	271
#define	WAIT	272
#define	THEN	273
#define	TM	274
#define	PUSH	275
#define	POP	276
#define	TO	277
#define	FROM	278
#define	LOOP	279
#define	ADDR	280
#define	GOSUB	281
#define	IF	282
#define	ELSE	283
#define	WHILE	284
#define	GOTO	285
#define	RETURN	286
#define	NAME	287
#define	LABEL	288
#define	DATA_IN	289
#define	NUMBER	290
#define	UMINUS	291


extern YYSTYPE yylval;
