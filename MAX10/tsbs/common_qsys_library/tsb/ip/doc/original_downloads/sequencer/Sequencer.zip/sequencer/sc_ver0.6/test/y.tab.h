/* A Bison parser, made by GNU Bison 2.6.1.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2012 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_Y_TAB_H
# define YY_Y_TAB_H
/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     LEFT_OP = 258,
     RIGHT_OP = 259,
     EQ_OP = 260,
     NE_OP = 261,
     BREAK = 262,
     DEVICE = 263,
     DEC = 264,
     STACK = 265,
     CREG = 266,
     LOAD = 267,
     WAIT = 268,
     THEN = 269,
     PUSH = 270,
     POP = 271,
     TO = 272,
     FROM = 273,
     LOOP = 274,
     GOSUB = 275,
     ADDRESS = 276,
     PREPROCESSOR = 277,
     COMPILER = 278,
     PNUMBER = 279,
     ORG = 280,
     DEFAULT = 281,
     IF = 282,
     ELSE = 283,
     WHILE = 284,
     GOTO = 285,
     CONTINUE = 286,
     RETURN = 287,
     NAME = 288,
     BRANCH_CONDITION = 289,
     ADR_LABEL = 290,
     PNAME = 291,
     SYSTEM_SYMBOL = 292,
     PLABEL = 293,
     PROJECT_NAME = 294,
     DATA_IN = 295,
     NUMBER = 296,
     DEFAULT_OUT = 297,
     UMINUS = 298
   };
#endif
/* Tokens.  */
#define LEFT_OP 258
#define RIGHT_OP 259
#define EQ_OP 260
#define NE_OP 261
#define BREAK 262
#define DEVICE 263
#define DEC 264
#define STACK 265
#define CREG 266
#define LOAD 267
#define WAIT 268
#define THEN 269
#define PUSH 270
#define POP 271
#define TO 272
#define FROM 273
#define LOOP 274
#define GOSUB 275
#define ADDRESS 276
#define PREPROCESSOR 277
#define COMPILER 278
#define PNUMBER 279
#define ORG 280
#define DEFAULT 281
#define IF 282
#define ELSE 283
#define WHILE 284
#define GOTO 285
#define CONTINUE 286
#define RETURN 287
#define NAME 288
#define BRANCH_CONDITION 289
#define ADR_LABEL 290
#define PNAME 291
#define SYSTEM_SYMBOL 292
#define PLABEL 293
#define PROJECT_NAME 294
#define DATA_IN 295
#define NUMBER 296
#define DEFAULT_OUT 297
#define UMINUS 298



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{
/* Line 2049 of yacc.c  */
#line 58 "gram.y"

	long val;
	struct symtab *symp;


/* Line 2049 of yacc.c  */
#line 149 "y.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */

#endif /* !YY_Y_TAB_H  */
