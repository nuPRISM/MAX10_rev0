
/*  A Bison parser, made from gram.y
 by  GNU Bison version 1.25
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	LEFT_OP	258
#define	RIGHT_OP	259
#define	EQ_OP	260
#define	NE_OP	261
#define	DEVICE	262
#define	CONTINUE	263
#define	DEC	264
#define	STACK	265
#define	CREG	266
#define	LOAD	267
#define	WAIT	268
#define	THEN	269
#define	PUSH	270
#define	POP	271
#define	TO	272
#define	FROM	273
#define	LOOP	274
#define	GOSUB	275
#define	ADDRESS	276
#define	PREPROCESSOR	277
#define	COMPILER	278
#define	PNAME	279
#define	PNUMBER	280
#define	ORG	281
#define	BRANCH_CONDITION	282
#define	DEFAULT	283
#define	IF	284
#define	ELSE	285
#define	WHILE	286
#define	GOTO	287
#define	RETURN	288
#define	NAME	289
#define	ADR_LABEL	290
#define	SYSTEM_SYMBOL	291
#define	PLABEL	292
#define	PROJECT_NAME	293
#define	DATA_IN	294
#define	NUMBER	295
#define	DEFAULT_OUT	296
#define	UMINUS	297

#line 1 "gram.y"

/*
Copyright �2003 Altera Corporation, San Jose, California, USA. All rights reserved.
Permission is hereby granted, free of charge, to any person obtaining a copy of this 
software and associated documentation files (the "Software"), to deal in the Software 
without restriction, including without limitation the rights to use, copy, modify, 
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
permit persons to whom the Software is furnished to do so, subject to the following 
conditions:

The above copyright notice and this permission notice shall be included in all copies 
or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE 
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
DEALINGS IN THE SOFTWARE.

This agreement shall be governed in all respects by the laws of the State of California 
and by the laws of the United States of America.

*/
#include <stdio.h>
#include <string.h>
#include "scan.h"
//extern char yytext[];
extern int column;
extern int lineno;
extern char linebuf[];
extern long code_address;
extern int error_count;
extern char * project_name;
int output_record(struct code * c);
struct symtab *sp;
struct code the_code;
char error[100];
int clear_the_code(struct code* ptr);
int fix_the_code(struct code* ptr);
int check_stack_opcode(struct code* ptr);
int check_data_opcode(struct code* ptr, int x);
int check_creg_opcode(struct code* ptr);
int check_addgen_opcode(struct code* ptr);
#define YYDEBUG 1
//	yydebug=1;

#line 58 "gram.y"
typedef union {
	long val;
	struct symtab *symp;
} YYSTYPE;
#ifndef YYDEBUG
#define YYDEBUG 1
#endif

#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		181
#define	YYFLAG		-32768
#define	YYNTBASE	55

#define YYTRANSLATE(x) ((unsigned)(x) <= 297 ? yytranslate[x] : 80)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,    47,     2,    53,
    54,    44,    43,    49,    42,     2,    45,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,    52,    50,     2,
    51,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,    46,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    48
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     3,     6,     8,    11,    13,    16,    21,    26,    31,
    36,    41,    44,    49,    53,    57,    61,    65,    69,    73,
    76,    80,    82,    84,    86,    89,    91,    93,    95,    97,
    99,   102,   107,   113,   118,   123,   128,   134,   140,   145,
   151,   156,   161,   166,   171,   176,   178,   181,   182,   185,
   190,   191,   193,   195,   199,   205,   208,   213,   216,   219,
   222,   225,   228,   231,   234,   237,   240,   243,   246,   249,
   252,   255,   258,   262,   266,   270,   274,   278,   282,   285,
   289,   291,   293,   295,   296,   302,   304,   308,   312,   316,
   320,   322,   324,   325
};

static const short yyrhs[] = {    22,
    56,     0,    23,    60,     0,    57,     0,    56,    57,     0,
    58,     0,    49,    50,     0,    38,    51,    24,    50,     0,
    27,    51,    25,    50,     0,    24,    51,    27,    50,     0,
    24,    51,    59,    50,     0,    36,    51,    59,    50,     0,
    37,    52,     0,    26,    52,    59,    50,     0,    59,    43,
    59,     0,    59,    42,    59,     0,    59,    46,    59,     0,
    59,    47,    59,     0,    59,    44,    59,     0,    59,    45,
    59,     0,    42,    59,     0,    53,    59,    54,     0,    25,
     0,    24,     0,    61,     0,    60,    61,     0,    63,     0,
    64,     0,    65,     0,    66,     0,    62,     0,    35,    52,
     0,    41,    51,    76,    50,     0,     7,    53,    76,    54,
    50,     0,    34,    51,    76,    50,     0,    27,    51,    27,
    50,     0,    27,    51,    40,    50,     0,    67,    77,    72,
    68,    50,     0,    67,    77,    73,    68,    50,     0,    67,
    77,    68,    50,     0,    67,    77,    75,    68,    50,     0,
    67,    77,     9,    50,     0,    67,    77,    71,    50,     0,
    67,    77,    70,    50,     0,    67,    77,    33,    50,     0,
    67,    77,    74,    50,     0,    49,     0,    76,    49,     0,
     0,    30,    13,     0,    30,    13,    31,    11,     0,     0,
    17,     0,    16,     0,    16,    69,    11,     0,    16,    69,
    53,    11,    54,     0,    15,    11,     0,    15,    53,    11,
    54,     0,    15,    76,     0,    15,    39,     0,    15,    21,
     0,    32,    39,     0,    32,    10,     0,    32,    76,     0,
    20,    39,     0,    20,    10,     0,    20,    76,     0,    19,
    39,     0,    19,    10,     0,    19,    76,     0,    12,    39,
     0,    12,    10,     0,    12,    76,     0,    76,    43,    76,
     0,    76,    42,    76,     0,    76,    46,    76,     0,    76,
    47,    76,     0,    76,    44,    76,     0,    76,    45,    76,
     0,    42,    76,     0,    53,    76,    54,     0,    40,     0,
    34,     0,    35,     0,     0,    29,    53,    78,    54,    79,
     0,     8,     0,    11,     6,    76,     0,    11,     5,    76,
     0,    27,     6,    76,     0,    27,     5,    76,     0,    27,
     0,    11,     0,     0,    14,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
    89,    90,    92,    93,    95,    97,    98,   102,   104,   105,
   108,   110,   114,   121,   122,   123,   124,   125,   126,   132,
   133,   134,   135,   146,   147,   150,   151,   152,   153,   159,
   162,   168,   172,   175,   176,   177,   180,   183,   185,   196,
   198,   204,   205,   206,   211,   214,   215,   218,   219,   225,
   238,   239,   242,   247,   253,   260,   265,   269,   275,   279,
   284,   289,   293,   301,   308,   313,   322,   331,   339,   350,
   354,   357,   364,   365,   366,   367,   368,   369,   375,   376,
   377,   378,   384,   387,   388,   390,   394,   406,   417,   428,
   441,   444,   449,   450
};
#endif


#if YYDEBUG != 0 || defined (YYERROR_VERBOSE)

static const char * const yytname[] = {   "$","error","$undefined.","LEFT_OP",
"RIGHT_OP","EQ_OP","NE_OP","DEVICE","CONTINUE","DEC","STACK","CREG","LOAD","WAIT",
"THEN","PUSH","POP","TO","FROM","LOOP","GOSUB","ADDRESS","PREPROCESSOR","COMPILER",
"PNAME","PNUMBER","ORG","BRANCH_CONDITION","DEFAULT","IF","ELSE","WHILE","GOTO",
"RETURN","NAME","ADR_LABEL","SYSTEM_SYMBOL","PLABEL","PROJECT_NAME","DATA_IN",
"NUMBER","DEFAULT_OUT","'-'","'+'","'*'","'/'","'|'","'&'","UMINUS","','","';'",
"'='","':'","'('","')'","combined","preprossesor_grammer_list","preprossesor_grammer",
"p_any_line","pexpression","sequencer_grammer_list","sequencer_grammer","the_label",
"default_expr","device_expr","assign_statement","statement","begin_expression",
"else_wait","to","pop_state","push_state","goto_state","gosub_state","loop_state",
"load_state","expression","if_condition","cond","then", NULL
};
#endif

static const short yyr1[] = {     0,
    55,    55,    56,    56,    57,    58,    58,    58,    58,    58,
    58,    58,    58,    59,    59,    59,    59,    59,    59,    59,
    59,    59,    59,    60,    60,    61,    61,    61,    61,    61,
    62,    63,    64,    65,    65,    65,    66,    66,    66,    66,
    66,    66,    66,    66,    66,    67,    67,    68,    68,    68,
    69,    69,    70,    70,    70,    71,    71,    71,    71,    71,
    72,    72,    72,    73,    73,    73,    74,    74,    74,    75,
    75,    75,    76,    76,    76,    76,    76,    76,    76,    76,
    76,    76,    76,    77,    77,    77,    78,    78,    78,    78,
    78,    78,    79,    79
};

static const short yyr2[] = {     0,
     2,     2,     1,     2,     1,     2,     4,     4,     4,     4,
     4,     2,     4,     3,     3,     3,     3,     3,     3,     2,
     3,     1,     1,     1,     2,     1,     1,     1,     1,     1,
     2,     4,     5,     4,     4,     4,     5,     5,     4,     5,
     4,     4,     4,     4,     4,     1,     2,     0,     2,     4,
     0,     1,     1,     3,     5,     2,     4,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     3,     3,     3,     3,     3,     3,     2,     3,
     1,     1,     1,     0,     5,     1,     3,     3,     3,     3,
     1,     1,     0,     1
};

static const short yydefact[] = {     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     1,
     3,     5,     0,     0,    82,    83,    81,     0,     0,    46,
     0,     2,    24,    30,    26,    27,    28,    29,    84,     0,
     0,     0,     0,     0,    12,     0,     6,     4,     0,     0,
     0,    31,     0,    82,    83,    79,     0,    25,    86,     0,
    48,     0,     0,     0,     0,     0,     0,    47,    23,    22,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    80,     0,     0,     0,     0,    51,     0,
     0,     0,     0,     0,     0,     0,     0,    48,    48,     0,
    48,    74,    73,    77,    78,    75,    76,     9,    20,     0,
     0,     0,     0,     0,     0,     0,    10,    13,     8,    11,
     7,     0,    35,    36,    34,    32,    92,    91,     0,    41,
    71,    70,    72,    56,    60,    59,     0,    58,    52,     0,
    68,    67,    69,    65,    64,    66,    49,    62,    61,    63,
    44,    39,    43,    42,     0,     0,    45,     0,    21,    15,
    14,    18,    19,    16,    17,    33,     0,     0,     0,     0,
    93,     0,    54,     0,     0,    37,    38,    40,    88,    87,
    90,    89,    94,    85,    57,     0,    50,    55,     0,     0,
     0
};

static const short yydefgoto[] = {   179,
    10,    11,    12,    64,    22,    23,    24,    25,    26,    27,
    28,    29,    85,   130,    86,    87,    88,    89,    90,    91,
    30,    51,   119,   174
};

static const short yypact[] = {    28,
   119,    14,   -43,   -39,   -35,   -26,   -10,   -24,     7,   119,
-32768,-32768,     0,     9,    18,    35,-32768,    37,   -25,-32768,
   -25,    14,-32768,-32768,-32768,-32768,-32768,-32768,    -3,   194,
   -13,    41,    71,    41,-32768,    75,-32768,-32768,   -25,     3,
   -25,-32768,   -25,-32768,-32768,-32768,   107,-32768,-32768,    48,
   150,   -25,   -25,   -25,   -25,   -25,   -25,-32768,-32768,-32768,
    53,    41,    41,   149,   158,    57,   167,    65,   130,    67,
    72,   176,   185,-32768,    -4,    74,    42,    95,   -11,    58,
    70,   114,    79,    78,    86,    92,    97,    90,    90,   108,
    90,   206,   206,   -28,   -28,-32768,-32768,-32768,-32768,   143,
    41,    41,    41,    41,    41,    41,-32768,-32768,-32768,-32768,
-32768,   110,-32768,-32768,-32768,-32768,    73,    80,   109,-32768,
-32768,-32768,   202,-32768,-32768,-32768,    91,   202,-32768,    -7,
-32768,-32768,   202,-32768,-32768,   202,   133,-32768,-32768,   202,
-32768,-32768,-32768,-32768,   117,   121,-32768,   128,-32768,   210,
   210,    44,    44,-32768,-32768,-32768,   -25,   -25,   -25,   -25,
   165,   127,-32768,   187,   195,-32768,-32768,-32768,   202,   202,
   202,   202,-32768,-32768,-32768,   153,-32768,-32768,   215,   216,
-32768
};

static const short yypgoto[] = {-32768,
-32768,   214,-32768,   -31,-32768,   203,-32768,-32768,-32768,-32768,
-32768,-32768,   -44,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
   -19,-32768,-32768,-32768
};


#define	YYLAST		257


static const short yytable[] = {    46,
    65,    47,    67,   163,    49,   129,   117,    31,    44,    45,
    59,    60,    32,    61,    17,    33,    19,    56,    57,    69,
    13,    72,   118,    73,    34,    50,    36,    21,    62,    70,
    99,   100,    92,    93,    94,    95,    96,    97,   -53,    63,
    14,    35,    71,   145,   146,   164,   148,    15,    16,     1,
     2,   121,    39,    17,    18,    19,    37,   123,   128,    40,
   133,   136,    20,   140,    59,    60,    21,   131,    41,   150,
   151,   152,   153,   154,   155,    44,    45,   157,   158,   134,
   122,    17,    62,    19,   159,   160,    42,    43,   138,   105,
   106,    44,    45,    63,    21,    66,   132,    17,    68,    19,
    75,   162,    98,    44,    45,   124,   109,    47,   135,    17,
    21,    19,    44,    45,   111,   125,   113,   139,    17,    82,
    19,   114,    21,   120,    44,    45,   137,   141,    44,    45,
    17,    21,    19,   126,    17,   142,    19,   169,   170,   171,
   172,   143,     3,    21,     4,     5,   144,   127,    52,    53,
    54,    55,    56,    57,     6,     7,     8,   147,    76,   156,
    74,    77,   161,   165,    78,    79,   166,     9,    80,    81,
   167,    52,    53,    54,    55,    56,    57,   168,   173,    82,
   175,    83,    84,   112,   101,   102,   103,   104,   105,   106,
   101,   102,   103,   104,   105,   106,   149,   176,   107,   101,
   102,   103,   104,   105,   106,   177,   178,   108,   101,   102,
   103,   104,   105,   106,   180,   181,   110,    52,    53,    54,
    55,    56,    57,    38,    48,   115,    52,    53,    54,    55,
    56,    57,     0,     0,   116,    52,    53,    54,    55,    56,
    57,     0,    58,    52,    53,    54,    55,    56,    57,    54,
    55,    56,    57,   103,   104,   105,   106
};

static const short yycheck[] = {    19,
    32,    21,    34,    11,     8,    17,    11,    51,    34,    35,
    24,    25,    52,    27,    40,    51,    42,    46,    47,    39,
     7,    41,    27,    43,    51,    29,    51,    53,    42,    27,
    62,    63,    52,    53,    54,    55,    56,    57,    50,    53,
    27,    52,    40,    88,    89,    53,    91,    34,    35,    22,
    23,    10,    53,    40,    41,    42,    50,    77,    78,    51,
    80,    81,    49,    83,    24,    25,    53,    10,    51,   101,
   102,   103,   104,   105,   106,    34,    35,     5,     6,    10,
    39,    40,    42,    42,     5,     6,    52,    51,    10,    46,
    47,    34,    35,    53,    53,    25,    39,    40,    24,    42,
    53,    11,    50,    34,    35,    11,    50,   127,    39,    40,
    53,    42,    34,    35,    50,    21,    50,    39,    40,    30,
    42,    50,    53,    50,    34,    35,    13,    50,    34,    35,
    40,    53,    42,    39,    40,    50,    42,   157,   158,   159,
   160,    50,    24,    53,    26,    27,    50,    53,    42,    43,
    44,    45,    46,    47,    36,    37,    38,    50,     9,    50,
    54,    12,    54,    31,    15,    16,    50,    49,    19,    20,
    50,    42,    43,    44,    45,    46,    47,    50,    14,    30,
    54,    32,    33,    54,    42,    43,    44,    45,    46,    47,
    42,    43,    44,    45,    46,    47,    54,    11,    50,    42,
    43,    44,    45,    46,    47,    11,    54,    50,    42,    43,
    44,    45,    46,    47,     0,     0,    50,    42,    43,    44,
    45,    46,    47,    10,    22,    50,    42,    43,    44,    45,
    46,    47,    -1,    -1,    50,    42,    43,    44,    45,    46,
    47,    -1,    49,    42,    43,    44,    45,    46,    47,    44,
    45,    46,    47,    44,    45,    46,    47
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/share/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(TO,FROM,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (to, from, count)
     char *to;
     char *from;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *to, char *from, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 196 "/usr/share/bison.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#ifdef __cplusplus
#define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else /* not __cplusplus */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#endif /* not __cplusplus */
#else /* not YYPARSE_PARAM */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif /* not YYPARSE_PARAM */

int
yyparse(YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss, (char *)yyss1, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs, (char *)yyvs1, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls, (char *)yyls1, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 89 "gram.y"
{clear_the_code(&the_code);;
    break;}
case 4:
#line 93 "gram.y"
{yyval.val= 0;;
    break;}
case 5:
#line 95 "gram.y"
{yyval.val=1;;
    break;}
case 6:
#line 97 "gram.y"
{code_address++;;
    break;}
case 7:
#line 98 "gram.y"
{ project_name =   (char*)strdup(yyvsp[-1].symp->name);
                                         yyvsp[-1].symp->type = PROJECT_NAME;
                                         printf("\nProject -> %s\n",project_name);;
    break;}
case 8:
#line 102 "gram.y"
{yyvsp[-3].symp->value = yyvsp[-1].val;;
    break;}
case 9:
#line 104 "gram.y"
{yyvsp[-3].symp->value=yyvsp[-1].symp->value;yyvsp[-3].symp->type=yyvsp[-1].symp->type;;
    break;}
case 10:
#line 105 "gram.y"
{yyvsp[-3].symp->value =yyvsp[-1].val; 
                                       if( yyvsp[-3].symp->type != SYSTEM_SYMBOL)
                                           yyvsp[-3].symp->type = INITIALIZED_VARIABLE;;
    break;}
case 11:
#line 108 "gram.y"
{yyvsp[-3].symp->value =yyvsp[-1].val;;
    break;}
case 12:
#line 110 "gram.y"
{
                      yyvsp[-1].symp->value = code_address;
                      yyvsp[-1].symp->type = ADR_LABEL;
                     ;
    break;}
case 13:
#line 114 "gram.y"
{
                      code_address = yyvsp[-1].val;
                     ;
    break;}
case 14:
#line 121 "gram.y"
{ yyval.val = yyvsp[-2].val + yyvsp[0].val; ;
    break;}
case 15:
#line 122 "gram.y"
{ yyval.val = yyvsp[-2].val - yyvsp[0].val; ;
    break;}
case 16:
#line 123 "gram.y"
{ yyval.val = yyvsp[-2].val | yyvsp[0].val; ;
    break;}
case 17:
#line 124 "gram.y"
{ yyval.val = yyvsp[-2].val & yyvsp[0].val; ;
    break;}
case 18:
#line 125 "gram.y"
{ yyval.val = yyvsp[-2].val * yyvsp[0].val; ;
    break;}
case 19:
#line 127 "gram.y"
{	if(yyvsp[0].val == 0.0)
						yyerror("divide by zero");
					else
						yyval.val = yyvsp[-2].val / yyvsp[0].val;
				;
    break;}
case 20:
#line 132 "gram.y"
{ yyval.val = -yyvsp[0].val; ;
    break;}
case 21:
#line 133 "gram.y"
{ yyval.val = yyvsp[-1].val; ;
    break;}
case 23:
#line 135 "gram.y"
{   if (yyvsp[0].symp->type == VARIABLE)
	                                    {
	                                       sprintf(error,"The symbol %s is not initialized",yyvsp[0].symp->name);
                                               yyerror(error);
                                             }
                                             yyval.val = yyvsp[0].symp->value; ;
    break;}
case 26:
#line 150 "gram.y"
{yyval.val = 0;;
    break;}
case 27:
#line 151 "gram.y"
{yyval.val = 1;;
    break;}
case 28:
#line 152 "gram.y"
{yyval.val = 2;;
    break;}
case 29:
#line 153 "gram.y"
{yyval.val = 3; the_code.adr=code_address;
	                         the_code.line = lineno;
	                         fix_the_code(&the_code);
                                output_record(&the_code);
                                code_address++;
                                clear_the_code(&the_code);;
    break;}
case 30:
#line 159 "gram.y"
{yyval.val = 4;;
    break;}
case 31:
#line 162 "gram.y"
{yyval.symp= yyvsp[-1].symp ;
                        /*printf("label %d",$1->value);*/
                     /* do nothing this was handeled in the preprocessor stage*/;
    break;}
case 32:
#line 168 "gram.y"
{yyval.val=yyvsp[-3].val = yyvsp[-1].val; /*printf("\n** Parsed a default_expr %d**\n",DEFAULT);*/;
    break;}
case 33:
#line 172 "gram.y"
{/*printf("\n** Parsed a device_expr (value = %d) **\n",$3);*/;
    break;}
case 34:
#line 175 "gram.y"
{ /* nothing to do handeled in the pre processor*/ ;
    break;}
case 35:
#line 176 "gram.y"
{/* nothing to do handeled in the pre processor*/;
    break;}
case 36:
#line 177 "gram.y"
{/* nothing to do hangeled in the pre processor*/;
    break;}
case 37:
#line 181 "gram.y"
{;
    break;}
case 38:
#line 183 "gram.y"
{;
    break;}
case 39:
#line 185 "gram.y"
{
                                                                     if(yyvsp[-1].val==0)
                                                                     {
                                                                       the_code.branch=yyval.val=symlook("__opcode_branch_default_pass")->value;
                                                                       the_code.addgen = symlook("__opcode_addgen_continue")->value ;
                                                                       the_code.opcode_data = 0;
                                                                       the_code.creg =  symlook("__opcode_creg_nop")->value;
                                                                       the_code.stack=  symlook("__opcode_stack_nop")->value;
                                                                     }
                                                                ;
    break;}
case 40:
#line 196 "gram.y"
{;
    break;}
case 41:
#line 198 "gram.y"
{// DEC only
                                                                     the_code.addgen = symlook("__opcode_addgen_continue")->value ;
                                                                     the_code.opcode_data = 0;
                                                                     the_code.creg = symlook("__opcode_creg_dec")->value;
                                                                     the_code.stack=  symlook("__opcode_stack_nop")->value;
                                                                  ;
    break;}
case 42:
#line 204 "gram.y"
{;
    break;}
case 43:
#line 205 "gram.y"
{   ;
    break;}
case 44:
#line 206 "gram.y"
{the_code.addgen = symlook("__opcode_addgen_stack")->value ;
                                                                     the_code.opcode_data = 0;
                                                                     the_code.creg =  symlook("__opcode_creg_nop")->value;
                                                                     the_code.stack=  symlook("__opcode_stack_pop")->value;
                                                                     ;
    break;}
case 45:
#line 211 "gram.y"
{ ;
    break;}
case 46:
#line 214 "gram.y"
{the_code.data = 0; /*printf("no expression");*/;
    break;}
case 47:
#line 215 "gram.y"
{the_code.data = yyvsp[-1].val;;
    break;}
case 48:
#line 218 "gram.y"
{yyval.val=0;;
    break;}
case 49:
#line 219 "gram.y"
{yyval.val=1;
                            if(the_code.addgen==-1)  // if they have never been filled don't or
                                the_code.addgen = symlook("__opcode_addgen_wait")->value;
                            else
                                the_code.addgen |= symlook("__opcode_addgen_wait")->value;
                        ;
    break;}
case 50:
#line 225 "gram.y"
{yyval.val=2;
                            if(the_code.addgen==-1)  // if they have never been filled don't or
                                the_code.addgen = symlook("__opcode_addgen_wait_creg")->value;
                            else
                                the_code.addgen |= symlook("__opcode_addgen_wait_creg")->value;

                           if(the_code.creg==-1)
                                the_code.creg =  symlook("__opcode_creg_decn")->value;
                           else
                                the_code.creg |=  symlook("__opcode_creg_decn")->value;
                        ;
    break;}
case 53:
#line 243 "gram.y"
{
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_pop")->value;
                        ;
    break;}
case 54:
#line 247 "gram.y"
{
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_pop")->value;
                              if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_load_stack")->value;
                        ;
    break;}
case 55:
#line 253 "gram.y"
{
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_pop")->value;
                              if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_load_stack")->value;
                        ;
    break;}
case 56:
#line 261 "gram.y"
{
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_push_creg")->value;
                        ;
    break;}
case 57:
#line 265 "gram.y"
{
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_push_creg")->value;
                        ;
    break;}
case 58:
#line 269 "gram.y"
{
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_push_data")->value;
                                if(check_data_opcode(&the_code,yyvsp[0].val)==OK)
                                  the_code.opcode_data = yyvsp[0].val;
                        ;
    break;}
case 59:
#line 275 "gram.y"
{
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_push_edata")->value;
                        ;
    break;}
case 60:
#line 279 "gram.y"
{
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_push_address")->value;
                        ;
    break;}
case 61:
#line 285 "gram.y"
{yyval.val=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_edata")->value;
                ;
    break;}
case 62:
#line 289 "gram.y"
{yyval.val=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_stack")->value;
                ;
    break;}
case 63:
#line 293 "gram.y"
{yyval.val=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_data")->value;
                              if(check_data_opcode(&the_code,yyvsp[0].val)==OK)
                                  the_code.opcode_data = yyvsp[0].val;
                            ;
    break;}
case 64:
#line 302 "gram.y"
{yyval.val=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_edata")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_push_address")->value;
                              ;
    break;}
case 65:
#line 308 "gram.y"
{yyval.val=0;if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_stack")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_push_address")->value;
                              ;
    break;}
case 66:
#line 313 "gram.y"
{yyval.val=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_data")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_push_address")->value;
                              if(check_data_opcode(&the_code,yyvsp[0].val)==OK)
                                  the_code.opcode_data = yyvsp[0].val;
                              ;
    break;}
case 67:
#line 323 "gram.y"
{yyval.val=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_edata")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_nop")->value;
                              if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_dec")->value;
                              ;
    break;}
case 68:
#line 331 "gram.y"
{yyval.val=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_stack")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_nop")->value;
                              if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_dec")->value;
                              ;
    break;}
case 69:
#line 339 "gram.y"
{yyval.val=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_data")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_nop")->value;
                              if(check_data_opcode(&the_code,yyvsp[0].val)==OK)
                                  the_code.opcode_data = yyvsp[0].val;
                              if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_dec")->value;
                            ;
    break;}
case 70:
#line 351 "gram.y"
{      if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_load_edata")->value;
                        ;
    break;}
case 71:
#line 354 "gram.y"
{      if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_load_stack")->value;
                        ;
    break;}
case 72:
#line 357 "gram.y"
{  if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_load_data")->value;
                              if(check_data_opcode(&the_code,yyvsp[0].val)==OK)
                                  the_code.opcode_data = yyvsp[0].val;
                            ;
    break;}
case 73:
#line 364 "gram.y"
{ yyval.val = yyvsp[-2].val + yyvsp[0].val; ;
    break;}
case 74:
#line 365 "gram.y"
{ yyval.val = yyvsp[-2].val - yyvsp[0].val; ;
    break;}
case 75:
#line 366 "gram.y"
{ yyval.val = yyvsp[-2].val | yyvsp[0].val; ;
    break;}
case 76:
#line 367 "gram.y"
{ yyval.val = yyvsp[-2].val & yyvsp[0].val; ;
    break;}
case 77:
#line 368 "gram.y"
{ yyval.val = yyvsp[-2].val * yyvsp[0].val; ;
    break;}
case 78:
#line 370 "gram.y"
{	if(yyvsp[0].val == 0.0)
						yyerror("divide by zero");
					else
						yyval.val = yyvsp[-2].val / yyvsp[0].val;
				;
    break;}
case 79:
#line 375 "gram.y"
{ yyval.val = -yyvsp[0].val; ;
    break;}
case 80:
#line 376 "gram.y"
{ yyval.val = yyvsp[-1].val; ;
    break;}
case 82:
#line 378 "gram.y"
{   if (yyvsp[0].symp->type == VARIABLE)
	                                    {
	                                       sprintf(error,"The symbol %s is not initialized",yyvsp[0].symp->name);
                                               yyerror(error);
                                             }
                                             yyval.val = yyvsp[0].symp->value; ;
    break;}
case 83:
#line 384 "gram.y"
{ yyval.val = yyvsp[0].symp->value; ;
    break;}
case 84:
#line 387 "gram.y"
{the_code.branch=yyval.val=symlook("__opcode_branch_default_pass")->value;;
    break;}
case 85:
#line 388 "gram.y"
{ yyval.val=yyvsp[-2].val;
                                       the_code.branch=yyvsp[-2].val;;
    break;}
case 86:
#line 390 "gram.y"
{the_code.branch=yyval.val=symlook("__opcode_branch_default_pass")->value;;
    break;}
case 87:
#line 395 "gram.y"
{/*printf("cond");*/
		                        if(yyvsp[0].val == 0) //(CREG != 0) /* the values of the OPCODES are stored in the symbol table so se need to look them up*/
                                           yyval.val  = symlook("__opcode_branch_creg_zero")->value | symlook("__opcode_branch_negate")->value;
                                        else
                                        {
                                          if(yyvsp[0].val == 1) //(CREG != 1) or (CREG == 0)
                                            yyval.val  = symlook("__opcode_branch_creg_zero")->value;
                                          else
                                            yyerror("CREG can only be compared against 0 and 1  ie \n (CREG <> 0), (CREG != 0), (CREG == 0), (CREG)\n(CREG <> 1), (CREG != 1), (CREG == 1)");
                                        }
                                      ;
    break;}
case 88:
#line 406 "gram.y"
{/*printf("cond");*/
		                        if(yyvsp[0].val == 1) //(CREG != 0)  /* the values of the OPCODES are stored in the symbol table so se need to look them up*/
                                           yyval.val  = symlook("__opcode_branch_creg_zero")->value | symlook("__opcode_branch_negate")->value;
                                        else
                                        {
                                          if(yyvsp[0].val == 0) //(CREG != 1) or (CREG == 0)
                                            yyval.val  = symlook("__opcode_branch_creg_zero")->value;
                                          else
                                            yyerror("CREG can only be compared against 0 and 1  ie \n (CREG <> 0), (CREG != 0), (CREG == 0), (CREG)\n(CREG <> 1), (CREG != 1), (CREG == 1)");
                                        }
                                      ;
    break;}
case 89:
#line 417 "gram.y"
{/*printf("cond");*/
		                        if(yyvsp[0].val == 0)  //(BR1 != 0) or (BR1==1)  /* the values of the OPCODES are stored in the symbol table so se need to look them up*/
                                           yyval.val  = yyvsp[-2].symp->value;
                                        else
                                        {
                                          if(yyvsp[0].val == 1) //(CREG != 1) or (CREG == 0)
                                            yyval.val  = yyvsp[-2].symp->value | symlook("__opcode_branch_negate")->value;   /*negate the answer*/
                                          else
                                            yyerror("BRANCH conditions can only be compared against 0 and 1  ie \n (BRx <> 0), (BRx != 0), (BRx == 0), (BRx)\n(CREG <> 1), (BRx != 1), (BRx == 1)");
                                        }
                                      ;
    break;}
case 90:
#line 428 "gram.y"
{/*printf("cond");*/
		                        if(yyvsp[0].val == 1) //(BR1 != 0) or (BR1==1)
                                        {  /* the values of the OPCODES are stored in the symbol table so se need to look them up*/
                                           yyval.val = yyvsp[-2].symp->value;
                                        }
                                        else
                                        {
                                          if(yyvsp[0].val == 0) //(CREG != 1) or (CREG == 0)
                                            yyval.val  = yyvsp[-2].symp->value | symlook("__opcode_branch_negate")->value;   /*negate the answer*/
                                          else
                                            yyerror("BRANCH conditions can only be compared against 0 and 1  ie \n (BRx <> 0), (BRx != 0), (BRx == 0), (BRx)\n(CREG <> 1), (BRx != 1), (BRx == 1)");
                                        }
                                      ;
    break;}
case 91:
#line 441 "gram.y"
{/*printf("cond");*/
	                          yyval.val=yyvsp[0].symp->value;
                                  ;
    break;}
case 92:
#line 444 "gram.y"
{/*printf("cond");*/
                                           yyval.val  = symlook("__opcode_branch_creg_zero")->value | symlook("__opcode_branch_negate")->value;

                                      ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 498 "/usr/share/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 453 "gram.y"


/* look up a symbol table entry, add if not present */
struct symtab *
symlook(s)
char *s;
{
	char *p;
	struct symtab *sp;

	for(sp = symtab; sp < &symtab[NSYMS]; sp++) {
		/* is it already here? */
		if(sp->name && !strcmp(sp->name, s))
			return sp;

		/* is it free */
		if(!sp->name) {
			sp->name = (char*)strdup(s);
			return sp;
		}
		/* otherwise continue to next */
	}
	yyerror("Too many symbols");
	exit(1);	/* cannot continue */
} /* symlook */


yyerror(s)
char *s;
{
	fflush(stdout);
	printf("\n***** Error on line#%d *****\n%s\n", lineno,linebuf);
	printf("\n%*s\n%*s \n\n", column, "^", column, s);
	error_count++;
}

int clear_the_code(struct code* ptr)
{

       ptr->creg=-1;
       ptr->stack=-1;
       ptr->branch=-1;
       ptr->addgen=-1;
       ptr->opcode_data=-1;
       ptr->data=0;
       ptr->adr=0; // this is the codes address in memory
       ptr->line=0;
       ptr->name =0;
return OK;
};

int fix_the_code(struct code* ptr)
{

       if(ptr->creg==-1)
          ptr->creg =  symlook("__opcode_creg_nop")->value;
       if(ptr->stack==-1)
          ptr->stack =  symlook("__opcode_stack_nop")->value;
       if(ptr->branch==-1)
          ptr->branch =  symlook("__opcode_branch_default_pass")->value;
       if(ptr->addgen==-1)
          ptr->addgen =  symlook("__opcode_addgen_continue")->value;
       if(ptr->opcode_data==-1)
          ptr->opcode_data =  0;
          
          // now trucate to the correct width.
          // need to report errors/warnings when anything is truncated.
          ptr->creg &= 0xffffffff>>(32-symlook("__opcode_creg_width")->value);
          ptr->stack  &= 0xffffffff>>(32-symlook("__opcode_stack_width")->value);
          ptr->branch  &= 0xffffffff>>(32-symlook("__opcode_branch_width")->value);
          ptr->addgen  &= 0xffffffff>>(32-symlook("__opcode_addgen_width")->value);
          ptr->opcode_data  &= 0xffffffff>>(32-symlook("__opcode_data_width")->value);




       if(ptr->data==0);
       ptr->name =linebuf;
       return OK;
}


int check_stack_opcode(struct code* ptr)
{
    if (ptr->stack == -1)
       return(OK);
    yyerror("STACK has already been assigned an action and cannot accept two.");
    return(ERROR);
}
int check_data_opcode(struct code* ptr, int x)
{
 if ((ptr->opcode_data == -1)|| (ptr->opcode_data==x))
       return(OK);
    yyerror("Data field has already been assigned a value and connot be assigned a different one.");
    return(ERROR);
}
int check_creg_opcode(struct code* ptr)
{
if (ptr->creg == -1)
       return(OK);
    yyerror("GREG has already been assigned an action and cannot accept two.");
    return(ERROR);
}
int check_addgen_opcode(struct code* ptr)
{
if (ptr->addgen == -1)
       return(OK);
    yyerror("ADDRESS GENERATOR has already been assigned an action and cannot accept two.");
    return(ERROR);
}

