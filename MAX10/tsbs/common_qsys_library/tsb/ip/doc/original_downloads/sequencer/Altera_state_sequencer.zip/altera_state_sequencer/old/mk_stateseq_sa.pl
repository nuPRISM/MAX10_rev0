# 
# #BEGIN
# #{
# #  unshift @INC, "$ENV{QUARTUS_ROOTDIR}/sopc_builder/bin";
# #  unshift @INC, "$ENV{QUARTUS_ROOTDIR}/sopc_builder/bin/europa";
# #}
# 
# use europa_all;
# use strict;
# use mk_em_stateseq;
# 
# use Getopt::Long;
# $| = 1;     # Always flush stderr
# sub pretty_print($$)
# {
#   my $param = shift;
#   my $optional = shift;
# 
#   my $type_spec = "<$param->{type}>";
#   for ($param->{type})
#   {
#     /^s$/ and do {$type_spec = "<string>"; last;};
#     /^i$/ and do {$type_spec = "<integer>"; last;};
#     /^f$/ and do {$type_spec = "<float>"; last;};
#   }
#   my $l_delimit = "";
#   my $r_delimit = "";
#   my $default_value = "";
#   if ($optional)
#   {
#     $l_delimit = '[';
#     $r_delimit = ']';
#     $default_value = " ($param->{value})";
#   }
# 
#   my $str =
#     "  $l_delimit--$param->{name}=$type_spec$r_delimit " .
#     " - $param->{desc}$default_value\n";
# 
#   return $str;
# }
# 
# sub print_usage_and_fail($$)
# {
#   my ($req, $opt) = @_;
# 
#   my $base = `basename $0`;
#   1 while chomp $base;
# 
#   print STDERR "Usage:\n\n$base\n",
#     (map {pretty_print($_, 0)} @$req),
#     (map {pretty_print($_, 1)} @$opt),
#     "\n";
#   exit 1;
# }
# 
# my $start_time = time();
# #printf "Hello I was here" ;
# 
# my @required_parameters = (
#    {
#      name => '_system_directory',
#      type => 's',
#      value => undef,
#      dest => 'project',
#      desc => "HDL file output directory",
#    },
#      {
#      name => 'name',
#      type => 's',
#      value => undef,
#      dest => 'module',
#      desc => "module name",
#    },
# {
#     name => 'system_width',
#     type => 'i',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
# {
#     name => 'dataout_bits',
#     type => 'i',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
# #{
# #    name => 'use_external_clock',
# #    type => 'i',
# #    value => undef,
# #    dest => 'wsa',
# #    desc => "",
# #  },
# {
#     name => 'reset_running',
#     type => 'i',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
# {
#     name => 'idle_data_out',
#     type => 's',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
#  
# {
#     name => 'custom_idle_data_radix',
#     type => 's',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
# 
#  {
#      name => 'use_branch',
#      type => 'i',
#      value => undef,
#      dest => 'wsa',
#      desc => "",
#    },
#    {
#      name => 'branch_input_bits',
#      type => 'i',
#      value => undef,
#      dest => 'wsa',
#      desc => "",
#    },
#    {
#      name => 'onehot_branch',
#      type => 'i',
#      value => undef,
#      dest => 'wsa',
#      desc => "",
#    },
#    {
#      name => 'use_stack',
#      type => 'i',
#      value => undef,
#      dest => 'wsa',
#      desc => "",
#    },
#   {
#     name => 'stack_depth',
#     type => 'i',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
#  {
#     name => 'use_edata',
#     type => 'i',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
# {
#     name => 'use_creg',
#     type => 'i',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
#  {
#      name => 'clock_freq',
#      type => 's',
#      value => undef,
#      dest => 'wsa',
#      desc => "",
#    },
#     {
#      name => 'use_ext_load',
#      type => 's',
#      value => undef,
#      dest => 'wsa',
#      desc => "",
#    },
#    
#    {
#      name => 'device_family',
#      type => 's',
#      value => undef,
#      dest => 'wsa',
#      desc => "device family",
#    },
# 
#  );
# 
# # Optional paramters, with defaults.
# my @optional_parameters = (
#   {
#     name => 'language',
#     type => 's',
#     value => 'verilog',
#     dest => 'wsa',
#     desc => "HDL output language",
#   },
#    {
#     name => 'custom_idle_data_bitpattern',
#     type => 's',
#     value => ' ',
#     dest => 'wsa',
#     desc => "",
#   },
# );
# #printf "Hello I was here 0" ;
# my @params =
#   sort {$a->{name} cmp $b->{name}}
#     (@required_parameters, @optional_parameters);
# 
#  Getopt::Long::GetOptions(
# #GetOptions(
#   map {("$_->{name}=$_->{type}" => \$_->{value})} @params
# );
# #printf "Hello I was here 1" ;
# for my $req (@required_parameters)
# {
#   if (!defined $req->{value})
#   {
#     print STDERR "$0: missing required parameter '--$req->{name}'\n";
#     print_usage_and_fail(\@required_parameters, \@optional_parameters);
#   }
# }
# #printf "Hello I was here2" ;
# # Unpack the parameters and route them to their various destinations.
# my $WSA = {
#   map {$_->{dest} eq 'wsa' ? ($_->{name} => $_->{value}) : ()}  @params
# };
# #printf "Hello I was here 3" ;
# my $top = e_module->new(
# {
#   do_ptf => 0, # This avoids a warning about old-style ptf format.
#   (map {$_->{dest} eq 'module' ? ($_->{name} => $_->{value}) : ()} @params),
# });
# #printf "Hello I was here 4 $_->{name}" ;
# my $project = e_project->new({
#   top => $top,
#   map {$_->{dest} eq 'project' ? ($_->{name} => $_->{value}) : ()} @params
# });
# #printf "Hello I was here 5" ;
#  my $parameters_message =
#    join('', (map {"   --$_->{name}=$_->{value}\n"} @params));
# 
# # print "\nGenerating STATE Sequencer with these parameters:\n\n",
# #   $parameters_message,
# #   "\n";
# 
# #
# # # It's pretty handy to have a list of the parameters used for generation, right
# # # in the generated HDL file.
#  $top->comment("Generation parameters:\n" . $parameters_message);
# 
#  #print "Output file: ", $project->hdl_output_filename(), "\n";
# 
# mk_em_stateseq::make($project, $WSA);
# 
#  my $run_time = time() - $start_time;
# $| = 1;     # Always flush stderr
# # printf(
# #   "Generation time: about $run_time second%s\n\n",
# #   ($run_time == 1) ? "" : "s"
# # );
# 



use Getopt::Long;
use europa_all;
use mk_em_stateseq.pm;
use embedded_ip_generate_common;
use strict;

$| = 1;     # Always flush stderr






{

    my $infos = process_args();
    my $project = prepare_project($infos);
    

    my $Options = &copy_of_hash($infos);
    
    $Options->{width} = $infos->{Data_Width};     
    
    #&make_pio ($project->top(), $Options);
    em_stateseq::make($project, $WSA);
    $project->output();

    exit(0);
}