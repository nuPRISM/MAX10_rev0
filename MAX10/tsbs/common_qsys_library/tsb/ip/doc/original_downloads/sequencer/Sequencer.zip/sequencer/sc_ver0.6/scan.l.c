%{
/*
 * cal's sequecner parser
 *
 * For multiple files
 *
 */

unsigned long charCount = 0, wordCount = 0, lineCount = 0;

#undef yywrap	/* sometimes a macro by default */

%}

O           [0-7]
D           [0-9]
L           [a-zA-Z_]
H           [a-fA-F0-9]
WRD         {L}({L}|{D})*
HEXNUM      0[xX]{H}+
NUM         {D}+
WS          [ \t]
OP          [\/\*+-&\|]
%x CMNT0 CMNT1 PREPRO PREPROE PREPROL PREPROAL

%{
#include <stdio.h>
#include "y.tab.h"
#include "scan.h"
#include <math.h>
/*#include <strings.h>*/


int lineno=1;
char linebuf[500];
void count();
long htoi(char * yytext);
long code_address  = 0;
int first_time = 1;
int in_PREPRO = 1;
struct symtab *sp;
int column = 0;
int value;
int print_symbols(int x);
int error_count =0;
struct symtab  symtab[NSYMS]=
{
    {"__system_width",           10,    SYSTEM_SYMBOL},
    {"__dataout_bits",           8,     SYSTEM_SYMBOL},
    {"__use_branch",             1,     SYSTEM_SYMBOL},
    {"__use_stack",              1,     SYSTEM_SYMBOL},
    {"__use_creg",               1,     SYSTEM_SYMBOL},
    {"__use_edata",              1,     SYSTEM_SYMBOL},
    {"__branch_input_bits",      6,     SYSTEM_SYMBOL},
    {"__stack_depth",            5,     SYSTEM_SYMBOL},

    // creg stuff
    {"__opcode_creg_width",      4,      SYSTEM_SYMBOL},
    {"__opcode_creg_dec",        1,      SYSTEM_SYMBOL},
    {"__opcode_creg_load_data",  2,      SYSTEM_SYMBOL},
    {"__opcode_creg_load_edata", 4,      SYSTEM_SYMBOL},
    {"__opcode_creg_load_stack", 8,      SYSTEM_SYMBOL},
    {"__opcode_creg_decn",       0x10,   SYSTEM_SYMBOL},  // decriment if negative
    {"__opcode_creg_nop",        0x0,    SYSTEM_SYMBOL},


    // stack stuff
    {"__opcode_stack_width",     3,      SYSTEM_SYMBOL},
    {"__opcode_stack_push_creg", 1,      SYSTEM_SYMBOL},
    {"__opcode_stack_push_address", 2,   SYSTEM_SYMBOL},
    {"__opcode_stack_pop",       4,      SYSTEM_SYMBOL},
    {"__opcode_stack_nop",       0,      SYSTEM_SYMBOL},


    // branch stuff
    {"__opcode_branch_width",    4,      SYSTEM_SYMBOL},
    {"__opcode_branch_negate",   1,      SYSTEM_SYMBOL},
    {"__opcode_branch_onehot",   1,      SYSTEM_SYMBOL},
    {"__opcode_branch_creg_zero", 4,     SYSTEM_SYMBOL},
    {"__opcode_branch_default_pass", 2,  SYSTEM_SYMBOL},

    //address generation
    {"__opcode_addgen_width",    4,      SYSTEM_SYMBOL},
    {"__opcode_addgen_continue", 0,      SYSTEM_SYMBOL}, // next_address = address+1
    {"__opcode_addgen_stack",    1,      SYSTEM_SYMBOL}, // next_address = stack
    {"__opcode_addgen_data",     2,      SYSTEM_SYMBOL}, // next_address = opcode_data
    {"__opcode_addgen_edata",    4,      SYSTEM_SYMBOL}, // next_address = edata
    {"__opcode_addgen_wait_creg",4,      SYSTEM_SYMBOL}, // next_address=address if branch condition false and CREG is not zero
    {"__opcode_addgen_wait",     4,      SYSTEM_SYMBOL}, // next_address=address if branch condition false

    // data field width
    {"__opcode_data_width", 10, SYSTEM_SYMBOL},

    // branch conditions
    {"BR0", 0,      BRANCH_CONDITION},
    {"BR1", 1, BRANCH_CONDITION},
    {"BR2", 2, BRANCH_CONDITION},
    {"BR3", 3, BRANCH_CONDITION},
    {"BR4", 4, BRANCH_CONDITION},
    {"BR5", 5, BRANCH_CONDITION},
    {"BR6", 6, BRANCH_CONDITION},
    {"BR7", 7, BRANCH_CONDITION},
    {"BR8", 8, BRANCH_CONDITION},
    {"BR9", 9, BRANCH_CONDITION},
    {"BR10", 10, BRANCH_CONDITION},
    {"BR11", 11, BRANCH_CONDITION},
    {"BR12", 12, BRANCH_CONDITION},
    {"BR13", 13, BRANCH_CONDITION},
    {"BR14", 14, BRANCH_CONDITION},
    {"BR15", 15, BRANCH_CONDITION},
    {"BR16", 16, BRANCH_CONDITION},
    {"BR17", 17, BRANCH_CONDITION},
    {"BR18", 18, BRANCH_CONDITION},
    {"BR19", 19, BRANCH_CONDITION},
    {"BR20", 20, BRANCH_CONDITION},
    {"BR21", 21, BRANCH_CONDITION},
    {"BR22", 22, BRANCH_CONDITION},
    {"BR23", 23, BRANCH_CONDITION},
    {"BR24", 24, BRANCH_CONDITION},
    {"BR25", 25, BRANCH_CONDITION},
    {"BR26", 26, BRANCH_CONDITION},
    {"BR27", 27, BRANCH_CONDITION},
    {"BR28", 28, BRANCH_CONDITION},
    {"BR29", 29, BRANCH_CONDITION},
    {"BR30", 30, BRANCH_CONDITION},
    {"BR31", 31, BRANCH_CONDITION},

    {"continue" ,   CONTINUE ,  RESERVED},
    {"default" ,    DEFAULT ,   RESERVED},
    {"goto" ,       GOTO ,      RESERVED},
    {"if" ,         IF ,        RESERVED},
    {"return" ,     RETURN ,    RESERVED},
    {"while" ,      WHILE ,     RESERVED},
    {"device" ,     DEVICE ,    RESERVED},
    {"dec" ,        DEC ,       RESERVED},
    {"creg" ,       CREG ,      RESERVED},
    {"CREG" ,       CREG ,      RESERVED},
    {"stack" ,      STACK ,     RESERVED},
    {"load" ,       LOAD ,      RESERVED},
    {"wait" ,       WAIT ,      RESERVED},
    {"then" ,       THEN ,      RESERVED},
    {"push" ,       PUSH ,      RESERVED},
    {"pop" ,        POP ,       RESERVED},
    {"to" ,         TO ,        RESERVED},
    {"from" ,       FROM ,      RESERVED},
    {"loop" ,       LOOP ,      RESERVED},
    {"else" ,       ELSE ,      RESERVED},

    {"__END__PREINITIALIZED",0,0},

};
%}

%%
%{
    if(first_time)
    {
        if(in_PREPRO)
        {
            BEGIN   PREPRO;
            first_time =0;
            printf("\nStarting PREPROCESSOR\n");
            return (PREPROCESSOR);
        }
        else
        {
            BEGIN   INITIAL;
            first_time =0;
            printf("\nStarting Compile\n");
            return (COMPILER);

        }
    }


%}
        /*\"(\\.|[^\\"])*\"	{ count(); }*/
\"[^\"\n]*\"            {count(); }
\"[^\"\n]*$             {count();
                            yyerror("Unterminated string");}
<PREPRO>\"[^\"\n]*\"	{ count(); }
<PREPRO>\"[^\"\n]*$     {count();
                           yyerror("Unterminated string");}

"/*"			        { count();BEGIN CMNT0; }
<PREPRO>"/*"		    { count();BEGIN CMNT0; }
<CMNT0>.                { count();}
<CMNT0>\n               { count();lineno++;}
<CMNT0>"*/"             { count();  if   (in_PREPRO)
                               BEGIN PREPRO;
                            else
                               BEGIN INITIAL;}

"//"			        { count();BEGIN CMNT1;  }
<PREPRO>"//"		    { count();BEGIN CMNT1; }
<CMNT1>.*               {count();}
<CMNT1>\n               {count();lineno++;
                         if   (in_PREPRO)
                            BEGIN PREPRO;
                         else
                            BEGIN INITIAL;}

<PREPROE>{WRD}	{ count();
				sp = symlook(yytext);
				yylval.symp = sp;
				//printf("symbol");
				if(sp->type == BRANCH_CONDITION)
					           return(BRANCH_CONDITION);

				return(PNAME); /* return symbol pointer*/
				}
<PREPROL>{WRD}	{ count();
				sp = symlook(yytext);
				yylval.symp = sp;
				//printf("symbol");

				return(PLABEL); /* return symbol pointer*/
				}

<PREPROAL>"ORG"	                { count();
				//printf("symbol");

				return(ORG); /* return symbol pointer*/
				}

<PREPROAL>{WRD}	{ count();
				sp = symlook(yytext);
				yylval.symp = sp;
				//printf("symbol");

				return(PLABEL); /* return symbol pointer*/
				}


<PREPROE>{HEXNUM}		{ count();
				  //printf("hexnumber");
				  yylval.val = htoi(yytext);
				  return(PNUMBER); }
<PREPROL>{HEXNUM}		{ count();
				  //printf("hexnumber");
				  yylval.val = htoi(yytext);
				  return(PNUMBER); }
<PREPROAL>{HEXNUM}		{ count();
				  //printf("hexnumber");
				  yylval.val = htoi(yytext);
				  return(PNUMBER); }
<PREPROE>{NUM}		{ count();
				  yylval.val = atoi(yytext);
				  //printf("decimal");
				  return(PNUMBER); }
<PREPROL>{NUM}		{ count();
				  yylval.val = atoi(yytext);
				  //printf("decimal");
				  return(PNUMBER); }
<PREPROAL>{NUM}		{ count();
				  yylval.val = atoi(yytext);
				  //printf("decimal");
				  return(PNUMBER); }



<PREPROL>":"			{ count(); BEGIN PREPRO; return(':');}
<PREPROAL>":"			{ count(); return(':'); }

<PREPRO>";"			{ count(); return(';'); }
<PREPROAL>";"			{ count(); BEGIN PREPRO; return(';'); }
<PREPROE>";"			{ count(); BEGIN PREPRO; return(';'); }

<PREPRO>","			{ count(); return(','); }
<PREPROE>"="			{ count(); return('='); }
<PREPRO>.			{ count();  }
<PREPROE>.			{ count();  }
<PREPROL>.			{ count();  }
<PREPROAL>.			{ count();  }
 /* there are only five cases that need to be sent to the grammer
   ,;    this one is automtic the others we have to check for
   name = number;
   name = name;
   name :
   org : number|name;*/
<PREPRO>{WRD}{WS}*"="[^=][^;\n]*";"   {//printf("found equate  **  %s\n", yytext);
                                              yyless(0);
                                              BEGIN PREPROE;}
<PREPRO>{WRD}{WS}*":"                         {//printf(" found label. ** %s\n",yytext);
                                              yyless(0);
                                              BEGIN PREPROL;}
<PREPRO>ORG{WS}*":"[^\n;]*";"  {//printf(" found assign label. ** %s\n",yytext);
                                                yyless(0);
                                                BEGIN PREPROAL;}

<PREPRO>\n.*                    {
                          strcpy(linebuf,yytext+1); /* save the next line */
                          lineno++;
                          //printf("line# %d %s\n",lineno,linebuf);
                          yyless(1);
                          column = 0;}



"continue"		{ count(); return(CONTINUE); }
"default"		{ count(); return(DEFAULT_OUT); }
"goto"			{ count(); return(GOTO); }
"if"			{ count(); return(IF); }
"return"		{ count(); return(RETURN); }
"while"			{ count(); return(WHILE); }
"device"		{ count(); return(DEVICE); }
"dec"			{ count(); return(DEC); }
"creg"			{ count(); return(CREG); }
"CREG"			{ count(); return(CREG); }
"stack"			{ count(); return(STACK); }
"load"			{ count(); return(LOAD); }
"wait"			{ count(); return(WAIT); }
"then"			{ count(); return(THEN); }
"push"			{ count(); return(PUSH); }
"pop"			{ count(); return(POP); }
"to"			{ count(); return(TO); }
"from"			{ count(); return(FROM); }
"loop"			{ count(); return(LOOP); }
"else"			{ count(); return(ELSE); }
"DATA_IN"		{ count(); return(DATA_IN); }
"ADDRESS"		{ count(); return(ADDRESS); }

{WRD}		{count();
						sp = symlook(yytext);
						yylval.symp = sp;
						//printf(" NAME %s\n",yytext);
						if(sp->type == BRANCH_CONDITION)
					           return(BRANCH_CONDITION);
					        if(sp->type == ADR_LABEL)
					           return(ADR_LABEL);
						return(NAME); /* return symbol pointer*/
						}

{HEXNUM}		{ count();
						//printf("hexnumber %s",yytext);
						yylval.val = htoi(yytext);
						return(NUMBER); }

{NUM}		{ count();
						yylval.val = atoi(yytext);
						//printf("decimal %s",yytext);
						return(NUMBER); }





">>"			{ count(); return(RIGHT_OP); }
"<<"			{ count(); return(LEFT_OP); }
"=="			{ count(); return(EQ_OP); }
"!="			{ count(); return(NE_OP); }
";"			{ count(); return(';'); }
"{"			{ count(); return('{'); }
"}"			{ count(); return('}'); }
","			{ count(); return(','); }
":"			{ count(); return(':'); }
"="			{ count(); return('='); }
"("			{ count(); return('('); }
")"			{ count(); return(')'); }
"["			{ count(); return('['); }
"]"			{ count(); return(']'); }
"."			{ count(); return('.'); }
"&"			{ count(); return('&'); }
"!"			{ count(); return('!'); }
"~"			{ count(); return('~'); }
"-"			{ count(); return('-'); }
"+"			{ count(); return('+'); }
"*"			{ count(); return('*'); }
"/"			{ count(); return('/'); }
"%"			{ count(); return('%'); }
"<"			{ count(); return('<'); }
">"			{ count(); return('>'); }
"^"			{ count(); return('^'); }
"|"			{ count(); return('|'); }
"?"			{ count(); return('?'); }

[ \t\v\f]		{ count(); }
.			{ /* ignore bad characters */ }

 /*{WRD}{WS}*"="[^=][^;\n]*";"   {count(); // the equates are handeled by the preprocessor.}*/
 /*{WRD}{WS}*":"            {count(); // the labesl are handeled by the preprocessor. }*/

\n.*                    {
                          strcpy(linebuf,yytext+1); /* save the next line */
                          lineno++;
                          //printf("line# %d %s\n",lineno,linebuf);
                          yyless(1);
                          column = 0;}


%%


void count()
{
	int i;

	for (i = 0; yytext[i] != '\0'; i++)
		if (yytext[i] == '\n')
			column = 0;
		else if (yytext[i] == '\t')
			column += 8 - (column % 8);
		else
			column++;
//   if(!in_PREPRO)
//	ECHO;      // if this is turned on the entire contents of the file are printed
}


// converts a asci hex number to a long
long htoi(char * yytext)
{
	long value=0;
	int i,j;
	char a;
	for ( i=2;yytext[i] != 0;i++)
	{
		a=yytext[i];
		if ( a <='9')
		{			// must be 0-9
			value = (value<<4)+ (int)(a -'0');
		}
		else
		{		// must be a-f or A-F
				value = (value<<4)+ (int)((0x0f & a) +9);
		}



	}
	return value;
}
char **fileList;
unsigned currentFile = 0;
unsigned nFiles;

main(argc,argv)
int argc;
char **argv;
{
        FILE *file;

        fileList = argv+1;
        nFiles = argc-1;

       if(argc >=2)
       {
               in_PREPRO =1;
               first_time =1;
	       currentFile =0;
	       lineno=1;
	       code_address =0;

	       // initialize the array
	      // __END__PREINITIALIZED

	       if(!yywrap())	/* open first file for preprocessing*/
	       {
	           yyparse();
	        }
	        else
	        {
	            exit(1);
                }
                if(error_count>0)
                {
                   printf("\n Terminating execution with errors.\n");
                }
                else
                {
                 in_PREPRO =0;
                 first_time =1;
	         currentFile =0;
	         lineno=1;
	         code_address =0;
	         if(!yywrap())       /* now open all the files again but now for compiling*/
	           yyparse();

	          if(error_count>0)
                  {
                   printf("\n Terminating execution with errors.\n");
                  }
                  else
                  {
                      printf("\nCompiled successfully\n");
                  }
                }

	     print_symbols(0);
         }
        else
        {
          printf("\n*********  Need an input file ************\n\n");
        }


	return 0;
}

/*
 * the lexer calls yywrap to handle EOF conditions (e.g., to
 * connect to a new file, as we do in this case.)
 */

yywrap()
{
	FILE *file;
	if ((currentFile != 0) && (currentFile < nFiles)) {
		/*
		 * we print out the statistics for the previous file.
		 */
		fclose(yyin);	/* done with that file */
	}

	while (fileList[currentFile] != (char *)0) {
		file = fopen(fileList[currentFile++], "r");
		if (file != NULL) {
			yyin = file;
			break;
		}

		printf("\n\n*********** could not open file %s *************\n\n",
			fileList[currentFile-1]);
	}
	return (file ? 0 : 1);	/* 0 means there's more input */
}

int print_symbols(int x)
{
      FILE *file;
      struct symtab *sp;
      int count=0;
      file = fopen("symbols.txt","w");
      if (file != NULL)
      {
         fprintf(file,"\nSymbol Name                     \t Value          \t Type\n");
   	 for(sp = symtab; sp < &symtab[NSYMS]; sp++) {
		/* is it already here? */
		if(!sp->name)
			break; // end of the list
                 else
                 {
                  count++;
                     // now print the output
                     if( sp->type == VARIABLE)
                        fprintf(file,"\n%-32s\t 0x%-16x\t ** UNINITIALIZED VARIABLE **",sp->name,sp->value);
                     if( sp->type == INITIALIZED_VARIABLE)
                        fprintf(file,"\n%-32s\t 0x%-16x\t INITIALIZED VARIABLE",sp->name,sp->value);
                     if( sp->type == SYSTEM_SYMBOL)
                        fprintf(file,"\n%-32s\t 0x%-16x\t SYSTEM_SYMBOL",sp->name,sp->value);
                     if( sp->type == BRANCH_CONDITION)
                        fprintf(file,"\n%-32s\t 0x%-16x\t BRANCH_CONDITION",sp->name,sp->value);
                     if( sp->type == ADR_LABEL)
                        fprintf(file,"\n%-32s\t 0x%-16x\t LABEL",sp->name,sp->value);
                     if( sp->type == RESERVED)
                        fprintf(file,"\n%-32s\t 0x%-16x\t RESERVED WORDS",sp->name,sp->value);

                  }
	   }

	   fprintf(file,"\n\nEnd of file.  Total symbols = %d\n\n",count);
	   fclose(file);
	}
	else
	{
	 printf("\n ERROR: Could not open file to write symbols\n");
	 return (1);
	}
	return (0);

}
