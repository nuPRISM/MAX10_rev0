/*
 * file: c:/sequencer/test1/state_sequencer_0_sdk/src/state_sequencer_0_test_code.c
 * This file is a machine generated test program
 * for a CPU named state_sequencer_0.
 * c:/sequencer/test1/test1.ptf
 * Generated: 2003.11.06 13:24:31
 *
 * ex: set tabstop=4:
 */

#include "excalibur.h"

int main(void)
	{
	/* (Test routines follow) */


	return 0;
	}

/* End of file */
