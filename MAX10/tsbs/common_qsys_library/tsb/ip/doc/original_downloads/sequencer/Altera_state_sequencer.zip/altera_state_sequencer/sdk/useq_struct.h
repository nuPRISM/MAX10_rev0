// Sequencer registers
typedef volatile struct
	{
	int np_useqrunreset;
	int np_useqpc;
	} np_useq_control;
	
// Sequencer Control Register Bits
enum
	{
	np_useqcontrol_rst_bit = 1,
	np_useqcontrol_run_bit = 0,
	
	np_useqcontrol_rst_mask = (1<<1),
	np_useqcontrol_run_mask = (1<<0)
	};