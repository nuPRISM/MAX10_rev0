typedef union {
	long val;
	struct symtab *symp;
} YYSTYPE;
#define	LEFT_OP	258
#define	RIGHT_OP	259
#define	EQ_OP	260
#define	NE_OP	261
#define	DEVICE	262
#define	CONTINUE	263
#define	DEC	264
#define	STACK	265
#define	CREG	266
#define	LOAD	267
#define	WAIT	268
#define	THEN	269
#define	PUSH	270
#define	POP	271
#define	TO	272
#define	FROM	273
#define	LOOP	274
#define	GOSUB	275
#define	ADDRESS	276
#define	PREPROCESSOR	277
#define	COMPILER	278
#define	PNAME	279
#define	PNUMBER	280
#define	ORG	281
#define	BRANCH_CONDITION	282
#define	DEFAULT	283
#define	IF	284
#define	ELSE	285
#define	WHILE	286
#define	GOTO	287
#define	RETURN	288
#define	NAME	289
#define	ADR_LABEL	290
#define	SYSTEM_SYMBOL	291
#define	PLABEL	292
#define	PROJECT_NAME	293
#define	DATA_IN	294
#define	NUMBER	295
#define	DEFAULT_OUT	296
#define	UMINUS	297


extern YYSTYPE yylval;
