# 
# #BEGIN
# #{
# #  unshift @INC, "$ENV{QUARTUS_ROOTDIR}/sopc_builder/bin";
# #  unshift @INC, "$ENV{QUARTUS_ROOTDIR}/sopc_builder/bin/europa";
# #}
# 
# use europa_all;
# use strict;
# use mk_em_uart;
# 
# use Getopt::Long;
# 
# sub pretty_print($$)
# {
#   my $param = shift;
#   my $optional = shift;
# 
#   my $type_spec = "<$param->{type}>";
#   for ($param->{type})
#   {
#     /^s$/ and do {$type_spec = "<string>"; last;};
#     /^i$/ and do {$type_spec = "<integer>"; last;};
#     /^f$/ and do {$type_spec = "<float>"; last;};
#   }
#   my $l_delimit = "";
#   my $r_delimit = "";
#   my $default_value = "";
#   if ($optional)
#   {
#     $l_delimit = '[';
#     $r_delimit = ']';
#     $default_value = " ($param->{value})";
#   }
# 
#   my $str =
#     "  $l_delimit--$param->{name}=$type_spec$r_delimit " .
#     " - $param->{desc}$default_value\n";
# 
#   return $str;
# }
# 
# sub print_usage_and_fail($$)
# {
#   my ($req, $opt) = @_;
# 
#   my $base = `basename $0`;
#   1 while chomp $base;
# 
#   print STDERR "Usage:\n\n$base\n",
#     (map {pretty_print($_, 0)} @$req),
#     (map {pretty_print($_, 1)} @$opt),
#     "\n";
#   exit 1;
# }
# 
# my $start_time = time();
# printf "Hello I was here" ;
# # Parameter specifications.
# # Most fields are self-explanatory.  The "dest" field
# # takes one of three values:
# #   1) "module": the parameter is passed directly to e_module->new().
# #   2) "project": the parameter is passed to e_project->new().
# #   3) "wsa": the parameter is passed to the component generator subroutine.
# #     --_system_directory=$outdir \
# #      --language=$language \
# #      --name=$output_name \
# #      --clock_freq=$clock_freq \
# #      --use_tx_fifo=$use_tx_fifo \
# #      --use_rx_fifo=$use_rx_fifo \
# #   X   --baud=$baud \
# #    X  --data_bits=$data_bits \
# #   X   --fixed_baud=$fixed_baud \
# #  X    --parity=$parity \
# #   X   --stop_bits=$stop_bits \
# #  X    --use_cts_rts=$use_cts_rts \
# #   X   --use_eop_register=$use_eop_register \
# #   X   --sim_true_baud=$sim_true_baud \
# #   X   --sim_char_stream=$sim_char_stream \
# #  X    --fifo_export_used=$fifo_export_used \
# #  x    --Has_IRQ=$Has_IRQ \
# #      --hw_cts=$hw_cts \
# #  X    --trans_pin=$trans_pin \
# #  X    --fifo_size_tx=$fifo_size_tx \
# #  X    --fifo_size_rx=$fifo_size_rx \
# #
# my @required_parameters = (
# {
#     name => 'system_width',
#     type => 'i',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
# {
#     name => 'dataout_bits',
#     type => 'i',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
# {
#     name => 'reset_running',
#     type => 'i',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
# {
#     name => 'idle_data_out',
#     type => 'i',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
# {
#     name => 'custom_idle_data_radix',
#     type => 'i',
#     value => undef,
#     dest => 'wsa',
#     desc => "",
#   },
# 
#    {
#      name => 'name',
#      type => 's',
#      value => undef,
#      dest => 'l',
#      desc => "component module name",
#    },
#  
#    {
#      name => '_system_directory',
#      type => 's',
#      value => undef,
#      dest => 'project',
#      desc => "HDL file output directory",
#    },
#  );
# 
# # Optional paramters, with defaults.
# my @optional_parameters = (
#   {
#     name => 'language',
#     type => 's',
#     value => 'verilog',
#     dest => 'project',
#     desc => "HDL output language",
#   },
# );
# 
# my @params =
#   sort {$a->{name} cmp $b->{name}}
#     (@required_parameters, @optional_parameters);
# 
# # Getopt::Long::GetOptions(
# GetOptions(
#   map {("$_->{name}=$_->{type}" => \$_->{value})} @params
# );
# 
# for my $req (@required_parameters)
# {
#   if (!defined $req->{value})
#   {
#     print STDERR "$0: missing required parameter '--$req->{name}'\n";
#     print_usage_and_fail(\@required_parameters, \@optional_parameters);
#   }
# }
# 
# # Unpack the parameters and route them to their various destinations.
# my $WSA = {
#   map {$_->{dest} eq 'wsa' ? ($_->{name} => $_->{value}) : ()}  @params
# };
# 
# my $top = e_module->new(
# {
#   do_ptf => 0, # This avoids a warning about old-style ptf format.
#   (map {$_->{dest} eq 'module' ? ($_->{name} => $_->{value}) : ()} @params),
# });
# 
# my $project = e_project->new({
#   top => $top,
#   map {$_->{dest} eq 'project' ? ($_->{name} => $_->{value}) : ()} @params
# });
# 
#  my $parameters_message =
#    join('', (map {"   --$_->{name}=$_->{value}\n"} @params));
# 
#  print "\nGenerating State Sequencer with these parameters:\n\n",
#    $parameters_message,
#    "\n";
#  print "\nGenerating State Sequencer uart with WSA:\n\n",
#    $WSA,
#    "\n";
# 
# #
# # # It's pretty handy to have a list of the parameters used for generation, right
# # # in the generated HDL file.
#  $top->comment("Generation parameters:\n" . $parameters_message);
# 
#  print "Output file: ", $project->hdl_output_filename(), "\n";
# 
# em_stateseq::make($project, $WSA);
# 
#  my $run_time = time() - $start_time;
# 
#  printf(
#    "Generation time: about $run_time second%s\n\n",
#    ($run_time == 1) ? "" : "s"
#    return 1;
#  );

#Copyright (C)2001-2010 Altera Corporation
#Any megafunction design, and related net list (encrypted or decrypted),
#support information, device programming or simulation file, and any other
#associated documentation or information provided by Altera or a partner
#under Altera's Megafunction Partnership Program may be used only to
#program PLD devices (but not masked PLD devices) from Altera.  Any other
#use of such megafunction design, net list, support information, device
#programming or simulation file, or any other related documentation or
#information is prohibited for any other purpose, including, but not
#limited to modification, reverse engineering, de-compiling, or use with
#any other silicon devices, unless such use is explicitly licensed under
#a separate agreement with Altera or a megafunction partner.  Title to
#the intellectual property, including patents, copyrights, trademarks,
#trade secrets, or maskworks, embodied in any such megafunction design,
#net list, support information, device programming or simulation file, or
#any other related documentation or information provided by Altera or a
#megafunction partner, remains with Altera, the megafunction partner, or
#their respective licensors.  No other licenses, including any licenses
#needed under any third party's intellectual property, are provided herein.
#Copying or modifying any file, or portion thereof, to which this notice
#is attached violates this copyright.




use Getopt::Long;
use europa_all;
use mk_em_stateseq.pm;
use embedded_ip_generate_common;
use strict;

$| = 1;     # Always flush stderr






{

    my $infos = process_args();
    my $project = prepare_project($infos);
    

    my $Options = &copy_of_hash($infos);
    
    $Options->{width} = $infos->{Data_Width};     
    
    #&make_pio ($project->top(), $Options);
    em_stateseq::make($project, $WSA);
    $project->output();

    exit(0);
}
