# Copyright (C) 1991-2003 Altera Corporation
# Any megafunction design, and related net list (encrypted or decrypted),
# support information, device programming or simulation file, and any other
# associated documentation or information provided by Altera or a partner
# under Altera's Megafunction Partnership Program may be used only to
# program PLD devices (but not masked PLD devices) from Altera.  Any other
# use of such megafunction design, net list, support information, device
# programming or simulation file, or any other related documentation or
# information is prohibited for any other purpose, including, but not
# limited to modification, reverse engineering, de-compiling, or use with
# any other silicon devices, unless such use is explicitly licensed under
# a separate agreement with Altera or a megafunction partner.  Title to
# the intellectual property, including patents, copyrights, trademarks,
# trade secrets, or maskworks, embodied in any such megafunction design,
# net list, support information, device programming or simulation file, or
# any other related documentation or information provided by Altera or a
# megafunction partner, remains with Altera, the megafunction partner, or
# their respective licensors.  No other licenses, including any licenses
# needed under any third party's intellectual property, are provided herein.
# Copying or modifying any file, or portion thereof, to which this notice
# is attached violates this copyright.

package mk_em_stateseq;

#use wiz_utils;
#use filename_utils;  # This is for to Perlcopy 'uart.pl'
use europa_all;
use strict;
use europa_utils;

sub make ($$) {
my ($project, $WSA) = @_;
$WSA->{'system_directory'} = $project->_system_directory();
make_state_sequencer ($project,$WSA);

$project->output();

}

############## BEGIN  EXECUTION  ################
#my $project = e_project->new(@ARGV);
# Make a copy so we don't write-back derived parameter values, etc.
#my $Options = &copy_of_hash($project->WSA());
#$Options->{'top_module_name'}  = $project->_target_module_name();
#$Options->{'device_family'}    = $project->device_family();
#$Options->{'system_directory'} = $project->_system_directory();
#$Options->{'language'}         = $project->language();
#&make_state_sequencer ($project->top(), $Options);
#&generate_variation_file($Options, $project->_system_directory(), $project->_target_module_name());
#unless ($project->_software_only()) {
#    $project->output();
#}
#exit;

############## END OF EXECUTION  ################
############## BEGIN SUBROUTINES ################

#################################################################
# subroutine validate_state_sequencer_options
#
# Make sure all configuration options given to us in the
# WIZARD_SCRIPT_ARGUMENTS section of the system PTF file are 
# valid.  If they're not, halt system generation and have SOPC
# Builder print a nasty error message.
#
sub validate_state_sequencer_options
{
    my $Options = shift;
    &validate_parameter ({
	hash    => $Options,
	name    => 'system_width',
	type    => 'integer',
	range   => [3,16],
	default => 10,
    });
    &validate_parameter ({
	hash    => $Options,
	name    => 'dataout_bits',
	type    => 'integer',
        range   => [1,56],        # Minimum configuration with 56 dataout bits
	default => 4,             # produces 64 bit opcode.
    });
#    &validate_parameter ({
#	hash    => $Options,
#	name    => 'use_external_clock',
#	type    => 'boolean',
#	default => 0,
#    });
    &validate_parameter ({
	hash    => $Options,
	name    => 'reset_running',
	type    => 'boolean',
	default => 0,
    });
    &validate_parameter ({
	hash    => $Options,
	name    => 'idle_data_out',
	allowed => ['gnd','vcc','instr','custom'],
	default => 'instr',
    });
    if ($Options->{'idle_data_out'} eq 'custom') {
	&validate_parameter ({
	    hash    => $Options,
	    name    => 'custom_idle_data_radix',
	    allowed => ['h','d','b'],
	    default => 'h',
	});
	my $bitpattern = $Options->{'custom_idle_data_bitpattern'};
	$bitpattern =~ s/\s//ig;
	$Options->{'custom_idle_data_bitpattern'} = $bitpattern;
	if ($Options->{'custom_idle_data_radix'} eq 'h') {
	    unless ($bitpattern =~ m/^[\dabcdef]+$/i) {
		die "ERROR: $bitpattern is an improper custom dataout bitpattern for radix Hexadecimal.  Halted";
	    }
	} elsif ($Options->{'custom_idle_data_radix'} eq 'd') {
	    unless ($bitpattern =~ m/^\d+$/i) {
		die "ERROR: $bitpattern is an improper custom dataout bitpattern for radix Decimal.  Halted";
	    }
	} elsif ($Options->{'custom_idle_data_radix'} eq 'b') {
	    unless ($bitpattern =~ m/^[10]+$/i) {
		die "ERROR: $bitpattern is an improper custom dataout bitpattern for radix Binary.  Halted";
	    }
	} else {
	    die "ERROR: Improper value for parameter custom_idle_data_radix.  halted ";
	}
    }
    &validate_parameter ({
	hash    => $Options,
	name    => 'use_branch',
	type    => 'boolean',
	default => 1,
    });
    if ($Options->{'use_branch'}) {
	&validate_parameter ({
	    hash    => $Options,
	    name    => 'branch_input_bits',
	    type    => 'integer',
	    range   => [1,16],
	    default => 4,
	});
	&validate_parameter ({
	    hash    => $Options,
	    name    => 'onehot_branch',
	    type    => 'boolean',
	    default => 1,
	});
    }
    &validate_parameter ({
	hash    => $Options,
	name    => 'use_stack',
	type    => 'boolean',
	default => 0,
    });
    if ($Options->{'use_stack'}) {
	&validate_parameter ({
	    hash    => $Options,
	    name    => 'stack_depth',
	    type    => 'integer',
	    range   => [1,8],
	    default => 5,
	});
    }
    &validate_parameter ({
	hash    => $Options,
	name    => 'use_edata',
	type    => 'boolean',
	default => 0,
    });
    &validate_parameter ({
	hash    => $Options,
	name    => 'use_creg',
	type    => 'boolean',
	default => 1,
    });
}










#################################################################
# subroutine make_state_sequencer
#
# This is the main routine in the generator program.
# Its official responsibility is to create the top-level
# sequencer module, but in detail, it:
# Initializes some new parameters in the Options hash,
# determines the instruction word format, and calls other
# routines to generate the HDL for its lower-level modules.
# Instantiates enabled modules and handles port mapping for
# each of them.  Aside from port mapping and inter-module
# wiring, the only logic in the top-level module is:
#   1) Part-select assignments to route each opcode in the
#      instruction word to its appropriate module
#   2) Simulation-only MUXes to convert opcodes to ASCII
#      strings for debugging.  (generated by subroutine)
#
sub make_state_sequencer
{
#print  "starting sequencer\n";
  my ($project,$WSA) = (@_);
#print  "starting sequencer\n";
  my $module  = $project->top();
#  print  "starting sequencer\n";
  my $Opt = $WSA;
#  print  "starting sequencer\n";
  my $Options = $WSA;
 # print  "starting sequencer\n";
# print $Opt->{name} ;
    $Opt->{name}       = $module->name();
#     print $Opt->{name} ;
    $Opt->{top_module_name} = $Opt->{name};
#    print "$Opt->{top_module_name}\n" ;
 #   print  "starting sequencer\n";
 #   my ($module, $Opt)  = (@_);
    &validate_state_sequencer_options($Opt);
    my $marker          = e_default_module_marker->new ($module);
    my $top_module_name = $Opt->{'top_module_name'};
    my $device_family   = $Opt->{'device_family'};
    my $system_dir      = $Opt->{'system_directory'};
#print  "starting sequencer\n";
    # Opcode Width Stuff
    $Opt->{'opcode_creg_width'}  = 4 * $Opt->{'use_creg'};
    $Opt->{'opcode_stack_width'} = 4 * $Opt->{'use_stack'};
    if ($Opt->{'use_branch'}) {
	if ($Opt->{'onehot_branch'}) {
	    $Opt->{'opcode_branch_width'} = $Opt->{'branch_input_bits'} + 3;
	} else {
	    $Opt->{'opcode_branch_width'} = &ceil(&log2($Opt->{'branch_input_bits'} + 2)) + 1;
	}
    } else {
	$Opt->{'opcode_branch_width'} = 2;
	$Opt->{'branch_input_bits'}   = 0;
    }
    $Opt->{'opcode_addgen_width'} = 3;
    $Opt->{'opcode_data_width'}   = $Opt->{'system_width'};
    # Make some copy some frequently used Options into local variables.
    my $system_width     = $Opt->{'system_width'};
    my $n_doits          = $Opt->{'dataout_bits'};
    my $stack_cmd_width  = $Opt->{'opcode_stack_width'};
    my $creg_cmd_width   = $Opt->{'opcode_creg_width'};
    my $branch_cmd_width = $Opt->{'opcode_branch_width'};
    my $add_cmd_width    = $Opt->{'opcode_addgen_width'};;
    my $opcode_length    = $stack_cmd_width + $creg_cmd_width + $branch_cmd_width + $add_cmd_width + $n_doits + $system_width +1;#need to add the stop bit. 
    $Opt->{'opcode_length'} = $opcode_length;

    ## Calculate slave data width based on opcode size.
    my $iram_slave_data_width;
    if      ($opcode_length <= 8) {
	$iram_slave_data_width = 8;
    } elsif ($opcode_length <= 16) {
	$iram_slave_data_width = 16;
    } elsif ($opcode_length <= 32) {
	$iram_slave_data_width = 32;
    } elsif ($opcode_length <= 64) {
	$iram_slave_data_width = 64;
    } else {
	die "ERROR: Opcodes over 64 bits wide currently not supported. \n       Opcode width was $opcode_length\n";
    }
    $Opt->{'iram_slave_data_width'} = $iram_slave_data_width;

    # Declare all our ports on the top-level module
    my $iram_be_width = $iram_slave_data_width / 8;
    e_port->adds(["clk",    1,                      "in"],
		 ["reset",         1,                      "in"],
		 ["i_address",     $system_width,          "in"],
		 ["i_byteenable",  $iram_be_width,         "in"],
#	 ["i_chipselect",  1,                      "in"],
		 ["i_write",       1,                      "in"],
		 ["i_read",        1,                      "in"],
		 ["i_writedata",   $iram_slave_data_width, "in"],
		 ["i_readdata",   $iram_slave_data_width, "out"],
		 ["c_address",     1,                      "in"],
#		 ["c_chipselect",  1,                      "in"],
		 ["c_read",        1,                      "in"],
		 ["c_write",       1,                      "in"],
		 ["c_writedata",   32,                     "in"],
		 ["c_byteenable",   4,                     "in"],
		 ["c_readdata",    32,                     "out"],
		 ["data_out",      $n_doits, "out"],
		 ["op_data",	   $system_width, 	   "out"],	
		 );

    # Create a signal for the sequencer internal clock, and assign
    # it appropriately, depending on whether or not asynchronous
    # mode has been selected.
    # Additionally, asynchronous mode changes the number of wait 
    # states from 1/0 (read/write) to "peripheral_controlled".
    # Thus we need to export a waitrequest signal.
#    e_signal->add(['clk' => 1]);
#    if ($Opt->{'use_external_clock'}) {
#	e_port->adds(['external_clk',  1, 'in'],
#		     ['c_waitrequest', 1, 'out']);
#	e_assign->add(['clk' => 'external_clk']);
 #   } else {
#	e_assign->add(['clk' => 'avalon_clk']);
#    }

    # The signal 'module_reset_n' is asserted whenever the
    # global system reset signal (from Avalon) is asserted, or when
    # a write to the reset bit of the sequencer's control register 
    # produces a control_reset pulse.
    # module_reset_n is wired up to all the lower-level modules'
    # reset_n port, with the exception of the control module, which
    # uses the Avalon reset_n signal.
    e_assign->add(['module_reset_n' => '!(control_reset | reset)']);
    # The 'run' signal is output by the control module, and is used
    # as a clock enable for most modules.
    e_signal->add(['run' => 1]);
    e_assign->add([e_signal->new(['reset_n' => 1]) => '~reset']);

    ## Start making the modules. ##

    if ($Opt->{'use_edata'}) { e_port->add(['Edata', $system_width, 'in']); }
    
    if ($Opt->{'use_branch'}) {
	my $branch_module = &make_branch_module($Opt);
	e_instance->add ({
	    module   => $branch_module,
	    port_map => {
		'br'        => 'Branch',
		'zero'      => 'zero',
		'cmd'       => 'branch_cmd',
		'condition' => 'cond',
	    }
	});
    } else {
	# Even if the branch condition input bus is not enabled, 
	# we still support selecting between constant-1 and the
	# counter==zero signal, as well as the 'negate' bit.
	e_assign->add([e_signal->new(['i_condition']) => "(branch_cmd[0]) ? zero : 1\'b1"]);
	e_assign->add([e_signal->new(['cond'])        => 'i_condition ^ branch_cmd[1]']);
    }

    if ($Opt->{'use_stack'}) {
	my $stack_module = &make_stack_module($Opt);
	e_instance->add ({
	    module   => $stack_module,
	    port_map => {
		'clk'            => 'clk',
		'clk_en'         => 'run',
		'condition'      => 'cond',
		'addr_data'      => 'addr_p_1',
		'creg_data'      => 'creg',
		'op_data'        => 'op_data',
		'ext_data'       => 'Edata',
		'cmd'            => 'stack_cmd',
		'reset_n'        => 'module_reset_n',
		'stack'          => 'stack',
	    }
	});
    }

    if ($Opt->{'use_creg'}) {
	my $creg_module = &make_creg_module($Opt);
	e_instance->add ({
	    module   => $creg_module,
	    port_map => {
		'clk'       => 'clk',
		'clk_en'    => 'run',
		'condition' => 'cond',
		'data'      => 'op_data',
		'Edata'     => 'Edata',
		'Sdata'     => 'stack',
		'cmd'       => 'creg_cmd',
		'reset_n'   => 'module_reset_n',
		'count'     => 'creg',
		'zero'      => 'zero',
	    }
	});
    } else {
	# Even if the module is disabled, output some dummy
	# signals, since other modules expect them.
	e_assign->add([e_signal->new(['zero']) => "1\'b1"]);	
	if ($Opt->{'use_stack'}) {
	    e_assign->add([e_signal->new(['creg']) => "$system_width\'b0"]);	
	}
    }

    my $addr_module = &make_addr_module($Opt);
    e_instance->add ({
	module   => $addr_module,
	port_map => {
	    'clk'                      => 'clk',
	    'clk_en'                   => 'run',
	    'zero'                     => 'zero',
	    'condition'                => 'cond',
	    'data'                     => 'op_data',
	    'Edata'                    => 'Edata',
	    'Sdata'                    => 'stack',
	    'cmd'                      => 'add_cmd',
	    'reset_n'                  => 'module_reset_n',
	    'load_pc_from_control_reg' => 'load_pc_from_control_reg',
	    'control_reg_pc_data'      => 'control_reg_pc_data',
	    'address'                  => 'address',
	    'addressp1'                => 'addr_p_1',
	}
    });

    e_assign->add([ 'c_readdata[31:16]' => '16\'b0']);
    my $control_module = &make_control_module($Opt);
    e_instance->add ({
	module   => $control_module,
	port_map => {
	    'a_clk'          => 'clk',
#	    'e_clk'          => 'external_clk',
	    'reset_n'        => 'reset_n',
	    'address'        => 'c_address',
	    'byteenable'     => 'c_byteenable',
	    'write'          => 'c_write',
	    'writedata'      => 'c_writedata[15:0]',
	    'read'           => 'c_read',
	    'readdata'       => 'c_readdata[15:0]',
	    'run'            => 'run',
	    'external_reset' => 'control_reset',
	    'pc'             => 'address',
	    'load_pc'        => 'load_pc_from_control_reg',
	    'pc_loaddata'    => 'control_reg_pc_data',
	    'waitrequest'    => 'c_waitrequest',
	}
    });

    my $iram_module = &make_iram_module($Opt);
    e_instance->add ({
	module => $iram_module,
	port_map=> {
	    'clk'     => 'clk',
	    'external_clk'   => 'external_clk',
	    'reset'          => 'reset',
	    'run'            => 'run',
	    'module_reset_n' => 'module_reset_n',
#	    'avalon_cs'      => 'i_chipselect',
	    'avalon_address' => 'i_address',
	    'avalon_write'   => 'i_write',
	    'avalon_writedata'   => 'i_writedata',
	    'avalon_be'      => 'i_byteenable',
	    'avalon_data'    => 'i_writedata',
	    'avalon_read'    => 'i_read',
	    'avalon_readdata'=> 'i_readdata',
	    'internal_addr'  => 'address',
	    'iram_q'         => 'iram_q',
	}
    });

    ## Humbly declare our slave ports to SOPC Builder, who will
    ## express gratitude by populating the PORT_WIRING sections
    ## of the PTF for us, and by interfacing them properly with
    ## the Avalon bus.
    
    my $instr_type_map = {
	'clk'   => 'clk',
	'reset'        => 'reset',
	'i_address'    => 'address',
	'i_byteenable' => 'byteenable',
	'i_write'      => 'write',
	'i_writedata'  => 'writedata',
	'i_read'       => 'read',
	'i_readdata'   => 'readdata',
    };
    e_avalon_slave->add({
	name     => "instruction_ram_slave",
	type_map => $instr_type_map
    });

    my $control_type_map = {
	'clk'   => 'clk',
	'reset'        => 'reset',
	'c_address'    => 'address',
#	'c_chipselect' => 'chipselect',
	'c_write'      => 'write',
	'c_writedata'  => 'writedata',
	'c_read'       => 'read',
	'c_readdata'   => 'readdata'
    };
#    if ($Opt->{'use_external_clock'}) {
#	$control_type_map->{'c_waitrequest'} = 'waitrequest';
#    }
    e_avalon_slave->add({
	name     => "control_slave",
	type_map => $control_type_map
    });

    e_signal->add(['iram_q' => $opcode_length]);
    
    # Part-out the Instruction RAM output bus, and deliver each
    # opcode chunk to its corresponding module.
    e_signal->adds([ break_doit	     => 1],
		   [ data_out_instr  => $n_doits],
		   [ op_data         => $system_width],
		   [ data_out        => $n_doits],
		   [ branch_cmd      => $branch_cmd_width ],
		   [ add_cmd         => $add_cmd_width ]);
    my $lo_index = 0;
    my $hi_index = $add_cmd_width - 1;
    e_assign->add(['add_cmd'       => "iram_q[$hi_index : $lo_index]"]);
    $lo_index  = $hi_index + 1;
    $hi_index += $branch_cmd_width;
    e_assign->add(['branch_cmd'    => "iram_q[$hi_index : $lo_index]"]);
 
   if ($Opt->{'use_creg'}) {
	e_signal->add([ creg_cmd   => $creg_cmd_width ]);
	$lo_index  = $hi_index + 1;
	$hi_index += $creg_cmd_width;
	e_assign->add(['creg_cmd'  => "iram_q[$hi_index : $lo_index]"]);
    }

    if ($Opt->{'use_stack'}) {
	e_signal->add([ stack_cmd  => $stack_cmd_width ]);
	$lo_index  = $hi_index + 1;
	$hi_index += $stack_cmd_width;
	e_assign->add(['stack_cmd' => "iram_q[$hi_index : $lo_index]"]);
    }
    $lo_index  = $hi_index + 1;
    $hi_index += $Opt->{'system_width'};
    e_assign->add(['op_data'        => "iram_q[$hi_index : $lo_index]"]);
 
    $hi_index += 1;
    e_assign->add(['break_doit' => "iram_q[[$hi_index]"]);
    $Opt->{'break_bit'} = $hi_index;
    
    $lo_index  = $hi_index + 1;
    $hi_index += $n_doits;
    e_assign->add(['data_out_instr' => "iram_q[$hi_index : $lo_index]"]);    
#    $hi_index += 1;
#    e_assign->add(['break_doit' => "iram_q[[$hi_index]"]);
#    $Opt->{'break_bit'}=>$hi_index;

    # MUX the data output bus based on the user option selected.
    # If the user selected GND or VCC, tie all the output bits
    # low or high when the sequencer is not running.
    # If the user specified a custom bitpattern, format that
    # string in Verilog fashion and assign that to dataout when
    # the sequencer is stopped.
    # If the user selected 'Bit pattern of current instruction',
    # just assign dataout to the partselect of the instruction
    # word that we just made.
    my $idle_data_out = $Opt->{'idle_data_out'};
    my $custom_bits   = $Opt->{'custom_idle_data_bitpattern'};
    my $custom_radix  = $Opt->{'custom_idle_data_radix'};
    my $idle_data_exp;
    if ($idle_data_out eq 'instr') {
	e_assign->add(['data_out' => 'data_out_instr']);
    } else {
	if ($idle_data_out eq 'gnd') {
	    $idle_data_exp = "$n_doits\'b0";
	} elsif ($idle_data_out eq 'vcc') {
	    $idle_data_exp = "\{$n_doits\{1\'b1\}\}";
	} else {
	    $idle_data_exp = $n_doits . "\'" . $custom_radix . $custom_bits;
	}
	e_assign->add(['data_out' => "(run) ? data_out_instr : $idle_data_exp"]);
    }

    ## Set up simulation section of PTF based on config options ##
    # Clear the sim section first, so that we don't have any leftover signals
    # from the previous configuration that don't exist anymore.
#    $project->module_ptf()->{SIMULATION} = {};
    # Now populate the sim section and create text muxes for opcodes
#    &update_ptf_with_sim_signals($Options, $module, $project->module_ptf()->{SIMULATION});
generate_variation_file($Opt, $system_dir, $top_module_name);
    return $module;
}





#################################################################
# subroutine make_branch_module
#
# Generates the HDL for the branch module.
# As of 09.10.03, the opcode format is as follows:
#  The (opcode_size - 1) LSB's designate which branch condition
#  is selected for output to the condition bit.  A select value
#  of 0 selects the constant-1 signal, and a select value of 1
#  selects the 'creg==0' signal.  Select value of 2 selects 
#  the LSB of the branch condition input bus.  Selection is
#  encoded in binary or one-hot, depending on user preference.
#  The MSB indicates whether or not the selected bit is
#  inverted before being output to the condition bit.
#
sub make_branch_module {
    my ($Opt)  = (@_);
    my $module = e_module->new({
	name  => $Opt->{'top_module_name'} . '_branch',
    });
    my $marker            = e_default_module_marker->new ($module);
    my $branch_cond       = $Opt->{'branch_input_bits'};
    my $branch_index      = $branch_cond - 1;
    my $onehot            = $Opt->{'onehot_branch'};
    my $size              = $Opt->{'opcode_branch_width'};
    my $mux_size          = $size - 1;
    my $mux_partsel_index = $mux_size - 1;
    my $i;

    # Make opcode symbol definitions for the variation file
    # that goes out to the compiler.
    # These values need to be updated if the hardware or
    # opcode conventions change.
    $Opt->{'opcode_branch_onehot'}       = $onehot;
    $Opt->{'opcode_branch_negate'}       = 2 ** ($size - 1);
    $Opt->{'opcode_branch_creg_zero'}    = ($onehot) ? 2 : 1;
    $Opt->{'opcode_branch_default_pass'} = ($onehot) ? 1 : 0;
    for $i (0..($branch_cond - 1)) {
	$Opt->{"BR$i"} = $onehot ? (2 ** ($i + 2)) : ($i + 2);
    }

    e_signal->adds([ br          => $branch_cond ],
		   [ zero        => 1],
		   [ cmd         => $size],
		   [ condition   => 1],
		   [ i_condition => 1 ]);

    if ($onehot) {
	my $cmd_i;
	my @table = ('cmd[0]', "1\'b1");
	push @table, ('cmd[1]', 'zero');
	for $i (0..($branch_cond-1)) {
	    $cmd_i = $i + 2;
	    push @table, ("cmd[$cmd_i]", "br[$i]");
	}
	e_mux->add({
	    lhs   => 'i_condition',
	    type  => 'and_or',
	    table => \@table,
	});
    } else {
	my %case_hash = 
	    (
	     "$mux_size\'b0" => [e_assign->new(['i_condition' => "1\'b1"])],
	     "$mux_size\'b1" => [e_assign->new(['i_condition' => "zero"])],
	     'default'       => [e_assign->new(['i_condition' => "1\'b1"])],
	     );
	my ($i, $case_i);
	for $i (0..($branch_cond-1)) {
	    $case_i = $i + 2;
	    $case_hash{"$mux_size\'d$case_i"} = [e_assign->new(['i_condition' => "br\[$i\]"])];
	}
	e_assign->add([e_signal->add(['mux_switch' => $mux_size]) => "cmd[$mux_partsel_index:0]"]);
	e_process->add({
	    clock    => "",
	    comment  => "case statement process",
	    contents => 
		[e_case->new({
		    switch   => 'mux_switch',
		    full     => 1,
		    parallel => 1,
		    contents => {%case_hash}
		})],
	});
    }
    # XOR with the MSB of the opcode.
    e_assign->add(['condition' => "cmd[$mux_size] \^ i_condition"]);
    # Cal: if we wanted to register the condition bit...
#    e_register->add({
#	out         => 'condition',
#	in          => "cmd[$mux_size] \^ i_condition",
#	async_value => "1\'b0",
#	enable      => 'clk_en',
#    });



    return $module;
}



#################################################################
# subroutine make_stack_module
#
# As of 09.10.03, the opcode format is as follows:
#  opcode[1:0]
#    00 noop
#    01 pop on cond
#    10 push on cond (data from mux selected by opcode MSB's below)
#    11 noop
#  opcode[3:2]
#    00 address+1
#    01 creg (if enabled)
#    10 opcode data
#    11 external data (if enabled)
sub make_stack_module {
    my ($Opt)  = (@_);
    my $module = e_module->new({
	name  => $Opt->{'top_module_name'} . '_stack',
    });
    my $marker = e_default_module_marker->new ($module);
    my $data_width             = $Opt->{'system_width'};
    my $opcode_width           = $Opt->{'opcode_stack_width'};
    my $data_index             = $data_width - 1;
    my $stackram_address_width = $Opt->{'stack_depth'};
    my $stackram_numwords      = 2 ** $stackram_address_width;

    # Make opcode symbol definitions for the variation file
    # that goes out to the compiler.
    # These values need to be updated if the hardware or
    # opcode conventions change.
    $Opt->{'opcode_stack_push_creg'}    = 6;    
    $Opt->{'opcode_stack_push_address'} = 2; 
    $Opt->{'opcode_stack_pop'}          = 1;          
    $Opt->{'opcode_stack_nop'}          = 0;          
    $Opt->{'opcode_stack_push_data'}    = 10;   
    $Opt->{'opcode_stack_push_edata'}   = 14;  

    e_port->adds(['clk',       1,             'in'],
		 ['clk_en',    1,             'in'],
		 ['condition', 1,             'in'],
		 ['addr_data', $data_width,   'in'],
		 ['creg_data', $data_width,   'in'],
		 ['op_data',   $data_width,   'in'],
		 ['cmd',       $opcode_width, 'in'],
		 ['reset_n',   1,             'in'],
		 ['stack',     $data_width,   'out']);

    e_signal->add(['add' => $stackram_address_width]);
    # If opcode is a push, increment.  Otherwise decrement the address reg.
    e_assign->add([e_signal->new(['next_add'=>$stackram_address_width]) => "(cmd[1] ==2\'b1)? add_r+1:add_r-1"]);
    e_assign->add([e_signal->new(['load'=>1]) => "(cmd[1:0] == 2\'b10) & condition"]);
 
    e_register->add({
	out         => e_signal->new(['add_r' => $stackram_address_width]),
	in          => 'add',                                               
	async_value => "$stackram_address_width\'b0",              
	enable      => 'clk_en',                                        
    });                                                            

    # If we're configured to use the external data port, then we'll
    # want to use edata as the load value on opcode 11.  Otherwise,
    # we'll give it the default (addr_data)
    my $value_to_load_on_11;
    if ($Opt->{'use_edata'}) {
	$value_to_load_on_11 = 'ext_data';
	e_port->add(['ext_data', $data_width, 'in']);
    } else {
	$value_to_load_on_11 = 'addr_data';
    }

    e_signal->add(['load_value' => $data_width]);
    e_assign->add([e_signal->new(['load_value_mux_switch'=>2]) => "cmd[3:2]"]);
    e_process->add({
	clock    => "",
	contents => [e_case->new({
	    switch   => 'load_value_mux_switch',
	    parallel => 1,
	    full     => 1,
	    contents => {
		"2\'b00"  => ['load_value' => 'addr_data'],
		"2\'b01"  => ['load_value' => 'creg_data'],
		"2\'b10"  => ['load_value' => 'op_data'],
		"2\'b11"  => ['load_value' => $value_to_load_on_11],
		'default' => ['load_value' => 'addr_data'],
	    },
	})],	
    });
   
    e_process->add({
	clock    => "",
	contents => [e_if->new({
	    comment   => 'nop',
	    condition => "cmd[1:0] == 2\'b00",
	    then      => ['add', 'add_r'],
	    else      => [e_if->new({
		comment   => 'down count (pop)',
		condition => "(cmd[1:0] == 2\'b01) & condition",
		then      => ['add','next_add'],
		else      => [e_if->new({
		    comment   => 'count up (load)',
		    condition => "(cmd[1:0] == 2\'b10) & condition",
		    then      => ['add', 'next_add'],
		    else      => ['add', 'add_r'],
		})],
	    })],
	})],
#	asynchronous_contents => [e_assign->new({lhs => 'add', rhs => "10\'b0"})]
    });

    # Instantiate an altsyncram that implements the stack storage.
    my $device_family = $Opt->{'device_family'};
    print "device family $device_family" ;
    my $ram_in_port_map = {
	wren_a    => 'load',
	data_a    => 'load_value',
	clock0    => 'clk',
	address_a => 'next_add',
	address_b => 'add'
    };
    my $ram_out_port_map = {
	q_b       => 'stack'
    };
    my $ram_parameter_map = {
	intended_device_family => qq("$device_family"),
	operation_mode         => qq("DUAL_PORT"),
	width_a                => $data_width,
	widthad_a              => $stackram_address_width,
	numwords_a             => $stackram_numwords,
	width_b                => $data_width,
	widthad_b              => $stackram_address_width,
	numwords_b             => $stackram_numwords,
	lpm_type               => qq("altsyncram"),
	width_byteena_a        => 1,
	outdata_reg_b          => qq("UNREGISTERED"),
	indata_aclr_a          => qq("NONE"),
	wrcontrol_aclr_a       => qq("NONE"),
	address_aclr_a         => qq("NONE"),
	address_reg_b          => qq("CLOCK0"),
	address_aclr_b         => qq("NONE"),
	outdata_aclr_b         => qq("NONE"),
	ram_block_type         => qq("AUTO"),
	read_during_write_mode_mixed_ports => qq("DONT_CARE"),
    };
    e_blind_instance->add({
	tag            => 'compilation',
	use_sim_models => 1,
	name           => $Opt->{'top_module_name'} . "_stack_ram", 
	module         => 'altsyncram',
	in_port_map    => $ram_in_port_map,
	out_port_map   => $ram_out_port_map,
	parameter_map  => $ram_parameter_map
    });
    e_blind_instance->add({
	tag            => 'simulation',
	use_sim_models => 1,
	name           => $Opt->{'top_module_name'} . "_stack_ram", 
	module         => 'altsyncram',
	in_port_map    => $ram_in_port_map,
	out_port_map   => $ram_out_port_map,
	parameter_map  => $ram_parameter_map
    });
    return $module;
}




#################################################################
# subroutine make_creg_module
#
# As of 09.10.03, the opcode format is as follows:
#  opcode[3]   - down count until (condition OR zero), then do
#                op specified by opcode[2:0]
#  opcode[2:0]
#    000 noop
#    001 decrement on condition
#    100 load opcode data on condition
#    101 load opcode data on fail condition
#    110 load external data on condition
#    111 load stack data on condition
sub make_creg_module {
    my ($Opt)  = (@_);
    my $module = e_module->new({
	name  => $Opt->{'top_module_name'} . '_creg',
    });
    my $marker    = e_default_module_marker->new ($module);
    my $size      = $Opt->{'system_width'};
    my $cmd_width = $Opt->{'opcode_creg_width'};

    # Make opcode symbol definitions for the variation file
    # that goes out to the compiler.
    # These values need to be updated if the hardware or
    # opcode conventions change.
    $Opt->{'opcode_creg_dec'}        = 1;
    $Opt->{'opcode_creg_load_data'}  = 4;
    $Opt->{'opcode_creg_load_edata'} = 6;
    $Opt->{'opcode_creg_load_stack'} = 7;
    $Opt->{'opcode_creg_decn'}       = 8;
    $Opt->{'opcode_creg_nop'}        = 0;

    e_port->adds(['clk',       1,          'in'],
		 ['clk_en',    1,          'in'],
		 ['condition', 1,          'in'],
		 ['data',      $size,      'in'],
		 ['cmd',       $cmd_width, 'in'],
		 ['reset_n',   1,          'in'],
		 ['zero',      1,          'out']);

    e_signal->add(['load_value' => $size]);
    
    # MUX inputs into the load values as appropriate for this config.
    if ($Opt->{'use_stack'} && $Opt->{'use_edata'}) {
	e_port->add(['Edata', $size, 'in']);
	e_port->add(['Sdata', $size, 'in']);
	e_port->add(['count', $size, 'out']);
	e_assign->add(['load_value' => "(cmd[1]==1\'b0)?data:((cmd[1:0]==2\'b10)?Edata:Sdata)"]);
    } elsif ($Opt->{'use_edata'}) {
	e_port->add(['Edata', $size, 'in']);
	e_assign->add(['load_value' => "(~cmd[1]) ? data : Edata"]);
    } elsif ($Opt->{'use_stack'}) {
	e_port->add(['Sdata', $size, 'in']);
	e_port->add(['count', $size, 'out']);
	e_assign->add(['load_value' => "(~cmd[1]) ? data : Sdata"]);
    } else {
	e_assign->add(['load_value' => 'data']);
    }

    e_signal->adds(['enable' => 1],
		   ['load'   => 1]);

    e_process->add({
	clock    => "",   
	contents => [
		     e_if->new({
			 comment   => 'if MSB of cmd is high, downcount until condition||zero',
			 condition => "(cmd[3]) & !condition & !zero",
			 then      => [e_assign->new(['enable' => "1"]),
				       e_assign->new(['load'   => "0"])],
			 else => [e_if->new({
			     comment   => 'down count',
			     condition => "(cmd[2:0] == 3\'b001) & condition & !zero",
			     then      => [e_assign->new(['enable' => "1"]),
					   e_assign->new(['load'   => "0"])],
			     else      => [e_if->new({
# We decided to remove this opcode and make it its own opcode bit.				 
#				 comment => 'down count on not condition',
#				 condition => "(cmd == 3\'b010) & ~condition & !zero",
#				 then => [e_assign->new(['enable' => "1"]),
#					  e_assign->new(['load'   => "0"])],
#				 else => [e_if->new({
				 comment   => '',
				 condition => "(cmd[2:0] == 3\'b100) & condition",
				 then      => [e_assign->new(['enable' => "0"]),
					       e_assign->new(['load'   => "1"])],
				 else      => [e_if->new({
				     comment   => '',
				     condition => "(cmd[2:0] == 3\'b101) & ~condition",
				     then      => [e_assign->new(['enable' => "0"]),
						   e_assign->new(['load'   => "1"])],
				     else      => [e_if->new({
					 comment   => "cmd[2:0] == 3\'b11x",
					 condition => "cmd[1] & cmd[2] & condition",
					 then      => [e_assign->new(['enable' => "0"]),
						       e_assign->new(['load'   => "1"])],
					 else      => [e_assign->new(['enable' => "0"]),
						       e_assign->new(['load'   => "0"])],
				     })],
				 })],
#				 })],
			     })],
			 })],
		     })],
    });

    e_signal->adds(['count' => $size],
		   ['zero'  => 1]);
    e_assign->add([e_signal->new(['count_mux_switch' => 2]) => '{load, enable} & {2{clk_en}}']);
    e_assign->add(['zero' => '(count == 0)']);
    e_process->add({
	asynchronous_contents => [e_assign->new(['count' => "$size\'b0"])],
	contents     => [e_case->new({
	    switch   => 'count_mux_switch',
	    parallel => 1,
	    full     => 1,
	    contents => {
		"2\'b10"  => ['count' => 'load_value'],
		"2\'b01"  => ['count' => 'count-1'],
		'default' => ['count' => 'count'],
	    },
	})],
    });
    return $module;
}



#################################################################
# subroutine make_addr_module
#
# As of 09.10.03, the opcode format is as follows:
#  opcode[0]
#    0  if condition, goto address specified by opcode[2:1]
#       otherwise, increment address
#    1  if condition, goto address specified by opcode[2:1]
#       otherwise, maintain current address until creg goes to
#       zero, then increment address
#  opcode[2:1]
#   00  address+1
#   01  opcode data
#   10  stack data
#   11  external data
#
sub make_addr_module {
    my ($Opt)  = (@_);
    my $module = e_module->new({
	name  => $Opt->{'top_module_name'} . '_addr',
    });
    my $marker       = e_default_module_marker->new ($module);
    my $system_width = $Opt->{'system_width'};
    my $cmd_width    = $Opt->{'opcode_addgen_width'};

    # Make opcode symbol definitions for the variation file
    # that goes out to the compiler.
    # These values need to be updated if the hardware or
    # opcode conventions change.
    $Opt->{'opcode_addgen_continue'}  = 0;
    $Opt->{'opcode_addgen_data'}      = 2;
    $Opt->{'opcode_addgen_stack'}     = 4;
    $Opt->{'opcode_addgen_edata'}     = 6;
    $Opt->{'opcode_addgen_wait_creg'} = 1;
    $Opt->{'opcode_addgen_wait'}      = 1;

    e_port->adds(['clk',                      1,             'in'],
		 ['clk_en',                   1,             'in'],
		 ['zero',                     1,             'in'],
		 ['condition',                1,             'in'],
		 ['data',                     $system_width, 'in'],
		 ['cmd',                      $cmd_width,    'in'],
		 ['reset_n',                  1,             'in'],
		 ['load_pc_from_control_reg', 1,             'in'],
		 ['control_reg_pc_data',      $system_width, 'in'],
		 ['address',                  $system_width, 'out']);

    if ($Opt->{'use_stack'}) {
	e_port->add(['addressp1',             $system_width, 'out']);
    }

    e_signal->add(['next_add' => $system_width]);

    e_register->add({
	out         => e_signal->new(['current_addr', $system_width]),
	in          => 'load_pc_from_control_reg ? control_reg_pc_data : address',
	async_value => "$system_width\'b0",
	enable      => "clk_en | load_pc_from_control_reg",
    });
    e_assign->add([e_signal->new(['addressp1'=>$system_width]) => 'current_addr + 1']);

    if ($Opt->{'use_stack'} && $Opt->{'use_edata'}) {
	e_port->add(['Edata', $system_width, 'in']);
	e_port->add(['Sdata', $system_width, 'in']);
    } elsif ($Opt->{'use_edata'}) {
	e_port->add(['Edata', $system_width, 'in']);
	e_assign->add([e_signal->new(['Sdata'=>$system_width]) => "$system_width\'b0"]);

    } elsif ($Opt->{'use_stack'}) {
	e_port->add(['Sdata', $system_width, 'in']);
	e_assign->add([e_signal->new(['Edata'=>$system_width]) => "$system_width\'b0"]);
    }

    if ($Opt->{'use_stack'} || $Opt->{'use_edata'}) {
	e_assign->add([e_signal->new(['next_addr_mux_switch' => 2]) => 'cmd[2:1]']);
	e_process->add({
	    clock    => "",
	    contents => [e_case->new({
		switch   => 'next_addr_mux_switch',
		parallel => 1,
		full     => 1,
		contents => {
		    "2\'b00" => ['next_add' => 'addressp1'],
		    "2\'b01" => ['next_add' => 'data'],
		    "2\'b10" => ['next_add' => 'Sdata'],
		    "2\'b11" => ['next_add' => 'Edata'],
		},
	    })],
	});
    } else {
	# If we don't have stack data or external data, next_add
	# only switches between opcode data and address+1
	e_assign->add(['next_add' => '(cmd[1]) ? data : addressp1']);
    }

    e_assign->add([e_signal->new(['address_mux_switch' => 3]) => '{condition, cmd[0], zero}']);
    # [DJL 09.10.03]
    # For some reason, using the asynchronous_contents field to implement an "if (reset_n == 0)"
    # in this combinatorial process block (i.e., not clocked), doesn't work in vhdl.
    # Simulation shows that the reset_n signal doesn't have any effect on the process output.
    # Does in Verilog, though.  Funny.
    e_signal->add(['address_before_reset' => $system_width]); # vhdl fix
    e_process->add({
	clock => "",
#	asynchronous_contents => [e_assign->new(['address' => "$system_width\'b0"])],  # before vhdl fix
	contents =>
              [e_case->new({
		switch   => 'address_mux_switch',
		parallel => 1,
		full     => 1,
		contents => {
		    "3\'b100" => ['address_before_reset' => 'next_add'],
		    "3\'b101" => ['address_before_reset' => 'next_add'],
		    "3\'b110" => ['address_before_reset' => 'next_add'],
		    "3\'b111" => ['address_before_reset' => 'next_add'],
		    "3\'b000" => ['address_before_reset' => 'addressp1'],
		    "3\'b001" => ['address_before_reset' => 'addressp1'],
		    "3\'b010" => ['address_before_reset' => 'current_addr'],
		    "3\'b011" => ['address_before_reset' => 'current_addr'],
		    'default' => ['address_before_reset' => 'addressp1'],
		}
	    })],
    });    
    e_assign->add(['address' => "address_before_reset & {$system_width\{reset_n}}"]);  # vhdl fix
    return $module;
}




#################################################################
# subroutine make_control_module
#
# The control module implements a memory mapped interface for
# starting, stopping, and reseting the sequencer, as well as setting 
# the program counter.  It is half of the sequencer's interface to
# the Avalon bus.  The Instruction RAM module implements the other
# half.  If the sequencer is configured to operate using the Avalon
# clock (synchronous mode), the control module's task is simple --
# implement the following memory-mapped register structure:
#   16-bit register at address 0:
#     bit 0: start/stop
#     bit 1: reset
#   16-bit register at address 1:
#     bits 0-15: program counter
# These are read/write registers.
# The control module outputs the following signals:
#   readdata       - Exported to the Avalon bus
#   run            - Value of the start/stop bit in the control
#                    register.  This signal should be used as
#                    a clock enable for all other sequencer modules.
#   external_reset - Asserted when a "1" has been written to the
#                    reset bit of the control register.  This value,
#                    OR'ed with the global system reset, should 
#                    serve as the reset signal for all other
#                    sequencer modules.
#   load_pc        - Asserted when an Avalon master has written to
#                    the program counter register.  Signals the
#                    Address module that the next address should
#                    be loaded from the control module.
#   pc_loaddata    - Data to be used as the next address, loaded
#                    from Avalon.
# If the sequencer is configured to use an external clock
# (asynchronous mode), we need to synchronize the signals
# coming in from Avalon before we can use them in the sequencer.
# We use an array of sequencer modules to accomplish this task.
# Since asynchronous mode requires control reads/writes to have
# "Peripheral_Controlled" wait states, we also need to generate
# a waitrequest signal.  This gets somewhat complicated, but we
# essentially assert waitrequest as soon as an Avalon transfer is
# initiated, follow the read/write signal through its
# synchronization/registration path to determine when its data
# is ready (in the case of a read), or when its data has been
# is synchronized and ready to be used by the sequencer (in the
# case of a write).  As soon as we see that the signal is through
# synchronization, we generate a pulse that pulls waitrequest
# down.
sub make_control_module {
    my ($Opt)  = (@_);
    my $module = e_module->new({
	name  => $Opt->{'top_module_name'} . '_control'
	});
    my $marker        = e_default_module_marker->new ($module);
    my $system_width  = $Opt->{'system_width'};
    my $reset_running = $Opt->{'reset_running'};
    my $data_width    = 16;

    e_port->adds(['a_clk',          1,             'in'],
		 ['reset_n',        1,             'in'],
		 ['address',        1,             'in'],
		 ['byteenable',     2,             'in'],
		 ['write',          1,             'in'],
		 ['writedata',      $data_width,   'in'],
		 ['read',           1,             'in'],
		 ['pc',             $system_width, 'in'],
		 ['readdata',       $data_width,   'out'],
		 ['run',            1,             'out'],
		 ['external_reset', 1,             'out'],
		 ['load_pc',        1,             'out'],
		 ['pc_loaddata',    $system_width, 'out'],
		 );

    # synchronize interface signals if we need to.
    my ($address_signal, $write_signal, $writedata_signal, $read_signal, $readdata_signal, $byteenable_signal);
#     if ($Opt->{'use_external_clock'}) {
# 	($address_signal, $chipselect_signal, $write_signal, $writedata_signal, $read_signal, $readdata_signal) =
# 	    ('address_sync', 'chipselect_sync', 'write_sync', 'writedata_sync', 'read_sync', 'readdata_async');
# 	e_port->adds(['e_clk',       1, 'in'],
# 		     ['waitrequest', 1, 'out']);
# 	e_signal->adds(['address_sync'              => 1],
# 		       ['chipselect_sync'           => 1],
# 		       ['write_sync'                => 1],
# 		       ['writedata_sync'            => $data_width],
# 		       ['read_sync'                 => 1],         
# 		       ['readdata_ready'            => 1]);
# 	
# 	# Stall Avalon until either:
# 	#   - We know we've registered the writedata, so we no longer
# 	#     need Avalon to hold it there for us
# 	#   - We've gone and fetched the readdata, and synchronized
# 	#     it to the Avalon clock.
# 	e_assign->add(['waitrequest' => 'chipselect & (write & ~write_resync_pulse | read & ~readdata_ready)']);
# 	
# 	# There are two types of signals we'll be synchronizing here...
# 	# 1-bit signals, and buses as wide as the system.  
# 	# Well, technically the data buses are 16 bits wide, but if
# 	# the system's not 16 bits, we don't really care about the
# 	# other bits.
# 	my $sync_module_1bit       = &make_synchronizer_module(1);
# 	my $sync_module_data_width = &make_synchronizer_module($data_width);
# 
# 	# Synchronize everything!
# 	e_instance->add({
# 	    name     => 'address_synchronizer',
# 	    module   => $sync_module_1bit,
# 	    port_map => {
# 		'clk_in'      => 'a_clk',
# 		'clk_out'     => 'e_clk',
# 		'signal_in'   => 'address',
# 		'signal_out'  => 'address_sync',
# 		'reset_n'     => 'reset_n',
# 		'clk_en'      => "1\'b1",
# 	    }
# 	});
# 	e_instance->add({
# 	    name     => 'chipselect_synchronizer',
# 	    module   => $sync_module_1bit,
# 	    port_map => {
# 		'clk_in'      => 'a_clk',
# 		'clk_out'     => 'e_clk',
# 		'signal_in'   => 'chipselect',
# 		'signal_out'  => 'chipselect_sync',
# 		'reset_n'     => 'reset_n',
# 		'clk_en'      => "1\'b1",
# 	    }
# 	});
# 	e_instance->add({
# 	    name     => 'write_synchronizer',
# 	    module   => $sync_module_1bit,
# 	    port_map => {
# 		'clk_in'     => 'a_clk',
# 		'clk_out'    => 'e_clk',
# 		'signal_in'  => 'write',
# 		'signal_out' => 'write_sync',
# 		'reset_n'    => 'reset_n',
# 		'clk_en'     => "1\'b1",
# 	    }
# 	});
# 	e_instance->add({
# 	    name     => 'writedata_synchronizer',
# 	    module   => $sync_module_data_width,
# 	    port_map => {
# 		'clk_in'     => 'a_clk',
# 		'clk_out'    => 'e_clk',
# 		'signal_in'  => 'writedata',
# 		'signal_out' => 'writedata_sync',
# 		'reset_n'    => 'reset_n',
# 		'clk_en'     => "1\'b1",
# 	    }
# 	});
# 
# 	# Create some synchronizers to re-sync the write signal
# 	# back to the Avalon clock, and eventually create a pulse
# 	# one Avalon clock period wide that we can use to effectively
# 	# de-assert waitrequest as soon as we no longer need Avalon 
# 	# to keep giving us the writedata.
# 	e_instance->add({
# 	    name     => 'write_resynchronizer',
# 	    module   => $sync_module_1bit,
# 	    port_map => {
# 		'clk_in'     => 'e_clk',
# 		'clk_out'    => 'a_clk',
# 		'signal_in'  => 'write_sync',
# 		'signal_out' => 'write_resync',
# 		'reset_n'    => 'reset_n',
# 		'clk_en'     => "1\'b1",
# 	    }
# 	});
# 	e_register->add({
# 	    out         => 'write_resync_delayed',
# 	    in          => 'write_resync',
# 	    async_value => "1\'b0",
# 	    enable      => "1\'b1",
# 	    clock       => 'a_clk',
# 	});
# 	e_assign->add(['write_resync_pulse' => 'write_resync & ~write_resync_delayed']);
# 
# 	# Do the equivalent thing for the read signal, except
# 	# add extra registration to account for the delay in 
# 	# fetching readdata.  The outcome of all this is a pulse
# 	# that tells us when we've got valid readdata, so we can
# 	# pull waitrequest down and get on with our lives.
# 	e_instance->add({
# 	    name     => 'read_synchronizer',
# 	    module   => $sync_module_1bit,
# 	    port_map => {
# 		'clk_in'     => 'a_clk',
# 		'clk_out'    => 'e_clk',
# 		'signal_in'  => 'read',
# 		'signal_out' => 'read_sync',
# 		'reset_n'    => '~readdata_ready',
# 		'clk_en'     => "1\'b1",
# 	    }
# 	});
# 	e_instance->add({
# 	    name     => 'readdata_synchronizer',
# 	    module   => $sync_module_data_width,
# 	    port_map => {
# 		'clk_in'     => 'e_clk',
# 		'clk_out'    => 'a_clk',
# 		'signal_in'  => 'readdata_async',
# 		'signal_out' => 'readdata',
# 		'reset_n'    => 'reset_n',
# 		'clk_en'     => "1\'b1",
# 	    }
# 	});
# 	e_register->add({
# 	    out         => e_signal->new(['read_sync_delayed' => 1]),
# 	    in          => "read_sync",
# 	    async_value => "1\'b0", 
# 	    enable      => "1\'b1",
# 	});
# 	e_signal->add(['read_sync_delayed_resynced' => 1]);
# 	e_instance->add({
# 	    name     => 'read_sync_delayed_synchronizer',
# 	    module   => $sync_module_1bit,
# 	    port_map => {
# 		'clk_in'     => 'e_clk',
# 		'clk_out'    => 'a_clk',
# 		'signal_in'  => 'read_sync_delayed',
# 		'signal_out' => 'read_sync_delayed_resynced',
# 		'reset_n'    => 'reset_n',
# 		'clk_en'     => "1\'b1",
# 	    }
# 	});
# 	e_register->add({
# 	    out         => e_signal->new(['read_sync_delayed_resynced_delayed' => 1]),
# 	    in          => "read_sync_delayed_resynced",
# 	    async_value => "1\'b0", 
# 	    enable      => "1\'b1",
# 	    clock       => 'a_clk',
# 	});
# 	e_assign->add(['readdata_ready' => 'read_sync_delayed_resynced & ~read_sync_delayed_resynced_delayed']);
#     } else {
	($address_signal, $write_signal, $writedata_signal, $read_signal, $readdata_signal, $byteenable_signal) =
	    ('address',  'write', 'writedata', 'read', 'readdata', 'byteenable');
#    }

    # Implement the control registers.
    e_register->add({
#	out         => 'run',                     # 
	out         => 'run_reg',                 #
	in          => "$writedata_signal\[0]",
	async_value => "1\'b$reset_running", 
	enable      => "$byteenable_signal\[0] & $write_signal & \~$address_signal ",
    });

    # Create some registers/signals for the step bit.
    # We only want run to go high for one cycle, so we need
    # to make an edge detector.
    e_signal->add(['step' => 1]);
    e_assign->add(['step' => "$write_signal & \~$address_signal  & $writedata_signal\[2]"]);
    e_register->add({
	out         => 'step_delayed',
	in          => 'step',
	async_value => "1\'b0", 
	enable      => "1\'b1",
    });
    e_signal->add(['step_pulse']);
    e_assign->add(['step_pulse' => 'step & ~step_delayed']);
    e_signal->add(['step_pulse_reg']);
    e_register->add({
	out         => 'step_pulse_reg',
	in          => 'step_pulse',
	async_value => "1\'b0", 
	enable      => "1\'b1",
    });
    e_assign->add(['run' => 'run_reg | step_pulse_reg']);

    e_register->add({
	enable      => "1\'b1",
	async_value => "1\'b1",
	out         => 'external_reset',
	in          => "$byteenable_signal\[0] &  $write_signal & ~$address_signal & $writedata_signal\[1]",
    });
    e_register->add({
	out         => 'load_pc',
	in          => "$byteenable_signal\[0] & $byteenable_signal\[1] &  $write_signal & $address_signal",
	async_value => "1\'b0",
	enable      => "1\'b1",
    });
    e_register->add({
	out         => 'pc_loaddata',
	in          => "$writedata_signal\[$system_width-1:0\]",
	enable      => "1\'b1",
	async_value => "$data_width\'b0",
    });
    my $fill0 = $data_width - $system_width;
    my $fill1 = $data_width -2;
    e_register->add({
	out         => $readdata_signal,
	in          => "$address_signal ? {$fill0\'b0 ,pc }: {$fill1\'b0, external_reset, run}",
	enable      => "$read_signal",
	async_value => "$data_width\'b0",
    });
    return $module;
}





#################################################################
# subroutine make_synchronizer_module
#
# This routine implements the djl_synchronizer module.  It can
# be configured to be any width, and in HDL the module name 
# will be: "djl_synchronizer_<width>_bit".
# The djl_synchronizer synchronizes a signal between two different 
# clock domains, simply by registering in the originating domain,
# then registering in the destination domain.  This method
# leaves the possibility of missing pulses, etc., but it works
# for the limited set of cases encountered in the control module.
# sub make_synchronizer_module {
#     my $width  = shift;
#     my $module = e_module->new({
# 	name => "djl_synchronizer_$width\_bit",
#     });
#     my $marker = e_default_module_marker->new($module);
# 
#     e_port->adds(['clk_in',     1,      'in'],
# 		 ['clk_out',    1,      'in'],
# 		 ['signal_in',  $width, 'in'],
# 		 ['signal_out', $width, 'out'],
# 		 ['reset_n',    1,      'in'],
# 		 ['clk_en',     1,      'in']);
#     e_signal->add(['intermediate' => $width]);
#     e_register->add({
# 	clock       => 'clk_in',
# 	out         => 'intermediate',
# 	in          => 'signal_in',
# 	async_value => "$width\'b0",
# 	enable      => 'clk_en',
#     });
#     e_register->add({
# 	clock       => 'clk_out',
# 	out         => 'signal_out',
# 	in          => 'intermediate',
# 	async_value => "$width\'b0",
# 	enable      => 'clk_en',
#     });
#     return $module;
# }




#################################################################
# subroutine make_iram_module
#
# Makes the Instruction RAM module for the sequencer.
# RAM is broken up into 8 bit chunks that run in parallel to 
# store complete instruction words.  The RAM blocks are dual-port
# Synchronous RAM's -- the write port allows an Avalon master
# to program the sequencer, and the read port is used internally
# to fetch instruction words.  If the user configures the
# sequencer to run in asynchronous mode, these ports use different
# clocks.  The purpose of this module is to implement the program
# storage, and to abstract away the division/parallelization of
# the RAM blocks.
# Since the blocks run in parallel, all address bus values
# correspond to the instruction address.  The generator configures
# the Instruction RAM Slave Port to have a data bus as wide as
# one instruction word.  Byte-enables are used to support narrow
# masters, byte-writes, etc.  There's not much logic here --
# just some part-selecting and a couple OR's and AND's.
# 
sub make_iram_module {
    my ($Opt) = @_;
    my $module = e_module->new({
	name  => $Opt->{'top_module_name'} . '_instr_ram'
	});
    my $marker                    = e_default_module_marker->new ($module);
    my $iram_slave_width          = $Opt->{'iram_slave_data_width'};
    my $opcode_length             = $Opt->{'opcode_length'};
    my $be_width                  = $iram_slave_width / 8;
    my $system_width              = $Opt->{'system_width'};
    my $effective_iram_data_width = (&ceil($opcode_length / 8)) * 8;
    my $effective_be_width        = $effective_iram_data_width / 8;
    my $system_dir                = $Opt->{'system_directory'};
    my $top_module_name           = $Opt->{'top_module_name'};
#    my $instr_ram_initfile        = "$system_dir\/$top_module_name\_instr_ram_block";
    my $instr_ram_initfile        = "$top_module_name\_instr_ram";
    my $language                  = $Opt->{'language'};
    my $device_family 		  = $Opt->{'device_family'};
    my $iram_depth      	  = $Opt->{'imemory_depth'};
 #   my $use_external_clock        = $Opt->{'use_external_clock'};

 #   my $nRAMs = &ceil($effective_iram_data_width / 8);
 #   $Opt->{'n_8bit_ram_chunks'} = $nRAMs;
    e_port->adds(['clk',     1,                 'in'],
		 ['reset',          1,                 'in'],
		 ['run',            1,                 'in'],
		 ['module_reset_n', 1,                 'in'],
		 ['avalon_address', $system_width,     'in'],
		 ['avalon_write',   1,                 'in'],
		 ['avalon_be',      $be_width,         'in'],
		 ['avalon_writedata',$iram_slave_width, 'in'],
		 ['avalon_readdata', $iram_slave_width, 'out'],
		 ['avalon_read',    1, 			'in'],
		 ['internal_addr',  $system_width,     'in'],
		 ['iram_q',         $opcode_length,    'out'],
		 );
		 
 $Opt->{'effective_iram_data_width'} = $effective_iram_data_width;
    # Use the sequencer (external to Avalon) clock if we're
    # configured to run in asynchronous mode.
#    e_signal->add(['rd_clk' => 1]);
#    if ($use_external_clock) {
#	e_port->add(['external_clk', 1, 'in']);
#	e_assign->add(['rd_clk' => 'external_clk']);
#    } else {
#	e_assign->add(['rd_clk' => 'avalon_clk']);
#    }

    # We only want to read if the sequencer is running.  And also if
    # we're resetting, because otherwise the iram won't load the
    # instruction at address zero.
    e_assign->add([e_signal->new(['iram_rdclken']) => 'run | ~module_reset_n']);
    # This one's a no-brainer.
 #   e_assign->add([e_signal->new(['iram_we'])      => 'avalon_cs & avalon_write']);

    # Make the standard parameter hashes somewhere else so we don't
    # have to look at them.
 #  my ($ram_parameter_map, $ram_in_port_map) = &initialize_iram_parameter_maps($Opt);


 my $mif_file = "$instr_ram_initfile"."\_packed\.hex";
 # is the avalon side 
 #b is the sequencer side
   my $ram_parameter_map = {
	intended_device_family => qq("$device_family"),
	operation_mode         => qq("BIDIR_DUAL_PORT"),
	width_a                => $effective_iram_data_width,
	widthad_a              => $iram_depth,
	width_b                => $effective_iram_data_width,
	widthad_b              => $iram_depth,
	lpm_type               => qq("altsyncram"),
	width_byteena_a        => $effective_be_width,
	byte_size              => 8,
	outdata_reg_b          => qq("UNREGISTERED"),
	outdata_reg_a          => qq("UNREGISTERED"),
#	outdata_reg_b          => qq("REGISTERED"),    # Cal: Registered memory output!
	address_reg_b          => qq("CLOCK0"),
	indata_reg_b	       => qq("CLOCK0"),
	wrcontrol_wraddress_reg_b =>qq("CLOCK0"),
	address_aclr_a         => qq("CLEAR0"),
	address_aclr_b         => qq("CLEAR0"),
	init_file              => qq("$mif_file"),
	read_during_write_mode_mixed_ports => qq("DONT_CARE"),
	clock_enable_input_a => qq("NORMAL"),
	clock_enable_input_b => qq("NORMAL"),
	clock_enable_output_a => qq("BYPASS"),
	clock_enable_output_b => qq("BYPASS"),
    };
    my $ram_in_port_map = {
        byteena_a => "avalon_be\[$effective_be_width-1:0\]" ,
	clock0    => 'clk',
	wren_a    => "avalon_write",
	address_a => "avalon_address\[$iram_depth-1:0\]",
	clocken0  => 'iram_rdclken',           # write port clock enable always enabled
	data_a    => "avalon_writedata\[$effective_iram_data_width-1:0\]",
	aclr0     => 'reset',
	addressstall_a => "1\'b0",
	
	byteena_b => "1\'b1",
	clock1    => "1\'b1",
	wren_b    => "1\'b0",
	address_b => "internal_addr\[$iram_depth-1:0\]",
	clocken1  => 'iram_rdclken',    # read  port clock enable
	aclr1     => "1\'b0",
	addressstall_b =>"1\'b0",
	clocken1  => "1\'b1",
	clocken2  => "1\'b1",
	clocken3  => "1\'b1",
	
	rden_a    => "1\'b1",
	rden_b    => "1\'b1",
	
	data_b	  => "$effective_iram_data_width"."\'b0",
	};
	
  my	$ram_out_port_map = {
	    q_a	      => "avalon_readdata\[$effective_iram_data_width-1:0\]",
	    q_b       => "iram_q\[$opcode_length-1:0\]",
	};	
		
	e_blind_instance->add({
#	    tag            => 'compilation',
	    use_sim_models => 1,
	    name           => $Opt->{'top_module_name'} . "_instr_ram_block", 
	    module         => 'altsyncram',
	    in_port_map    => $ram_in_port_map,
	    out_port_map   => $ram_out_port_map,
	    parameter_map  => $ram_parameter_map,
	});
    # Now make the RAM blocks!  One block per iteration of this loop...
#     my $iram_assignment_rhs = " }";
#     my ($i, $data_index_high, $data_index_low, $ram_out_port_map, $sim_file, $index_of_last_bit_in_last_chunk);
#     my %sim_parameter;
# 
#     for $i (0..($nRAMs-1)) {
# 
# 	# Each time we make a RAM chunk, add a piece to the assign statement
# 	# that sticks the output of all of the RAM chunks together into
# 	# one neat bus.  We output this bus back to the sequencer.
# 	if ($i == ($nRAMs-1)) {
# 	# was ($opcode_length -1)
# 	    $index_of_last_bit_in_last_chunk = ($opcode_length ) % 8;
# 	    $iram_assignment_rhs = "{ iram_q_$i\[$index_of_last_bit_in_last_chunk\:0]" . $iram_assignment_rhs;
# 	} else {
# 	    $iram_assignment_rhs = ", iram_q_$i\[7:0]" . $iram_assignment_rhs;
# 	}	
# 
# 	# Add indexed signals to the module and to the parameter/port maps
# 	# for this chunk.  All other parameters are initialized by the 
# 	# routine initialize_iram_parameter_maps.
#       	$data_index_low  = $i * 8;
# 	$data_index_high = $data_index_low + 7;
# 	e_assign->adds(
# 		       [e_signal->new(["wren_a_$i"=>1]) => "iram_we & avalon_be\[$i\]"],
# 		       [e_signal->new(["data_a_$i"=>8]) => "avalon_data\[$data_index_high\:$data_index_low\]"],
# 		       );
# 	e_signal->add(["iram_q_$i" => 8]);
# #	$ram_parameter_map->{'init_file'} = qq("$instr_ram_initfile\_$i\.mif");
# #	$ram_in_port_map->{'wren_a'}      = "wren_a_$i";
# #	$ram_in_port_map->{'data_a'}      = "data_a_$i";
# 	$ram_out_port_map = {
# 	    q_b       => "iram_q_$i",
# 	};
# 	
# 	# Instantiate the RAM block (for compilation)
# 	e_blind_instance->add({
# 	    tag            => 'compilation',
# 	    use_sim_models => 1,
# 	    name           => $Opt->{'top_module_name'} . "_instr_ram_block_$i", 
# 	    module         => 'altsyncram',
# 	    in_port_map    => $ram_in_port_map,
# 	    out_port_map   => $ram_out_port_map,
# 	    parameter_map  => $ram_parameter_map,
# 	});
# 
# 	# Put in some defparams for simulation.
# 	# Copied almost directly out of the onchip ram generator...
# 	%sim_parameter = %$ram_parameter_map;
# #	print "the laguage=$language";
# 	if ($language eq 'vhdl')
# 	{
# 	    $sim_file = qq("$instr_ram_initfile\_$i\.hex");
# 	}
# 	elsif ($language eq 'verilog')
# 	{
# 	    $sim_file = join ("\n",'',
# 			      '`ifdef NO_PLI',
# 			      qq("$instr_ram_initfile\_$i\.dat"),
# 			      '`else',
# 			      qq("$instr_ram_initfile\_$i\.mif"),
# 			      "\`endif\n");
# 	}
# 	else
# 	{
# 	    die "unknown language ($language)\n";
# 	}
# 	$sim_parameter{init_file}        = $sim_file;
# 	$sim_parameter{init_file_layout} = qq("PORT_A");  # dunno why modelsim can't initialize a dpram properly without this parameter, but it can't...
# 	e_blind_instance->add({
# 	    tag            => 'simulation',
# 	    use_sim_models => 1,
# 	    name           => $Opt->{'top_module_name'} . "_instr_ram_block_$i", 
# 	    module         => 'altsyncram',
# 	    in_port_map    => $ram_in_port_map,
# 	    out_port_map   => $ram_out_port_map,
# 	    parameter_map  => \%sim_parameter,
# 	});
# 
#     }
#     e_assign->add(['iram_q' => $iram_assignment_rhs]);
    return $module;
}





#################################################################
# subroutine initialize_iram_parameter_maps
#
# Returns a parameter hashref and input port hashref for an
# 8-bit Instruction RAM block.  
#
# sub initialize_iram_parameter_maps {
#     my $Opt = shift;
#     my $device_family = $Opt->{'device_family'};
#     my $system_width = $Opt->{'system_width'};
#     my $ram_parameter_map = {
# 	intended_device_family => qq("$device_family"),
# 	operation_mode         => qq("DUAL_PORT"),
# 	width_a                => 8,
# 	widthad_a              => $system_width,
# 	width_b                => 8,
# 	widthad_b              => $system_width,
# 	lpm_type               => qq("altsyncram"),
# 	width_byteena_a        => 1,
# 	byte_size              => 8,
# 	outdata_reg_b          => qq("UNREGISTERED"),
# #	outdata_reg_b          => qq("REGISTERED"),    # Cal: Registered memory output!
# 	address_reg_b          => qq("CLOCK1"),
# 	address_aclr_b         => qq("CLEAR1"),
#     };
#     my $ram_in_port_map = {
# 	clock0    => 'avalon_clk',
# 	clock1    => 'rd_clk',
# 	address_a => 'avalon_address',
# 	address_b => 'internal_addr',
# 	aclr1     => 'reset',
# 	clocken0  => "1\'b1",           # write port clock enable
# 	clocken1  => 'iram_rdclken',    # read  port clock enable
# 	};
#     return ($ram_parameter_map, $ram_in_port_map);
# }





# doesn't work this way anymore
#################################################################
# subroutine update_ptf_with_sim_signals
#
# Since the sequencer is a highly parameterizable component,
# the signals we want to show up in simulation will be disabled
# or enabled in different configurations.  So we have to set up
# the SIMULATION section of the PTF file every time the 
# generator is run. 
# This routine also adds some simulation-only MUXes that 
# translate each module's opcode into an ASCII-encoded 
# instruction name, for easier debugging in simulation.
#
# sub update_ptf_with_sim_signals {
#     my ($Opt, $module, $sim) = @_;
#     my $marker               = e_default_module_marker->new ($module);
#     my $instance_name        = $Opt->{'top_module_name'};
#     my ($typedef_string, $current_opcode, $cmd_string, $opcode_width, $table, $i, $temp);
#     my @module_opcodes;
#     my $signal_index         = 'a';
#     my $signal_index_ref     = \$signal_index;
# 
#     &add_signal_to_sim_section('Control Slave',         $sim, $signal_index_ref, 'divider');    
#     &add_signal_to_sim_section('clk',                   $sim, $signal_index_ref);
#     &add_signal_to_sim_section('c_address',             $sim, $signal_index_ref);
#     &add_signal_to_sim_section('c_chipselect',          $sim, $signal_index_ref);
#     &add_signal_to_sim_section('c_read',                $sim, $signal_index_ref);
#     &add_signal_to_sim_section('c_write',               $sim, $signal_index_ref);
#     &add_signal_to_sim_section('c_writedata',           $sim, $signal_index_ref, 'hex');
#     &add_signal_to_sim_section('c_readdata',            $sim, $signal_index_ref, 'hex');
#         
#     &add_signal_to_sim_section('Instruction RAM Slave', $sim, $signal_index_ref, 'divider');    
#     &add_signal_to_sim_section('i_address',             $sim, $signal_index_ref);
#     &add_signal_to_sim_section('i_chipselect',          $sim, $signal_index_ref);
#     &add_signal_to_sim_section('i_byteenable',          $sim, $signal_index_ref);
#     &add_signal_to_sim_section('i_write',               $sim, $signal_index_ref);
#     &add_signal_to_sim_section('i_writedata',           $sim, $signal_index_ref, 'hex');
#     
#     &add_signal_to_sim_section('Sequencer Internals',   $sim, $signal_index_ref, 'divider');
# #    if ($Opt->{'use_external_clock'}) {
# #	&add_signal_to_sim_section('avalon_clk',        $sim, $signal_index_ref);
# #	&add_signal_to_sim_section('external_clk',      $sim, $signal_index_ref);
# #    }
#     &add_signal_to_sim_section('reset_n',        $sim, $signal_index_ref);
#     &add_signal_to_sim_section('run',            $sim, $signal_index_ref);
#     &add_signal_to_sim_section('module_reset_n', $sim, $signal_index_ref);
#     &add_signal_to_sim_section("__FIX_ME_UP__/the_$instance_name\_addr/current_addr", $sim, $signal_index_ref, 'hex');
#     &add_signal_to_sim_section('address',        $sim, $signal_index_ref, 'hex');
#     &add_signal_to_sim_section('cond',           $sim, $signal_index_ref);
#     &add_signal_to_sim_section('iram_q',         $sim, $signal_index_ref, 'hex');
#     &add_signal_to_sim_section('op_data',        $sim, $signal_index_ref, 'hex');
#     if ($Opt->{'use_edata'}) {
# 	&add_signal_to_sim_section('Edata',      $sim, $signal_index_ref, 'hex');
#     }
#     &add_signal_to_sim_section('data_out',       $sim, $signal_index_ref, 'hex');
# 
#     # Address Opcode
#     e_signal->add({
# 	name         => "ADDR_OPCODE",
# 	never_export => 1,
# 	width        => 8*9,  # 9 ascii characters
#     });
#     e_sim_wave_text->add({
# 	out => 'ADDR_OPCODE',
# 	selecto => 'add_cmd',
# 	table => ["3'h".$Opt->{'opcode_addgen_continue'}   => 'NEXT',
# 		  "3'h".$Opt->{'opcode_addgen_data'}       => 'DATA',
# 		  "3'h".$Opt->{'opcode_addgen_stack'}      => 'STACK',
# 		  "3'h".$Opt->{'opcode_addgen_edata'}      => 'EDATA',
# #		  "3'h".$Opt->{'opcode_addgen_wait_creg'}  => 'WAIT_CREG',
# 		  "3'h".$Opt->{'opcode_addgen_wait'}       => 'WAIT'],
# 	default => 'BAD',
#     });
#     &add_signal_to_sim_section('ADDR_OPCODE', $sim, $signal_index_ref, 'ascii');
#     
#     # Branch Opcode / Module
#     $opcode_width    = $Opt->{'opcode_branch_width'};
#     my $select_width = $opcode_width - 1;
#     my $select_index = $select_width - 1;
#     if ($Opt->{'use_branch'}) {
# 	e_signal->add({
# 	    name         => "BRANCH_OPCODE_SELECT",
# 	    never_export => 1,
# 	    width        => 8*4,  # 4 ascii characters
# 	});
# 	my $branch_number;
# 	if ($Opt->{'opcode_branch_onehot'}) {
# 	    $table = ["$select_width\'d1" => 'TRUE',
# 		      "$select_width\'d2" => 'ZERO'];
# 	    for $i (0..($Opt->{'branch_input_bits'} - 1)) {
# 		$temp = 2 ** ($i + 2);
# 		push (@$table, ("$select_width\'d$temp" => "BR$i"));
# 	    }
# 	} else {
# 	    $table = ["$select_width\'d0" => 'TRUE',
# 		      "$select_width\'d1" => 'ZERO'];
# 	    for $i (0..($Opt->{'branch_input_bits'} - 1)) {
# 		$temp = $i + 2;
# 		push (@$table, ("$select_width\'d$temp" => "BR$i"));
# 	    }	    
# 	}
# 	e_sim_wave_text->add({
# 	    out     => 'BRANCH_OPCODE_SELECT',
# 	    selecto => "branch_cmd[$select_index:0]",
# 	    table   => $table,
# 	    default => 'BAD',
# 	});
# 	&add_signal_to_sim_section('BRANCH_OPCODE_SELECT', $sim, $signal_index_ref, 'ascii');	
# 	e_signal->add({
# 	    name         => "BRANCH_OPCODE_INVERT",
# 	    never_export => 1,
# 	    width        => 1,
# 	});
# 	e_assign->add(['BRANCH_OPCODE_INVERT' => "branch_cmd[$select_width]"]);
# 	&add_signal_to_sim_section('BRANCH_OPCODE_INVERT', $sim, $signal_index_ref);
#     } else {
# 	&add_signal_to_sim_section('branch_cmd', $sim, $signal_index_ref);
#     }
# 
#     # Stack Opcode / Module
#     $opcode_width = $Opt->{'opcode_stack_width'};
#     if ($Opt->{'use_stack'}) {
# 	e_signal->add({
# 	    name         => "STACK_OPCODE",
# 	    never_export => 1,
# 	    width        => 8*10,  # 10 ascii characters
# 	});
# 	e_sim_wave_text->add({
# 	    out     => 'STACK_OPCODE',
# 	    selecto => 'stack_cmd',
# 	    table   => ["$opcode_width'h".$Opt->{'opcode_stack_push_creg'}    => 'PUSH_CREG',
# 			"$opcode_width'h".$Opt->{'opcode_stack_push_address'} => 'PUSH_ADDR',
# 			"$opcode_width'h".$Opt->{'opcode_stack_pop'}          => 'POP',
# 			"$opcode_width'h".$Opt->{'opcode_stack_nop'}          => 'NOP',
# 			"$opcode_width'h".$Opt->{'opcode_stack_push_data'}    => 'PUSH_DATA',
# 			"$opcode_width'h".$Opt->{'opcode_stack_push_edata'}   => 'PUSH_EDATA'],
# 	    default => 'BAD',
# 	});
# 	&add_signal_to_sim_section('STACK_OPCODE', $sim, $signal_index_ref, 'ascii');
# 	&add_signal_to_sim_section('stack', $sim, $signal_index_ref, 'hex');
#     }
# 
#     # CREG Opcode / Module
#     $opcode_width = $Opt->{'opcode_creg_width'};
#     if ($Opt->{'use_creg'}) {
# 	e_signal->add({
# 	    name         => "CREG_OPCODE",
# 	    never_export => 1,
# 	    width        => 8*9,  # 9 ascii characters
# 	});
# 	e_sim_wave_text->add({
# 	    out => 'CREG_OPCODE',
# 	    selecto => 'creg_cmd',
# 	    table => [
# 		      "$opcode_width'h".$Opt->{'opcode_creg_dec'}        => 'DEC',
# 		      "$opcode_width'h".$Opt->{'opcode_creg_load_data'}  => 'LD_DATA',
# 		      "$opcode_width'h".$Opt->{'opcode_creg_load_edata'} => 'LD_EDATA',
# 		      "$opcode_width'h".$Opt->{'opcode_creg_load_stack'} => 'LD_STACK',
# 		      "$opcode_width'h".$Opt->{'opcode_creg_nop'}        => 'NOP',
# 		      
# 		      "$opcode_width'h".($Opt->{'opcode_creg_dec'}        + $Opt->{'opcode_creg_decn'}) => 'WAIT_DEC',
# 		      "$opcode_width'h".($Opt->{'opcode_creg_load_data' } + $Opt->{'opcode_creg_decn'}) => 'WAIT_LD_D',
# 		      "$opcode_width'h".($Opt->{'opcode_creg_load_edata'} + $Opt->{'opcode_creg_decn'}) => 'WAIT_LD_E',
# 		      "$opcode_width'h".($Opt->{'opcode_creg_load_stack'} + $Opt->{'opcode_creg_decn'}) => 'WAIT_LD_S',
# 		      "$opcode_width'h".($Opt->{'opcode_creg_nop'}        + $Opt->{'opcode_creg_decn'}) => 'WAIT',
# 		      ],
# 	    default => 'NOP',
# 	});
# 	&add_signal_to_sim_section('CREG_OPCODE', $sim, $signal_index_ref, 'ascii');
# 	&add_signal_to_sim_section('zero', $sim, $signal_index_ref);
# 	if ($Opt->{'use_stack'}) {
# 	    &add_signal_to_sim_section('creg', $sim, $signal_index_ref, 'hex');
# 	}
#     }
# 
# 
# }
# 

#################################################################
# subroutine add_signal_to_sim_section
#
# Adds the specified signal to the SIMULATION section of a PTF
# file.
# Arguments:
#   $signal_name  - Name of the signal to be added.
#                   Can be a path, if the desired signal is not
#                   in the top-level module.
#   $sim_section  - PTFref to the desired SIMULATION section
#   $ref_to_index - Reference to the scalar variable storing
#                   the index to the current signal.  The index
#                   should be initialized as 'a', and is
#                   incremented each time a signal is added.
#   $type         - Type of signal to be added.  Currently
#                   supported values are:
#                      'divider', 'hex', and 'ascii'
#                   Matching is case-insensitive substring
#                   matching.  I.e., 'Hexadecimal' would
#                   match 'hex'.
#                   If the provided type is not recognized,
#                   the $type string is blindly inserted into
#                   signal's 'radix' variable assignment.
#
# sub add_signal_to_sim_section {
#     my ($signal_name, $sim_section, $ref_to_index, $type) = @_;
# 
#     $sim_section->{DISPLAY}{"SIGNAL $$ref_to_index"}{name} = $signal_name;
#     if ($type =~ m/divider/i) {
# 	$sim_section->{DISPLAY}{"SIGNAL $$ref_to_index"}{format} = 'Divider';
#     } elsif ($type =~ m/hex/i) {
# 	$sim_section->{DISPLAY}{"SIGNAL $$ref_to_index"}{radix}  = 'hexadecimal';
#     } elsif ($type =~ m/ascii/i) {
# 	$sim_section->{DISPLAY}{"SIGNAL $$ref_to_index"}{radix}  = 'ascii';
#     } elsif ($type) {
# 	$sim_section->{DISPLAY}{"SIGNAL $$ref_to_index"}{radix}  = $type;
#     }
#     if ($$ref_to_index =~ m/(\w?)z$/) {
# 	$$ref_to_index .= 'a';
#     } else {
# 	($$ref_to_index)++;
#     }
# }






#################################################################
# subroutine generate_variation_file
#
# Generate the .shf (sequencer header file) that the microcode
# assembler will parse in order to generate Instruction RAM
# memory initialization files that will run on this particular
# instance of the sequencer.
# All the values we're looking for should have already been
# specified in the WIZARD_SCRIPT_ARGUMENTS section of the PTF,
# or should have been entered into the $Options hash at some
# point earlier in the generator's execution.
#
sub generate_variation_file {
    my ($Opt, $system_dir, $top_module_name) = (@_);
    my @wsa_args_to_output = (
			      'top_module_name',
			      'system_width',
			      'dataout_bits',
			      'use_branch',
			      'use_stack',
			      'use_creg',
			      'use_edata',
			      'branch_input_bits',
			      'stack_depth',
			      'opcode_creg_width',
			      'opcode_creg_dec',
			      'opcode_creg_load_data',
			      'opcode_creg_load_edata',
			      'opcode_creg_load_stack',
			      'opcode_creg_decn',
			      'opcode_creg_nop',
			      'opcode_stack_width',
			      'opcode_stack_push_creg',
			      'opcode_stack_push_address',
			      'opcode_stack_pop',
			      'opcode_stack_nop',
			      'opcode_stack_push_data',
			      'opcode_stack_push_edata',
			      'opcode_branch_width',
			      'opcode_branch_negate',
			      'opcode_branch_onehot',
			      'opcode_branch_creg_zero',
			      'opcode_branch_default_pass',
			      'opcode_addgen_width',
			      'opcode_addgen_continue',
			      'opcode_addgen_data',
			      'opcode_addgen_stack',
			      'opcode_addgen_edata',
			      'opcode_addgen_wait_creg',
			      'opcode_addgen_wait',
			      'opcode_data_width',
			      'opcode_length',  
			      'effective_iram_data_width',
			      'n_8bit_ram_chunks',       
			      'iram_slave_data_width',
			      'imemory_depth',
			      'break_bit',
#			      'system_directory',
			      );
    # output the file to /sdk/inc/<instance_name>.shf
#    my $filepath = $system_dir . '/' . $top_module_name . '_sdk/inc/' . $top_module_name . '.shf';
    my $filepath =  $system_dir . '/' . $top_module_name .  '.shf';
#    print "WARNING: variation file at $filepath.\n         May cause MicroCode compiler to generate bad memory files.\n";
 
    my $filestring = "// MicroSequencer variation definition for module $top_module_name\n// Generated " . localtime() . "\n\n";
    my $key;
    my $value;
    my $i;
    my $opcode_format = &make_opcode_format_string($Opt);
#    print "- Opcode format will be: $opcode_format\n";
    foreach $key (@wsa_args_to_output) {
	$value = ($Opt->{$key}) ? $Opt->{$key} : 0;
	$filestring .= '__' . $key . '=' . $value . ";\n";
    }
    for $i (0..($Opt->{'branch_input_bits'} - 1)) {
	$key = "BR$i";
	$filestring .= $key . '=' . $Opt->{$key} . ";\n";
    }
    $filestring .= '// opcode_format=' . $opcode_format;
 #   print "- Writing variation file to $filepath\n- Instance parameters and opcode format will be defined in this file.\n";
    open(OUTFILE, ">$filepath")
	or print "WARNING: Unable to write variation file at $filepath.\n         May cause MicroCode compiler to generate bad memory files.\n";
    print OUTFILE $filestring;
    close(OUTFILE);
    # output to sdk/src as well.
#    my $filepath = $system_dir . '/' . $top_module_name . '_sdk/src/' . $top_module_name . '.shf';
# #   print "- Writing another copy of variation file to $filepath\n";
#    open(OUTFILE, ">$filepath")
#	or print "WARNING: Unable to write variation file at $filepath.\n         May cause MicroCode compiler to generate bad memory files.\n";
#    print OUTFILE $filestring;
#    close(OUTFILE);
    return 1;
}




#################################################################
# subroutine make_opcode_format_string
#
# Based on the values stored in the $Options hash, returns a
# string specifying the makeup of this particular sequencer 
# variation's instruction word.  This routine has no functional
# significance, but currently is used in two places:
#   (1) Called to report the instruction word format in the
#       SOPC Builder System Generation window after the
#       HDL generator has finished running
#   (2) Opcode format is also reported as a comment in the 
#       variation file.  The opcode format string is not 
#       parsed by the microcode assembler -- it is output
#       there only for reference.  The assembler determines
#       the opcode format from the other parameters specified
#       in the variation file.
sub make_opcode_format_string {
    my $Opt = shift;
    my $data_out_index   = $Opt->{'dataout_bits'} - 1;
    my $op_data_index    = $Opt->{'opcode_data_width'} - 1;  ####
    my $stack_cmd_index  = $Opt->{'opcode_stack_width'} - 1;
    my $creg_cmd_index   = $Opt->{'opcode_creg_width'} - 1;
    my $branch_cmd_index = $Opt->{'opcode_branch_width'} - 1;
    my $add_cmd_index    = $Opt->{'opcode_addgen_width'} - 1;

    my $string = "\{data_out\[$data_out_index\..0\],op_data\[$op_data_index\..0\],break_bit,";
    if ($Opt->{'use_stack'}) {
	$string .= "stack_cmd\[$stack_cmd_index\..0\],";
    }
    if ($Opt->{'use_creg'}) {
	$string .= "creg_cmd\[$creg_cmd_index\..0\],";
    }
#    if ($Opt->{'use_branch'}) {
	$string .= "branch_cmd\[$branch_cmd_index\..0\],";
#    }
    $string .= "add_cmd\[$add_cmd_index..0\]\}";
    return $string;    
}
1;

