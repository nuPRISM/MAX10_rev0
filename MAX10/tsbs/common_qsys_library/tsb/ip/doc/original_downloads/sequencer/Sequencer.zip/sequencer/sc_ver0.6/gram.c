%{
#include <stdio.h>
#include <string.h>
#include "scan.h"
//extern char yytext[];
extern int column;
extern int lineno;
extern char linebuf[];
extern long code_address;
extern int error_count;
struct symtab *sp;
struct code the_code;
char error[100];
int clear_the_code(struct code* ptr);
int check_stack_opcode(struct code* ptr);
int check_data_opcode(struct code* ptr, int x);
int check_creg_opcode(struct code* ptr);
int check_addgen_opcode(struct code* ptr);
#define YYDEBUG 1
//	yydebug=1;
%}

%token LEFT_OP RIGHT_OP EQ_OP NE_OP
%token DEVICE CONTINUE DEC STACK CREG LOAD WAIT
%token THEN PUSH POP TO FROM LOOP GOSUB

%token PREPROCESSOR COMPILER
%token PNAME PNUMBER ORG
%token BRANCH_CONDITION

%token DEFAULT IF ELSE WHILE GOTO CONTINUE RETURN
%union {
	long val;
	struct symtab *symp;
}
%token <symp> NAME BRANCH_CONDITION
%token <symp> ADR_LABEL
%token <symp> PNAME
%token <symp> PLABEL
%token DATA_IN
%left <val> NUMBER
%left <val> PNUMBER
%token <val> DEFAULT_OUT
%left '-' '+'
%left '*' '/'
%left '|' '&'
%nonassoc UMINUS

%type <val> while_condition if_condition statement cond;
%type <val> expression pexpression
%type <val> begin_expression goto_state gosub_state loop_state load_state push state pop_state
%type <symp> the_label
%type <val>  else_wait wait_else_load

%type <val> sequencer_grammer
%type <val> sequencer_grammer_list
%type <val> preprossesor_grammer_list
%type <val> preprossesor_grammer p_any_line
%type <val> default_expr

%%
combined: PREPROCESSOR preprossesor_grammer_list  {clear_the_code(&the_code);}
          |COMPILER sequencer_grammer_list
          ;
preprossesor_grammer_list:   preprossesor_grammer
                | preprossesor_grammer_list preprossesor_grammer {$$= 0;}
                ;
preprossesor_grammer: p_any_line   {$$=1;}
                      ;
p_any_line: ',' ';'    {code_address++;}
           |PNAME '=' BRANCH_CONDITION';' {$1->value=$3->value;$1->type=$3->type;}
           |PNAME '=' pexpression ';' {$1->value =$3; $1->type = INITIALIZED_VARIABLE;}
          /* |PNAME '=' PNAME  ';'{$1->value =$3->value; $1->type= $3->type;}*/
           |PLABEL ':' {
                      $1->value = code_address;
                      $1->type = ADR_LABEL;
                     }
           |ORG ':' pexpression ';' {
                      code_address = $3;
                     }
          /* |ORG':' PLABEL ';'{
                      code_address = $3->value;
                     }*/
          ;
pexpression: pexpression '+' pexpression { $$ = $1 + $3; }
	|	pexpression '-' pexpression { $$ = $1 - $3; }
	|	pexpression '|' pexpression { $$ = $1 | $3; }
	|	pexpression '&' pexpression { $$ = $1 & $3; }
	|	pexpression '*' pexpression { $$ = $1 * $3; }
	|	pexpression '/' pexpression
				{	if($3 == 0.0)
						yyerror("divide by zero");
					else
						$$ = $1 / $3;
				}
	|	'-' pexpression %prec UMINUS	{ $$ = -$2; }
	|	'(' pexpression ')'	{ $$ = $2; }
	|	PNUMBER
	|	PNAME			{   if ($1->type == VARIABLE)
	                                    {
	                                       sprintf(error,"The symbol %s is not initialized",$1->name);
                                               yyerror(error);
                                             }
                                             $$ = $1->value; }
	;




sequencer_grammer_list: sequencer_grammer
		|sequencer_grammer_list sequencer_grammer
	;

sequencer_grammer: default_expr {$$ = 0;}
	| device_expr {$$ = 1;}
	| assign_statement {$$ = 2;}
	| statement	{$$ = 3; code_address++;clear_the_code(&the_code);}
	| the_label		{$$ = 4;}
	;

the_label:ADR_LABEL ':' {$$= $1 ;
                        /*printf("label %d",$1->value);*/
                     /* do nothing this was handeled in the preprocessor stage*/}
                     ;

 default_expr
	:DEFAULT_OUT '=' expression ';' {$$=$1 = $3; /*printf("\n** Parsed a default_expr %d**\n",DEFAULT);*/}
	;

device_expr
	:DEVICE '(' expression ')' ';'{/*printf("\n** Parsed a device_expr (value = %d) **\n",$3);*/}
	;

assign_statement:	NAME '=' expression ';'     { /* nothing to do handeled in the pre processor*/ }
	| BRANCH_CONDITION '=' BRANCH_CONDITION ';' {/* nothing to do handeled in the pre processor*/}
	;

statement:
	  begin_expression if_condition goto_state else_wait';'	{// done}

         | begin_expression if_condition gosub_state else_wait';'{//}

        | begin_expression if_condition ';'			{
                                                                     the_code.branch=$$=symlook("__opcode_branch_default_pass")->value;
                                                                     the_code.addgen = symlook("__opcode_addgen_continue")->value ;
                                                                     the_code.opcode_data = 0;
                                                                     the_code.creg =  symlook("__opcode_creg_nop")->value;
                                                                     the_code.stack=  symlook("__opcode_stack_nop")->value;
                                                                }

	|begin_expression if_condition load_state else_wait ';' {//}

	|begin_expression if_condition DEC ';'				{// DEC only
                                                                     the_code.addgen = symlook("__opcode_addgen_continue")->value ;
                                                                     the_code.opcode_data = 0;
                                                                     the_code.creg = symlook("__opcode_creg_dec")->value;
                                                                     the_code.stack=  symlook("__opcode_stack_nop")->value;
                                                                  }
	|begin_expression if_condition push_state ';'		{//}
	|begin_expression if_condition pop_state ';'		{// }
	|begin_expression if_condition RETURN';'                   {the_code.addgen = symlook("__opcode_addgen_continue")->value ;
                                                                     the_code.opcode_data = 0;
                                                                     the_code.creg =  symlook("__opcode_creg_load_stack")->value;
                                                                     the_code.stack=  symlook("__opcode_stack_pop")->value;
                                                                     }
        |begin_expression if_condition loop_state';'                   { }
	;

begin_expression: ',' {the_code.data = 0; /*printf("no expression");*/}
	| expression ',' {the_code.data = $1;}
	;

else_wait:           {$$=0;}
	| ELSE WAIT  {$$=1;
                            if(the_code.addgen==-1)  // if they have never been filled don't or
                                the_code.addgen = symlook("__opcode_addgen_wait")->value;
                            else
                                the_code.addgen |= symlook("__opcode_addgen_wait")->value;
                        }
	| ELSE WAIT WHILE CREG {$$=2;
                            if(the_code.addgen==-1)  // if they have never been filled don't or
                                the_code.addgen = symlook("__opcode_addgen_wait_creg")->value;
                            else
                                the_code.addgen |= symlook("__opcode_addgen_wait_creg")->value;
                        }
        ;

wait_else_load:  WAIT         {$$=0;}
	| WAIT ELSE LOAD  {$$=1;}
        ;

to:
	|	TO
        ;

pop_state:
           POP    {
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_pop")->value;
                        }
        |POP to CREG {
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_pop")->value;
                              if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_load")->value;
                        }
        ;
push_state:
           PUSH CREG    {
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_push_creg")->value;
                        }
         /*  |PUSH DATA_IN{
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_push_edata")->value;
                        } not supported yet */
           |PUSH ADDRESS{
                              if(check_stack_opcode(&the_code)==OK)
                                the_code.stack = symlook("__opcode_stack_push_address")->value;
                        }
           ;
goto_state:
          GOTO DATA_IN      {$$=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_edata")->value;
                }
          |GOTO STACK       {$$=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_stack")->value;
                }
          |GOTO expression  {$$=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen |= symlook("__opcode_addgen_data")->value;
                              if(check_data_opcode(&the_code,$2)==OK)
                                  the_code.opcode_data = $2;
                            }
        ;

gosub_state:
          GOSUB DATA_IN {$$=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_edata")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_push_address")->value;
                              }
          |GOSUB STACK  {$$=0;if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_stack")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_push_address")->value;
                              }
          |GOSUB expression  {$$=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_data")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_push_address")->value;
                              if(check_data_opcode(&the_code,$2)==OK)
                                  the_code.opcode_data = $2;
                              }
          ;
 loop_state:
          LOOP DATA_IN {$$=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_edata")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_push_address")->value;
                              if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_dec")->value;
                              }
          |LOOP STACK  {$$=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_stack")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_push_address")->value;
                              if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_dec")->value;
                              }
          |LOOP expression  {$$=0;
                              if(check_addgen_opcode(&the_code)==OK)
                                  the_code.addgen = symlook("__opcode_addgen_data")->value;
                              if(check_stack_opcode(&the_code)==OK)
                                  the_code.stack = symlook("__opcode_stack_push_address")->value;
                              if(check_data_opcode(&the_code,$2)==OK)
                                  the_code.opcode_data = $2;
                              if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_dec")->value;
                            }
          ;
load_state:
          LOAD DATA_IN {      if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_load_edata")->value;
                        }
          |LOAD STACK  {      if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_load_stack")->value;
                        }
          |LOAD expression  { if(check_creg_opcode(&the_code)==OK)
                                  the_code.creg =symlook("__opcode_creg_load_edata")->value;
                              if(check_data_opcode(&the_code,$2)==OK)
                                  the_code.opcode_data = $2;
                            }
          ;

expression: expression '+' expression { $$ = $1 + $3; }
	|	expression '-' expression { $$ = $1 - $3; }
	|	expression '|' expression { $$ = $1 | $3; }
	|	expression '&' expression { $$ = $1 & $3; }
	|	expression '*' expression { $$ = $1 * $3; }
	|	expression '/' expression
				{	if($3 == 0.0)
						yyerror("divide by zero");
					else
						$$ = $1 / $3;
				}
	|	'-' expression %prec UMINUS	{ $$ = -$2; }
	|	'(' expression ')'	{ $$ = $2; }
	|	NUMBER
	|	NAME			{   if ($1->type == VARIABLE)
	                                    {
	                                       sprintf(error,"The symbol %s is not initialized",$1->name);
                                               yyerror(error);
                                             }
                                             $$ = $1->value; }
  	|       ADR_LABEL               { $$ = $1->value; }
	;

if_condition:  {the_code.branch=$$=symlook("__opcode_branch_default_pass")->value;}
	| IF '(' cond ')' then { $$=$3;
                                       the_code.branch=$3;}
        | CONTINUE {the_code.branch=$$=symlook("__opcode_branch_default_pass")->value;}
	;

while_condition: WHILE '(' cond ')' { $$=$3;
                                      the_code.branch=$3;}

cond :
		CREG NE_OP expression {/*printf("cond");*/
		                        if($3 == 0) //(CREG != 0) /* the values of the OPCODES are stored in the symbol table so se need to look them up*/
                                           $$  = symlook("__opcode_branch_creg_zero")->value | symlook("__opcode_branch_negate")->value;
                                        else
                                        {
                                          if($3 == 1) //(CREG != 1) or (CREG == 0)
                                            $$  = symlook("__opcode_branch_creg_zero")->value;
                                          else
                                            yyerror("CREG can only be compared against 0 and 1  ie \n (CREG <> 0), (CREG != 0), (CREG == 0), (CREG)\n(CREG <> 1), (CREG != 1), (CREG == 1)");
                                        }
                                      }
	|	CREG EQ_OP expression {/*printf("cond");*/
		                        if($3 == 1) //(CREG != 0)  /* the values of the OPCODES are stored in the symbol table so se need to look them up*/
                                           $$  = symlook("__opcode_branch_creg_zero")->value | symlook("__opcode_branch_negate")->value;
                                        else
                                        {
                                          if($3 == 0) //(CREG != 1) or (CREG == 0)
                                            $$  = symlook("__opcode_branch_creg_zero")->value;
                                          else
                                            yyerror("CREG can only be compared against 0 and 1  ie \n (CREG <> 0), (CREG != 0), (CREG == 0), (CREG)\n(CREG <> 1), (CREG != 1), (CREG == 1)");
                                        }
                                      }
	|	BRANCH_CONDITION NE_OP expression {/*printf("cond");*/
		                        if($3 == 0)  //(BR1 != 0) or (BR1==1)  /* the values of the OPCODES are stored in the symbol table so se need to look them up*/
                                           $$  = $1->value;
                                        else
                                        {
                                          if($3 == 1) //(CREG != 1) or (CREG == 0)
                                            $$  = $1->value | symlook("__opcode_branch_negate")->value;   /*negate the answer*/
                                          else
                                            yyerror("BRANCH conditions can only be compared against 0 and 1  ie \n (BRx <> 0), (BRx != 0), (BRx == 0), (BRx)\n(CREG <> 1), (BRx != 1), (BRx == 1)");
                                        }
                                      }
	|	BRANCH_CONDITION EQ_OP expression {/*printf("cond");*/
		                        if($3 == 1) //(BR1 != 0) or (BR1==1)
                                        {  /* the values of the OPCODES are stored in the symbol table so se need to look them up*/
                                           $$ = $1->value;
                                        }
                                        else
                                        {
                                          if($3 == 0) //(CREG != 1) or (CREG == 0)
                                            $$  = $1->value | symlook("__opcode_branch_negate")->value;   /*negate the answer*/
                                          else
                                            yyerror("BRANCH conditions can only be compared against 0 and 1  ie \n (BRx <> 0), (BRx != 0), (BRx == 0), (BRx)\n(CREG <> 1), (BRx != 1), (BRx == 1)");
                                        }
                                      }
	|	BRANCH_CONDITION {/*printf("cond");*/
                                  the_code.branch  = $1->value;}
	;
then :/* can be blank*/
	| THEN;


%%

/* look up a symbol table entry, add if not present */
struct symtab *
symlook(s)
char *s;
{
	char *p;
	struct symtab *sp;
	
	for(sp = symtab; sp < &symtab[NSYMS]; sp++) {
		/* is it already here? */
		if(sp->name && !strcmp(sp->name, s))
			return sp;
		
		/* is it free */
		if(!sp->name) {
			sp->name = (char*)strdup(s);
			return sp;
		}
		/* otherwise continue to next */
	}
	yyerror("Too many symbols");
	exit(1);	/* cannot continue */
} /* symlook */


yyerror(s)
char *s;
{
	fflush(stdout);
	printf("\n***** Error on line#%d *****\n%s\n", lineno,linebuf);
	printf("\n%*s\n%*s \n\n", column, "^", column, s);
	error_count++;
}

int clear_the_code(struct code* ptr)
{

       ptr->creg=-1;
       ptr->stack=-1;
       ptr->branch=-1;
       ptr->addgen=-1;
       ptr->opcode_data=-1;
       ptr->data=0;
       ptr->adr=0; // this is the codes address in memory
       ptr->line=0;
       ptr->name =0;
return OK;
};

int check_stack_opcode(struct code* ptr)
{
    if (ptr->stack == -1)
       return(OK);
    yyerror("STACK has already been assigned an action and cannot accept two.");
    return(ERROR);
}
int check_data_opcode(struct code* ptr, int x)
{
 if ((ptr->opcode_data == -1)|| (ptr->opcode_data==x))
       return(OK);
    yyerror("Data field has already been assigned a value and connot be assigned a different one.");
    return(ERROR);
}
int check_creg_opcode(struct code* ptr)
{
if (ptr->creg == -1)
       return(OK);
    yyerror("GREG has already been assigned an action and cannot accept two.");
    return(ERROR);
}
int check_addgen_opcode(struct code* ptr)
{
if (ptr->addgen == -1)
       return(OK);
    yyerror("ADDRESS GENERATOR has already been assigned an action and cannot accept two.");
    return(ERROR);
}

